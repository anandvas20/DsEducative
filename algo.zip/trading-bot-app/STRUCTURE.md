# 📁 Project Structure

Complete directory tree of the Trading Bot Management Application.

```
trading-bot-app/
│
├── 📄 README.md                          # Complete documentation
├── 📄 QUICKSTART.md                      # 5-minute setup guide
├── 📄 PROJECT_SUMMARY.md                 # Project overview
├── 📄 STRUCTURE.md                       # This file
├── 🚀 start.sh                           # One-command startup script
├── 🔧 setup-frontend.sh                  # Frontend setup script
│
├── 📂 backend/                           # Python FastAPI Backend
│   ├── 📄 requirements.txt               # Python dependencies
│   ├── 📄 .env.example                   # Environment template
│   │
│   └── 📂 app/                           # Main application
│       ├── 📄 __init__.py
│       ├── 📄 main.py                    # FastAPI app entry point
│       │
│       ├── 📂 core/                      # Core functionality
│       │   ├── 📄 __init__.py
│       │   ├── 📄 config.py              # App configuration
│       │   ├── 📄 bot_manager.py         # Bot process control
│       │   └── 📄 mt5_connector.py       # MT5 integration
│       │
│       ├── 📂 api/                       # API layer
│       │   ├── 📄 __init__.py
│       │   └── 📂 routes/                # API endpoints
│       │       ├── 📄 __init__.py
│       │       ├── 📄 bots.py            # Bot control endpoints
│       │       ├── 📄 positions.py       # Position management
│       │       ├── 📄 analytics.py       # Performance metrics
│       │       └── 📄 config.py          # Configuration API
│       │
│       ├── 📂 models/                    # Database models
│       │   └── 📄 __init__.py
│       │
│       ├── 📂 schemas/                   # Pydantic schemas
│       │   └── 📄 __init__.py
│       │
│       └── 📂 services/                  # Business logic
│           └── 📄 __init__.py
│
└── 📂 frontend/                          # Angular Frontend
    └── (Created by setup-frontend.sh)
        │
        └── 📂 trading-bot-frontend/      # Angular project
            ├── 📄 package.json           # npm dependencies
            ├── 📄 angular.json           # Angular config
            ├── 📄 tsconfig.json          # TypeScript config
            │
            └── 📂 src/
                ├── 📄 index.html
                ├── 📄 main.ts
                ├── 📄 styles.scss
                │
                └── 📂 app/
                    ├── 📄 app.component.ts
                    ├── 📄 app.component.html
                    ├── 📄 app.component.scss
                    ├── 📄 app.routes.ts
                    │
                    ├── 📂 core/          # Core services
                    │   └── 📂 services/
                    │       ├── 📄 api.service.ts
                    │       ├── 📄 websocket.service.ts
                    │       └── 📄 bot.service.ts
                    │
                    ├── 📂 features/      # Feature modules
                    │   ├── 📂 dashboard/
                    │   │   ├── 📄 dashboard.component.ts
                    │   │   ├── 📄 dashboard.component.html
                    │   │   └── 📄 dashboard.component.scss
                    │   │
                    │   ├── 📂 bot-control/
                    │   │   ├── 📄 bot-control.component.ts
                    │   │   ├── 📄 bot-control.component.html
                    │   │   └── 📄 bot-control.component.scss
                    │   │
                    │   ├── 📂 positions/
                    │   │   ├── 📄 positions.component.ts
                    │   │   ├── 📄 positions.component.html
                    │   │   └── 📄 positions.component.scss
                    │   │
                    │   ├── 📂 analytics/
                    │   │   ├── 📄 analytics.component.ts
                    │   │   ├── 📄 analytics.component.html
                    │   │   └── 📄 analytics.component.scss
                    │   │
                    │   └── 📂 settings/
                    │       ├── 📄 settings.component.ts
                    │       ├── 📄 settings.component.html
                    │       └── 📄 settings.component.scss
                    │
                    └── 📂 shared/        # Shared components
                        ├── 📂 header/
                        │   ├── 📄 header.component.ts
                        │   ├── 📄 header.component.html
                        │   └── 📄 header.component.scss
                        │
                        └── 📂 sidebar/
                            ├── 📄 sidebar.component.ts
                            ├── 📄 sidebar.component.html
                            └── 📄 sidebar.component.scss
```

## 📊 File Statistics

### Backend
- **Python Files**: 10
- **Configuration Files**: 2
- **Total Lines**: ~1,500

### Frontend (After Setup)
- **TypeScript Files**: 20+
- **HTML Templates**: 10+
- **SCSS Styles**: 10+
- **Total Lines**: ~2,000+

### Documentation
- **Markdown Files**: 4
- **Scripts**: 2
- **Total Lines**: ~800

## 🎯 Key Files Explained

### Backend

**main.py**
- FastAPI application setup
- CORS middleware
- Socket.IO integration
- Route registration

**bot_manager.py**
- Start/stop bot processes
- Monitor bot health
- Process management

**mt5_connector.py**
- Connect to MetaTrader 5
- Fetch positions & account data
- Execute trades
- Get historical data

**routes/bots.py**
- Bot control endpoints
- Start/stop/restart bots
- Get bot status

**routes/positions.py**
- Position management
- Close positions
- Get position summary

**routes/analytics.py**
- Performance metrics
- Equity curve
- Daily P&L

**routes/config.py**
- Get/update configuration
- Default settings
- Reset config

### Frontend

**api.service.ts**
- HTTP client for API calls
- Error handling
- Response parsing

**websocket.service.ts**
- WebSocket connection
- Real-time updates
- Event handling

**bot.service.ts**
- Bot state management
- Bot control actions
- Status monitoring

**dashboard.component**
- Main dashboard view
- Real-time P&L
- Performance charts

**bot-control.component**
- Start/stop buttons
- Bot status display
- Emergency controls

**positions.component**
- Position list
- Close actions
- Real-time updates

**analytics.component**
- Performance charts
- Trade history
- Metrics display

**settings.component**
- Configuration editor
- Parameter management
- Preset handling

## 🔄 Data Flow

```
User Action (Frontend)
    ↓
API Service (HTTP/WebSocket)
    ↓
FastAPI Backend
    ↓
Bot Manager / MT5 Connector
    ↓
Trading Bots / MetaTrader 5
    ↓
Real-time Updates (WebSocket)
    ↓
Frontend Components
    ↓
User Interface
```

## 📦 Dependencies

### Backend (requirements.txt)
```
fastapi==0.109.0
uvicorn[standard]==0.27.0
python-socketio==5.11.0
MetaTrader5==5.0.45
pandas==2.1.4
numpy==1.26.3
pydantic==2.5.3
sqlalchemy==2.0.25
redis==5.0.1
```

### Frontend (package.json)
```json
{
  "dependencies": {
    "@angular/core": "^17.0.0",
    "@angular/material": "^17.0.0",
    "socket.io-client": "^4.6.0",
    "chart.js": "^4.4.0",
    "ng2-charts": "^5.0.0"
  }
}
```

## 🚀 Getting Started

1. **Clone/Navigate to project**
   ```bash
   cd trading-bot-app
   ```

2. **Setup Backend**
   ```bash
   cd backend
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Setup Frontend**
   ```bash
   ./setup-frontend.sh
   ```

4. **Start Application**
   ```bash
   ./start.sh
   ```

## 📝 Notes

- All Python files include proper imports and error handling
- Frontend components follow Angular best practices
- WebSocket integration for real-time updates
- RESTful API design
- Modular and scalable architecture
- Production-ready code structure

---

**Total Project Size**: ~3,500+ lines of code
**Languages**: Python, TypeScript, HTML, SCSS
**Frameworks**: FastAPI, Angular
**Real-time**: Socket.IO WebSockets