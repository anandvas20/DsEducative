"""
Models package
"""

from .schemas import (
    BotConfig,
    BotTemplate,
    BotAssignment,
    ConfigurationData,
    BotStatus,
    BotControlRequest,
    BotControlResponse,
    Position,
    PositionSummary,
    TradeStatistics,
    DailyPerformance,
    AnalyticsData,
    WebSocketEvent,
    TradeEvent,
    BotStatusEvent,
    SuccessResponse,
    ErrorResponse,
    CreateTemplateRequest,
    UpdateTemplateRequest,
    AssignTemplateRequest
)

__all__ = [
    "BotConfig",
    "BotTemplate",
    "BotAssignment",
    "ConfigurationData",
    "BotStatus",
    "BotControlRequest",
    "BotControlResponse",
    "Position",
    "PositionSummary",
    "TradeStatistics",
    "DailyPerformance",
    "AnalyticsData",
    "WebSocketEvent",
    "TradeEvent",
    "BotStatusEvent",
    "SuccessResponse",
    "ErrorResponse",
    "CreateTemplateRequest",
    "UpdateTemplateRequest",
    "AssignTemplateRequest"
]

# Made with Bob