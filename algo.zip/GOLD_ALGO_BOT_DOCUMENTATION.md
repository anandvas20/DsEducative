# Gold Algorithmic Trading Bot - Complete Documentation

## Table of Contents
1. [Overview](#overview)
2. [System Architecture](#system-architecture)
3. [Core Components](#core-components)
4. [Trading Strategy](#trading-strategy)
5. [Configuration](#configuration)
6. [Installation & Setup](#installation--setup)
7. [Usage](#usage)
8. [Risk Management](#risk-management)
9. [Logging & Monitoring](#logging--monitoring)
10. [Troubleshooting](#troubleshooting)

---

## Overview

**Gold Algorithmic Trading Bot** is an automated trading system designed for trading Gold (XAUUSD) on the MetaTrader 5 platform. The bot implements a grid trading strategy with dynamic risk management, hedge protection, and adaptive market regime detection.

### Key Features
- ✅ **Grid Trading Strategy**: Automated buy entries with progressive lot sizing
- ✅ **Dynamic Hedging**: Automatic hedge positions to protect against adverse moves
- ✅ **EMA-based Trend Detection**: Uses 5/9 EMA crossover for entry signals
- ✅ **ATR-based Volatility Adaptation**: Adjusts grid spacing based on market volatility
- ✅ **Advanced Logging**: Multi-level logging with rotation and throttling
- ✅ **Thread-safe Operations**: Concurrent position management with locks
- ✅ **Performance Monitoring**: Built-in performance tracking for all operations
- ✅ **State Persistence**: Saves and restores bot state across restarts

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Gold Algo Bot                            │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │   Logging    │    │   MT5 API    │    │  State Mgmt  │  │
│  │   System     │    │  Connection  │    │   (JSON)     │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Main Bot Loop (bot_loop)                 │  │
│  └──────────────────────────────────────────────────────┘  │
│           │                    │                    │        │
│           ▼                    ▼                    ▼        │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐  │
│  │    Market    │    │     Grid     │    │   Hedge      │  │
│  │    Data      │    │    Engine    │    │   Manager    │  │
│  │   Fetcher    │    │              │    │              │  │
│  └──────────────┘    └──────────────┘    └──────────────┘  │
│           │                    │                    │        │
│           └────────────────────┴────────────────────┘        │
│                              │                                │
│                              ▼                                │
│                    ┌──────────────────┐                      │
│                    │   TP Engine      │                      │
│                    │  (Take Profit)   │                      │
│                    └──────────────────┘                      │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## Core Components

### 1. ThrottledLogger Class
**Purpose**: Advanced logging system with throttling to prevent log spam

**Features**:
- Multiple log handlers (console, main log, debug log, error log)
- Automatic log rotation (size-based and time-based)
- Message throttling to reduce duplicate logs
- Thread-safe operations
- Performance metrics tracking

**Log Files**:
- `gold_grid_bot.log` - Main operational log (10MB max, 5 backups)
- `gold_grid_debug.log` - Debug information (daily rotation, 7 days retention)
- `gold_grid_errors.log` - Error tracking (5MB max, 10 backups)

### 2. MT5 Connection Manager
**Functions**: `load_mt5_credentials()`, `init_mt5()`

**Purpose**: Manages MetaTrader 5 connection and authentication

**Environment Variables Required**:
```bash
MT5_LOGIN=your_account_number
MT5_PASSWORD=your_password
MT5_SERVER=your_broker_server
```

**Connection Path**: `C:\Program Files\XM Global MT5\terminal64.exe`

### 3. Position Management System
**Functions**: `get_positions()`, `floating_pnl()`, `total_buy_volume()`

**Features**:
- Position caching (150ms cache duration)
- Thread-safe access with locks
- Real-time P&L calculation
- Volume aggregation by direction

### 4. Technical Indicators
**ATR (Average True Range)**:
```python
def ATR(df, period=14):
    # Calculates volatility measure
    # Used for dynamic grid spacing
```

**EMA (Exponential Moving Average)**:
- Fast EMA: 5 periods
- Slow EMA: 9 periods
- Used for trend detection

---

## Trading Strategy

### Grid Trading Logic

#### Phase 1: Initial Entry
```
Condition: No open positions
Signal: Fast EMA > Slow EMA (bullish trend)
Action: Open first buy position with LOT_LADDER[0]
```

#### Phase 2: Grid Recovery Entries
```
Condition: Price moves against position
Trigger: Price gap >= dynamic_gap
Action: Add new buy position with increased lot size
```

**Dynamic Gap Calculation**:
```python
dynamic_gap = max(MIN_GRID_GAP, atr_now * 0.25)
```

#### Phase 3: Take Profit
```
Condition: Floating P&L >= dynamic_tp_target
Action: Close all positions, reset lot_index
```

### Lot Sizing Ladder
```python
LOT_LADDER = [
    0.01,  # Entry 1
    0.01,  # Entry 2
    0.01,  # Entry 3
    0.02,  # Entry 4
    0.02,  # Entry 5
    0.02,  # Entry 6
    0.03,  # Entry 7
    0.04   # Entry 8 (max)
]
```

**Progressive Sizing**: Each grid level increases lot size to average down effectively.

### Hedge Protection System

**Purpose**: Protect against large drawdowns during adverse market moves

**Trigger Conditions**:
1. Buy P&L falls below `hedge_trigger` threshold
2. No existing hedge position
3. Trend strength indicates strong reversal

**Hedge Calculation**:
```python
hedge_lot = max(MIN_HEDGE_LOT, total_lot * HEDGE_RATIO)
hedge_lot = min(hedge_lot, HEDGE_MAX_LOT)
```

**Action**: Opens a SELL position to offset buy exposure

---

## Configuration

### Global Constants

```python
# Trading Symbol
SYMBOL = "GOLD.i#"          # Gold instrument

# Magic Number (identifies bot's trades)
MAGIC = 777

# Timeframe
TIMEFRAME = mt5.TIMEFRAME_M1  # 1-minute chart

# EMA Periods
EMA_FAST = 5
EMA_SLOW = 9

# Hedge Configuration
MIN_HEDGE_LOT = 0.01        # Minimum hedge size
HEDGE_RATIO = 0.5           # Hedge as % of total exposure
HEDGE_MAX_LOT = 1.0         # Maximum hedge size

# Grid Configuration
MIN_GRID_GAP = 0.5          # Minimum price gap (points)
LOT_MULTIPLIER = 1.0        # Lot size multiplier

# State Management
STATE_FILE = "bot_state.json"
```

### Adjustable Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `EMA_FAST` | 5 | Fast EMA period for trend detection |
| `EMA_SLOW` | 9 | Slow EMA period for trend detection |
| `MIN_GRID_GAP` | 0.5 | Minimum distance between grid levels |
| `HEDGE_RATIO` | 0.5 | Hedge size as ratio of total volume |
| `LOT_LADDER` | [0.01...0.04] | Progressive lot sizes for grid |

---

## Installation & Setup

### Prerequisites
```bash
# Python 3.8 or higher
python --version

# Required packages
pip install MetaTrader5
pip install numpy
pip install pandas
```

### Environment Setup

1. **Create `.env` file** or set environment variables:
```bash
export MT5_LOGIN=12345678
export MT5_PASSWORD="YourPassword"
export MT5_SERVER="YourBroker-Server"
```

2. **Verify MT5 Installation Path**:
```python
# Update path in init_mt5() if different
path=r"C:\Program Files\XM Global MT5\terminal64.exe"
```

3. **Configure Symbol**:
```python
# Verify your broker's gold symbol name
SYMBOL = "GOLD.i#"  # May be XAUUSD, GOLD, etc.
```

### First Run

```bash
# Test connection
python alogo_1.py

# Expected output:
# MT5 initialized successfully
# GoldAlgoBot started
# Positions=0 | PnL=0.00
```

---

## Usage

### Starting the Bot

```bash
python alogo_1.py
```

### Monitoring

**Console Output** (every 5 seconds):
```
2024-01-15 10:30:45 | INFO | Positions=3 | PnL=15.50
```

**Log Files**:
```bash
# View main log
tail -f gold_grid_bot.log

# View debug log
tail -f gold_grid_debug.log

# View errors
tail -f gold_grid_errors.log
```

### Stopping the Bot

```bash
# Graceful shutdown
Ctrl+C

# Bot will log: "Bot stopped by user"
```

### State Persistence

The bot saves its state to `bot_state.json`:
```json
{
  "lot_index": 3,
  "hedge_ticket": 12345678
}
```

This allows the bot to resume correctly after restart.

---

## Risk Management

### Built-in Safety Features

#### 1. Spread Check
```python
def spread_ok(max_spread=60):
    # Prevents trading during high spread conditions
    # Default: 60 points maximum spread
```

#### 2. Position Verification
```python
def verify_position_exists(ticket, retries=10):
    # Confirms position was opened successfully
    # Retries up to 10 times with 200ms delay
```

#### 3. Order Retry Logic
```python
def send_order_with_retry(request, attempts=3):
    # Retries failed orders up to 3 times
    # 200ms delay between attempts
```

#### 4. Equity Protection (Stub Functions)
- `equity_circuit_breaker()` - Emergency stop on large drawdown
- `equity_trailing_lock()` - Lock profits when threshold reached
- `daily_drawdown_guard()` - Daily loss limit protection

### Risk Parameters

| Risk Factor | Control Mechanism |
|-------------|-------------------|
| Maximum Positions | Limited by LOT_LADDER length (8 levels) |
| Maximum Lot Size | 0.04 (last ladder level) |
| Hedge Protection | Automatic at predefined thresholds |
| Spread Protection | Blocks trades when spread > 60 points |
| Connection Health | Checks MT5 connection before each cycle |

---

## Logging & Monitoring

### Log Levels

1. **DEBUG**: Detailed execution information
   - Function performance metrics
   - Market data updates
   - Position cache operations

2. **INFO**: Normal operational messages
   - Position counts and P&L
   - Trade executions
   - Bot lifecycle events

3. **WARNING**: Important events requiring attention
   - Hedge activations
   - Take profit hits
   - Spread warnings

4. **ERROR**: Recoverable errors
   - Failed order attempts
   - Missing tick data
   - State save failures

5. **CRITICAL**: Fatal errors
   - MT5 initialization failures
   - Unhandled exceptions

### Performance Monitoring

The `@monitor_performance` decorator tracks execution time:
```python
@monitor_performance
def get_positions(force=False):
    # Logs: "PERF | get_positions | 0.0023s"
```

### Trade Logging

Special trade log format:
```
TRADE | BUY_EXECUTED | lot=0.01 | price=2050.50 | ticket=12345678
TRADE | SELL_EXECUTED | lot=0.02 | price=2048.30 | ticket=12345679
```

---

## Troubleshooting

### Common Issues

#### 1. MT5 Connection Failed
```
Error: MT5 INIT FAILED | 10004 | Terminal not found
```
**Solution**: 
- Verify MT5 installation path
- Check MT5 is running
- Verify credentials in environment variables

#### 2. Symbol Not Found
```
Warning: BUY SKIPPED — No tick data
```
**Solution**:
- Check SYMBOL name matches your broker
- Ensure symbol is in Market Watch
- Verify trading hours

#### 3. Invalid Volume
```
Error: ORDER FAILED | retcode=10014
```
**Solution**:
- Check minimum lot size for symbol
- Verify account has sufficient margin
- Check symbol trading permissions

#### 4. High Spread Warning
```
Warning: Spread too high: 85 points
```
**Solution**:
- Wait for normal market conditions
- Adjust `max_spread` parameter if needed
- Avoid trading during news events

### Debug Mode

Enable detailed logging:
```python
# In ThrottledLogger.__init__
console_handler.setLevel(logging.DEBUG)
```

### Testing Without Real Trades

Comment out order execution:
```python
def buy(lot):
    # return False  # Disable real trading
    tick = mt5.symbol_info_tick(SYMBOL)
    # ... rest of code
```

---

## Advanced Features

### Adaptive Engine (Stub)
```python
def adaptive_engine():
    # Future: Dynamic parameter adjustment
    # - Adjust grid spacing based on volatility
    # - Modify lot sizes based on win rate
    # - Adapt to market regime changes
```

### Market Regime Detection (Stub)
```python
def update_market_regime_mode(df, atr, atr_mean):
    # Future: Detect market conditions
    # - Trending vs Ranging
    # - High vs Low volatility
    # - Adjust strategy accordingly
```

### Flat Trap Detector (Stub)
```python
def flat_trap_detector(df):
    # Future: Avoid false breakouts
    # - Detect consolidation patterns
    # - Prevent entries in choppy markets
```

---

## Performance Optimization

### Position Caching
- Reduces MT5 API calls
- 150ms cache duration
- Thread-safe implementation

### Log Throttling
- Prevents log spam
- Configurable intervals per message type
- Reduces I/O overhead

### Concurrent Operations
- Thread-safe locks for critical sections
- Queue-based trade management
- Parallel data processing capability

---

## Best Practices

### 1. Start with Demo Account
- Test thoroughly before live trading
- Verify all parameters work correctly
- Monitor for at least 1 week

### 2. Monitor Regularly
- Check logs daily
- Review trade history
- Analyze P&L patterns

### 3. Adjust Parameters Gradually
- Change one parameter at a time
- Test changes on demo first
- Document all modifications

### 4. Maintain Adequate Margin
- Keep 2x required margin minimum
- Monitor margin level regularly
- Set account alerts

### 5. Regular Backups
- Backup log files weekly
- Save state file regularly
- Document configuration changes

---

## Disclaimer

⚠️ **IMPORTANT**: This trading bot is provided for educational purposes only. 

- Trading involves substantial risk of loss
- Past performance does not guarantee future results
- Always test on demo accounts first
- Never risk more than you can afford to lose
- Consult with a financial advisor before live trading

---

## Support & Maintenance

### Log Analysis
```bash
# Count trades today
grep "TRADE" gold_grid_bot.log | grep "$(date +%Y-%m-%d)" | wc -l

# Check errors
grep "ERROR" gold_grid_errors.log | tail -20

# Monitor performance
grep "PERF" gold_grid_debug.log | tail -50
```

### Maintenance Tasks
- Weekly: Review and archive old logs
- Monthly: Analyze trading performance
- Quarterly: Update strategy parameters
- Annually: Review and optimize code

---

## Version History

**Current Version**: 1.0.0

### Features Implemented
✅ Grid trading strategy
✅ Dynamic hedging
✅ EMA trend detection
✅ ATR-based volatility adaptation
✅ Advanced logging system
✅ State persistence
✅ Thread-safe operations
✅ Performance monitoring

### Planned Features
🔄 Machine learning integration
🔄 Multi-symbol support
🔄 Web dashboard
🔄 Telegram notifications
🔄 Advanced risk management
🔄 Backtesting framework

---

## Contact & Contribution

For questions, issues, or contributions, please refer to the project repository.

**Happy Trading! 📈**