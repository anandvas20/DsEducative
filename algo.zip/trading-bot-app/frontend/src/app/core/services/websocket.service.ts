import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { io, Socket } from 'socket.io-client';

export interface PositionUpdate {
  positions: any[];
  timestamp: string;
}

export interface LogMessage {
  level: string;
  message: string;
  timestamp: string;
}

export interface PnLUpdate {
  total_pnl: number;
  buy_pnl: number;
  sell_pnl: number;
  timestamp: string;
}

@Injectable({
  providedIn: 'root'
})
export class WebsocketService {
  private socket: Socket | null = null;
  private connected = false;

  // Subjects for different event types
  private positionUpdates$ = new Subject<PositionUpdate>();
  private logMessages$ = new Subject<LogMessage>();
  private pnlUpdates$ = new Subject<PnLUpdate>();
  private botStatusChanges$ = new Subject<any>();
  private connectionStatus$ = new Subject<boolean>();

  constructor() {}

  connect(url: string = 'http://localhost:8000'): void {
    if (this.socket && this.connected) {
      console.log('WebSocket already connected');
      return;
    }

    this.socket = io(url, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionAttempts: 5
    });

    this.setupEventListeners();
  }

  private setupEventListeners(): void {
    if (!this.socket) return;

    this.socket.on('connect', () => {
      console.log('WebSocket connected');
      this.connected = true;
      this.connectionStatus$.next(true);
    });

    this.socket.on('disconnect', () => {
      console.log('WebSocket disconnected');
      this.connected = false;
      this.connectionStatus$.next(false);
    });

    this.socket.on('connection_response', (data: any) => {
      console.log('Connection response:', data);
    });

    this.socket.on('position_update', (data: PositionUpdate) => {
      this.positionUpdates$.next(data);
    });

    this.socket.on('log_message', (data: LogMessage) => {
      this.logMessages$.next(data);
    });

    this.socket.on('pnl_update', (data: PnLUpdate) => {
      this.pnlUpdates$.next(data);
    });

    this.socket.on('bot_status_change', (data: any) => {
      this.botStatusChanges$.next(data);
    });

    this.socket.on('connect_error', (error: any) => {
      console.error('WebSocket connection error:', error);
    });
  }

  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
      this.connected = false;
      this.connectionStatus$.next(false);
    }
  }

  // Subscribe to position updates
  subscribeToPositions(): void {
    if (this.socket && this.connected) {
      this.socket.emit('subscribe_positions', {});
    }
  }

  // Subscribe to log updates
  subscribeToLogs(): void {
    if (this.socket && this.connected) {
      this.socket.emit('subscribe_logs', {});
    }
  }

  // Subscribe to P&L updates
  subscribeToPnL(): void {
    if (this.socket && this.connected) {
      this.socket.emit('subscribe_pnl', {});
    }
  }

  // Observable streams
  getPositionUpdates(): Observable<PositionUpdate> {
    return this.positionUpdates$.asObservable();
  }

  getLogMessages(): Observable<LogMessage> {
    return this.logMessages$.asObservable();
  }

  getPnLUpdates(): Observable<PnLUpdate> {
    return this.pnlUpdates$.asObservable();
  }

  getBotStatusChanges(): Observable<any> {
    return this.botStatusChanges$.asObservable();
  }

  getConnectionStatus(): Observable<boolean> {
    return this.connectionStatus$.asObservable();
  }

  isConnected(): boolean {
    return this.connected;
  }
}

// Made with Bob
