#!/usr/bin/env python3
"""
Live XAU/USD Trading Signal Generator
Gets real-time trading recommendation from Gemini AI considering news and market conditions
"""

import sys
import json
import time
from datetime import datetime

try:
    from google import genai
    GEMINI_AVAILABLE = True
except ImportError:
    print("❌ google-genai package is NOT installed")
    print("   Install it with: pip install google-genai")
    sys.exit(1)

# Configuration
GEMINI_API_KEY = "AQ.Ab8RN6L0AQS87ZzRnJ6ZSGwt12TCSE-8b7eRYgtdJahtCOGOyg"
GEMINI_MODEL = "gemini-3.1-flash-lite"

def get_live_trading_signal():
    """Get live trading signal from Gemini AI considering news and market conditions"""
    
    # Get current date and time
    now = datetime.now()
    current_date = now.strftime("%Y-%m-%d")
    current_time = now.strftime("%H:%M:%S")
    day_of_week = now.strftime("%A")
    
    print("\n" + "="*80)
    print("🔴 LIVE XAU/USD TRADING SIGNAL REQUEST")
    print("="*80)
    print(f"📅 Date: {current_date} ({day_of_week})")
    print(f"⏰ Time: {current_time} IST")
    print(f"🤖 AI Model: {GEMINI_MODEL}")
    print("="*80)
    
    # Create comprehensive prompt for live trading - Let Gemini fetch live data
    prompt = f"""
You are a professional gold (XAU/USD) trading expert with deep knowledge of fundamental analysis, technical analysis, and market sentiment.

TODAY'S DATE: {current_date} ({day_of_week})
CURRENT TIME: {current_time} IST (Asia/Calcutta)

CRITICAL: You MUST fetch and use REAL-TIME live data for:
1. Current XAU/USD spot price (as of {current_time} IST on {current_date})
2. Today's actual economic calendar events and their scheduled times
3. Recent price action and current market sentiment
4. Latest geopolitical developments affecting gold

DO NOT use historical or hypothetical data. Access your real-time information to provide accurate, current market analysis.

TASK: Provide a live trading recommendation for XAU/USD (Gold) based on ACTUAL REAL-TIME data you fetch right now, considering:

1. CURRENT LIVE PRICE & MOVEMENT:
   - What is the ACTUAL current XAU/USD price right now?
   - Recent price movement (last 1 hour, 4 hours, 24 hours)
   - Current intraday high and low

2. TODAY'S ACTUAL ECONOMIC NEWS & EVENTS:
   - What economic data releases are ACTUALLY scheduled for today {current_date}?
   - Exact times of these events (in GMT/EST)
   - Any FOMC, Fed speeches, or central bank announcements TODAY
   - Current geopolitical events affecting gold RIGHT NOW
   - Actual USD strength/weakness based on DXY movement today

3. REAL-TIME MARKET CONDITIONS:
   - Current live trend (bullish/bearish/sideways) based on actual price action
   - Actual support and resistance levels based on recent price behavior
   - Current trading session (Asian/European/US) and its actual volatility
   - Real-time market sentiment (risk-on vs risk-off)

4. LIVE TECHNICAL ANALYSIS:
   - Current RSI reading (if available from real-time data)
   - MACD status based on recent price movement
   - Moving averages alignment (actual current values)
   - Recent candlestick patterns

5. ACTUAL RISK FACTORS RIGHT NOW:
   - Is there high-impact news scheduled in the next few hours?
   - Current spread conditions
   - Actual liquidity in current session
   - Real volatility levels right now

Return your analysis in this JSON format with ACTUAL CURRENT VALUES:
{{
  "current_price": "ACTUAL live XAU/USD price you fetched",
  "price_movement_1h": "actual % change last 1 hour",
  "price_movement_24h": "actual % change last 24 hours",
  "signal": "BUY|SELL|HOLD",
  "confidence": 0-100,
  "position_size": "FULL|HALF|QUARTER|AVOID",
  "entry_zone": "price range based on current price",
  "stop_loss": "recommended stop loss level",
  "take_profit_1": "first target",
  "take_profit_2": "second target",
  "news_impact": "HIGH|MEDIUM|LOW",
  "news_events": ["ACTUAL news events scheduled TODAY with exact times"],
  "best_entry_time": "recommended time window based on actual news schedule",
  "risk_level": "HIGH|MEDIUM|LOW",
  "session_analysis": "ACTUAL current session characteristics",
  "key_levels": {{
    "resistance": ["actual resistance levels based on recent price"],
    "support": ["actual support levels based on recent price"]
  }},
  "market_sentiment": "current actual market sentiment",
  "reason": "comprehensive explanation using REAL current data, news impact, technical setup, and risk factors",
  "warnings": ["specific warnings based on ACTUAL scheduled events today"],
  "data_timestamp": "when you fetched this data"
}}

REMEMBER: Use ONLY real-time, current, live data. Do not make assumptions or use historical patterns. Fetch actual current market conditions for {current_date} at {current_time} IST.
"""
    
    try:
        print("\n📤 Sending request to Gemini AI...")
        print("⏳ Analyzing current market conditions and news...")
        
        # Initialize client
        client = genai.Client(api_key=GEMINI_API_KEY)
        
        # Call Gemini API
        start_time = time.time()
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt
        )
        elapsed_time = time.time() - start_time
        
        if response and response.text:
            response_text = response.text.strip()
            
            # Remove markdown code blocks and extract JSON
            cleaned_response = response_text
            
            # Handle case where response has text before JSON
            if "```json" in cleaned_response:
                # Extract content between ```json and ```
                parts = cleaned_response.split("```json")
                if len(parts) > 1:
                    json_part = parts[1].split("```")[0]
                    cleaned_response = json_part.strip()
            elif cleaned_response.startswith("```"):
                cleaned_response = cleaned_response.split("```")[1]
                if cleaned_response.startswith("json"):
                    cleaned_response = cleaned_response[4:]
                cleaned_response = cleaned_response.strip()
            
            # Try to find JSON object if there's text before it
            if not cleaned_response.startswith("{"):
                # Look for first { and last }
                start_idx = cleaned_response.find("{")
                end_idx = cleaned_response.rfind("}")
                if start_idx != -1 and end_idx != -1:
                    cleaned_response = cleaned_response[start_idx:end_idx+1]
            
            # Parse JSON
            result = json.loads(cleaned_response)
            
            print(f"\n✅ Response received in {elapsed_time:.2f}s")
            print("\n" + "="*80)
            print("📊 LIVE TRADING SIGNAL FOR XAU/USD")
            print("="*80)
            
            # Display signal
            signal_emoji = "🟢" if result['signal'] == "BUY" else "🔴" if result['signal'] == "SELL" else "🟡"
            print(f"\n{signal_emoji} SIGNAL: {result['signal']}")
            print(f"📈 CONFIDENCE: {result['confidence']}%")
            print(f"💰 POSITION SIZE: {result['position_size']}")
            print(f"⚠️  RISK LEVEL: {result['risk_level']}")
            print(f"📰 NEWS IMPACT: {result['news_impact']}")
            
            print(f"\n📍 ENTRY ZONE: {result['entry_zone']}")
            print(f"🛑 STOP LOSS: {result['stop_loss']}")
            print(f"🎯 TAKE PROFIT 1: {result['take_profit_1']}")
            print(f"🎯 TAKE PROFIT 2: {result['take_profit_2']}")
            
            print(f"\n⏰ BEST ENTRY TIME: {result['best_entry_time']}")
            print(f"🌍 SESSION: {result['session_analysis']}")
            
            if result.get('news_events'):
                print(f"\n📰 TODAY'S NEWS EVENTS:")
                for event in result['news_events']:
                    print(f"   • {event}")
            
            if result.get('key_levels'):
                print(f"\n📊 KEY LEVELS:")
                if result['key_levels'].get('resistance'):
                    print(f"   Resistance: {', '.join(map(str, result['key_levels']['resistance']))}")
                if result['key_levels'].get('support'):
                    print(f"   Support: {', '.join(map(str, result['key_levels']['support']))}")
            
            print(f"\n💡 ANALYSIS:")
            print(f"   {result['reason']}")
            
            if result.get('warnings'):
                print(f"\n⚠️  WARNINGS:")
                for warning in result['warnings']:
                    print(f"   • {warning}")
            
            print("\n" + "="*80)
            print("✅ SIGNAL GENERATED SUCCESSFULLY")
            print("="*80)
            
            # Save to file
            output_file = f"live_signal_{current_date}_{now.strftime('%H%M%S')}.json"
            with open(output_file, 'w') as f:
                json.dump({
                    'timestamp': now.isoformat(),
                    'date': current_date,
                    'time': current_time,
                    'signal': result
                }, f, indent=2)
            
            print(f"\n💾 Signal saved to: {output_file}")
            
            return True
            
        else:
            print("❌ API returned empty response")
            return False
            
    except json.JSONDecodeError as e:
        print(f"\n❌ JSON PARSING FAILED: {e}")
        print("   Raw response:")
        print(response_text)
        return False
        
    except Exception as e:
        print(f"\n❌ ERROR: {type(e).__name__}")
        print(f"   Message: {str(e)}")
        
        if "429" in str(e) or "RESOURCE_EXHAUSTED" in str(e):
            print("\n💡 Rate limit hit. Wait a few minutes and try again.")
        
        return False

if __name__ == "__main__":
    print("\n🚀 XAU/USD Live Trading Signal Generator")
    print("   Powered by Gemini AI")
    print("   Analyzing news, market conditions, and technical factors...")
    
    success = get_live_trading_signal()
    
    if success:
        print("\n✅ Done! Use this signal with caution and proper risk management.")
        print("⚠️  Always verify with your own analysis before trading.")
        sys.exit(0)
    else:
        print("\n❌ Failed to generate signal. Please try again.")
        sys.exit(1)

# Made with Bob
