# 🚀 Quick Start Guide

Get your Trading Bot Management App running in 5 minutes!

## Step 1: Backend Setup (2 minutes)

```bash
# Navigate to project
cd trading-bot-app

# Create Python virtual environment
cd backend
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your MT5 credentials (optional for testing)

# Start backend
cd app
python main.py
```

✅ Backend running at: http://localhost:8000
📚 API docs at: http://localhost:8000/docs

## Step 2: Frontend Setup (3 minutes)

### Option A: Quick Setup (Recommended)

```bash
# In a new terminal, navigate to project
cd trading-bot-app/frontend

# Create Angular app
ng new trading-bot-frontend --routing --style=scss --skip-git
cd trading-bot-frontend

# Install dependencies
npm install socket.io-client chart.js ng2-charts @angular/material @angular/cdk

# Create basic structure
ng generate service core/services/api
ng generate service core/services/websocket
ng generate component features/dashboard
ng generate component features/bot-control
ng generate component features/positions

# Start frontend
ng serve --open
```

### Option B: Use Pre-built Frontend (Coming Soon)

```bash
cd trading-bot-app/frontend
npm install
npm start
```

✅ Frontend running at: http://localhost:4200

## Step 3: Test the App

1. **Open browser**: http://localhost:4200
2. **Check API**: http://localhost:8000/docs
3. **Test bot control**: Start/Stop buttons in UI
4. **View positions**: Real-time position updates

## 🎯 What You Can Do Now

### Via API (http://localhost:8000/docs)

1. **Start BUY Bot**
   - POST `/api/bots/buy/start`

2. **Check Bot Status**
   - GET `/api/bots/status`

3. **View Positions**
   - GET `/api/positions/live`

4. **Get Analytics**
   - GET `/api/analytics/performance`

5. **Close All Positions**
   - POST `/api/positions/close-all`

### Via UI (http://localhost:4200)

1. **Dashboard**: View real-time P&L and metrics
2. **Bot Control**: Start/Stop bots with one click
3. **Positions**: Monitor and close positions
4. **Analytics**: View performance charts
5. **Settings**: Configure bot parameters

## 🔧 Troubleshooting

### Backend Issues

**Problem**: `ModuleNotFoundError: No module named 'fastapi'`
```bash
# Solution: Activate virtual environment
source backend/venv/bin/activate
pip install -r backend/requirements.txt
```

**Problem**: `MT5 initialization failed`
```bash
# Solution: Ensure MT5 is running and credentials are correct
# Edit backend/.env with your MT5 login details
```

### Frontend Issues

**Problem**: `ng: command not found`
```bash
# Solution: Install Angular CLI globally
npm install -g @angular/cli
```

**Problem**: `Cannot connect to backend`
```bash
# Solution: Ensure backend is running on port 8000
# Check CORS settings in backend/app/main.py
```

## 📱 Using the App

### 1. Start Trading Bots

```bash
# Via API
curl -X POST http://localhost:8000/api/bots/buy/start

# Via UI
Click "Start BUY Bot" button in Bot Control panel
```

### 2. Monitor Positions

```bash
# Via API
curl http://localhost:8000/api/positions/live

# Via UI
Navigate to "Positions" tab to see real-time updates
```

### 3. View Analytics

```bash
# Via API
curl http://localhost:8000/api/analytics/performance

# Via UI
Navigate to "Analytics" tab for charts and metrics
```

### 4. Emergency Stop

```bash
# Via API
curl -X POST http://localhost:8000/api/positions/close-all

# Via UI
Click "Close All Positions" button (red button)
```

## 🎨 Customization

### Change Bot Parameters

Edit `backend/app/core/config.py`:
```python
# Lot sizes
LOT_LADDER = [0.01, 0.02, 0.04, 0.06, 0.08]

# Grid spacing
MIN_GRID_GAP = 5.0

# Max positions
MAX_BUY_POSITIONS = 9
```

### Change UI Theme

Edit `frontend/trading-bot-frontend/src/styles.scss`:
```scss
$primary-color: #2196F3;
$accent-color: #FF9800;
$background-color: #1E1E1E;
```

## 📊 Next Steps

1. **Add Authentication**: Implement JWT auth for security
2. **Database Integration**: Store trade history in PostgreSQL
3. **Mobile App**: Create React Native mobile version
4. **Alerts**: Add email/SMS notifications
5. **Backtesting**: Add historical data testing

## 🆘 Need Help?

- **Documentation**: See README.md for detailed info
- **API Docs**: http://localhost:8000/docs
- **Issues**: Check logs in `backend/app/` directory
- **Community**: Open a GitHub issue

## 🎉 You're All Set!

Your trading bot management app is now running. Happy trading! 📈

---

**Pro Tip**: Keep both terminal windows open - one for backend, one for frontend. Monitor logs for any issues.