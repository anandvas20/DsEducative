"""
Bot control API routes with template configuration support
"""

from fastapi import APIRouter, HTTPException
from typing import Dict, List
from app.core.bot_manager import bot_manager
from app.models.schemas import BotStatus, BotControlResponse, SuccessResponse

router = APIRouter()


@router.get("/", response_model=List[BotStatus])
async def get_all_bots() -> List[BotStatus]:
    """Get status of all bots"""
    status = bot_manager.get_bot_status()
    return [
        BotStatus(
            bot_id="buy",
            status=status["buy_bot"]["status"],
            uptime=status["buy_bot"].get("uptime"),
            last_trade=status["buy_bot"].get("last_trade"),
            active_positions=status["buy_bot"].get("active_positions", 0),
            template_id=status["buy_bot"].get("template_id")
        ),
        BotStatus(
            bot_id="sell",
            status=status["sell_bot"]["status"],
            uptime=status["sell_bot"].get("uptime"),
            last_trade=status["sell_bot"].get("last_trade"),
            active_positions=status["sell_bot"].get("active_positions", 0),
            template_id=status["sell_bot"].get("template_id")
        )
    ]


@router.get("/{bot_id}", response_model=BotStatus)
async def get_bot(bot_id: str) -> BotStatus:
    """Get status of a specific bot"""
    if bot_id not in ["buy", "sell"]:
        raise HTTPException(status_code=400, detail="bot_id must be 'buy' or 'sell'")
    
    status = bot_manager.get_bot_status()
    bot_status = status[f"{bot_id}_bot"]
    
    return BotStatus(
        bot_id=bot_id,
        status=bot_status["status"],
        uptime=bot_status.get("uptime"),
        last_trade=bot_status.get("last_trade"),
        active_positions=bot_status.get("active_positions", 0),
        template_id=bot_status.get("template_id")
    )


@router.post("/{bot_id}/start", response_model=BotControlResponse)
async def start_bot(bot_id: str) -> BotControlResponse:
    """Start a bot"""
    if bot_id not in ["buy", "sell"]:
        raise HTTPException(status_code=400, detail="bot_id must be 'buy' or 'sell'")
    
    if bot_id == "buy":
        result = bot_manager.start_buy_bot()
    else:
        result = bot_manager.start_sell_bot()
    
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    
    # Get updated status
    status = bot_manager.get_bot_status()
    bot_status = status[f"{bot_id}_bot"]
    
    return BotControlResponse(
        success=True,
        message=result["message"],
        bot_status=BotStatus(
            bot_id=bot_id,
            status=bot_status["status"],
            uptime=bot_status.get("uptime"),
            last_trade=bot_status.get("last_trade"),
            active_positions=bot_status.get("active_positions", 0),
            template_id=bot_status.get("template_id")
        )
    )


@router.post("/{bot_id}/stop", response_model=BotControlResponse)
async def stop_bot(bot_id: str) -> BotControlResponse:
    """Stop a bot"""
    if bot_id not in ["buy", "sell"]:
        raise HTTPException(status_code=400, detail="bot_id must be 'buy' or 'sell'")
    
    if bot_id == "buy":
        result = bot_manager.stop_buy_bot()
    else:
        result = bot_manager.stop_sell_bot()
    
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    
    # Get updated status
    status = bot_manager.get_bot_status()
    bot_status = status[f"{bot_id}_bot"]
    
    return BotControlResponse(
        success=True,
        message=result["message"],
        bot_status=BotStatus(
            bot_id=bot_id,
            status=bot_status["status"],
            uptime=bot_status.get("uptime"),
            last_trade=bot_status.get("last_trade"),
            active_positions=bot_status.get("active_positions", 0),
            template_id=bot_status.get("template_id")
        )
    )


@router.post("/{bot_id}/restart", response_model=BotControlResponse)
async def restart_bot(bot_id: str) -> BotControlResponse:
    """Restart a bot"""
    if bot_id not in ["buy", "sell"]:
        raise HTTPException(status_code=400, detail="bot_id must be 'buy' or 'sell'")
    
    if bot_id == "buy":
        result = bot_manager.restart_buy_bot()
    else:
        result = bot_manager.restart_sell_bot()
    
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    
    # Get updated status
    status = bot_manager.get_bot_status()
    bot_status = status[f"{bot_id}_bot"]
    
    return BotControlResponse(
        success=True,
        message=result["message"],
        bot_status=BotStatus(
            bot_id=bot_id,
            status=bot_status["status"],
            uptime=bot_status.get("uptime"),
            last_trade=bot_status.get("last_trade"),
            active_positions=bot_status.get("active_positions", 0),
            template_id=bot_status.get("template_id")
        )
    )


@router.post("/stop-all", response_model=SuccessResponse)
async def stop_all_bots() -> SuccessResponse:
    """Stop all bots"""
    buy_result = bot_manager.stop_buy_bot()
    sell_result = bot_manager.stop_sell_bot()
    
    return SuccessResponse(
        success=True,
        message="All bots stopped",
        data={
            "buy_bot": buy_result,
            "sell_bot": sell_result
        }
    )


@router.get("/status", response_model=Dict)
async def get_bot_status() -> Dict:
    """Get detailed status of all bots (legacy endpoint)"""
    return bot_manager.get_bot_status()


# Legacy endpoints for backward compatibility
@router.post("/buy/start")
async def start_buy_bot() -> Dict:
    """Start the BUY bot (legacy endpoint)"""
    result = bot_manager.start_buy_bot()
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/buy/stop")
async def stop_buy_bot() -> Dict:
    """Stop the BUY bot (legacy endpoint)"""
    result = bot_manager.stop_buy_bot()
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/buy/restart")
async def restart_buy_bot() -> Dict:
    """Restart the BUY bot (legacy endpoint)"""
    result = bot_manager.restart_buy_bot()
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/sell/start")
async def start_sell_bot() -> Dict:
    """Start the SELL bot (legacy endpoint)"""
    result = bot_manager.start_sell_bot()
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/sell/stop")
async def stop_sell_bot() -> Dict:
    """Stop the SELL bot (legacy endpoint)"""
    result = bot_manager.stop_sell_bot()
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    return result


@router.post("/sell/restart")
async def restart_sell_bot() -> Dict:
    """Restart the SELL bot (legacy endpoint)"""
    result = bot_manager.restart_sell_bot()
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    return result


# Made with Bob
