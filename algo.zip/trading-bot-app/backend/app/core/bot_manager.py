"""
Bot Manager - Controls trading bot processes
"""

import subprocess
import psutil
import signal
import os
from typing import Optional, Dict
from datetime import datetime
import json


class BotManager:
    """Manages trading bot processes"""
    
    def __init__(self):
        self.buy_bot_process: Optional[subprocess.Popen] = None
        self.sell_bot_process: Optional[subprocess.Popen] = None
        self.buy_bot_path = os.path.abspath("../../algo_withouthedge.py")
        self.sell_bot_path = os.path.abspath("../../algo_withouthedge_sell.py")
        
    def start_buy_bot(self) -> Dict:
        """Start the BUY bot"""
        if self.buy_bot_process and self.buy_bot_process.poll() is None:
            return {
                "status": "error",
                "message": "BUY bot is already running",
                "pid": self.buy_bot_process.pid
            }
        
        try:
            self.buy_bot_process = subprocess.Popen(
                ["python3", self.buy_bot_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            return {
                "status": "success",
                "message": "BUY bot started successfully",
                "pid": self.buy_bot_process.pid,
                "started_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "error",
                "message": f"Failed to start BUY bot: {str(e)}"
            }
    
    def stop_buy_bot(self) -> Dict:
        """Stop the BUY bot"""
        if not self.buy_bot_process or self.buy_bot_process.poll() is not None:
            return {
                "status": "error",
                "message": "BUY bot is not running"
            }
        
        try:
            # Graceful shutdown
            self.buy_bot_process.terminate()
            self.buy_bot_process.wait(timeout=10)
            
            return {
                "status": "success",
                "message": "BUY bot stopped successfully",
                "stopped_at": datetime.now().isoformat()
            }
        except subprocess.TimeoutExpired:
            # Force kill if graceful shutdown fails
            self.buy_bot_process.kill()
            return {
                "status": "success",
                "message": "BUY bot force stopped",
                "stopped_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "error",
                "message": f"Failed to stop BUY bot: {str(e)}"
            }
    
    def start_sell_bot(self) -> Dict:
        """Start the SELL bot"""
        if self.sell_bot_process and self.sell_bot_process.poll() is None:
            return {
                "status": "error",
                "message": "SELL bot is already running",
                "pid": self.sell_bot_process.pid
            }
        
        try:
            self.sell_bot_process = subprocess.Popen(
                ["python3", self.sell_bot_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            return {
                "status": "success",
                "message": "SELL bot started successfully",
                "pid": self.sell_bot_process.pid,
                "started_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "error",
                "message": f"Failed to start SELL bot: {str(e)}"
            }
    
    def stop_sell_bot(self) -> Dict:
        """Stop the SELL bot"""
        if not self.sell_bot_process or self.sell_bot_process.poll() is not None:
            return {
                "status": "error",
                "message": "SELL bot is not running"
            }
        
        try:
            # Graceful shutdown
            self.sell_bot_process.terminate()
            self.sell_bot_process.wait(timeout=10)
            
            return {
                "status": "success",
                "message": "SELL bot stopped successfully",
                "stopped_at": datetime.now().isoformat()
            }
        except subprocess.TimeoutExpired:
            # Force kill if graceful shutdown fails
            self.sell_bot_process.kill()
            return {
                "status": "success",
                "message": "SELL bot force stopped",
                "stopped_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "error",
                "message": f"Failed to stop SELL bot: {str(e)}"
            }
    
    def get_bot_status(self) -> Dict:
        """Get status of both bots with template information"""
        buy_running = self.buy_bot_process and self.buy_bot_process.poll() is None
        sell_running = self.sell_bot_process and self.sell_bot_process.poll() is None
        
        # Load configuration to get template assignments
        template_id_buy = None
        template_id_sell = None
        try:
            if os.path.exists("bot_config.json"):
                with open("bot_config.json", 'r') as f:
                    config = json.load(f)
                    assignments = config.get("assignments", {})
                    template_id_buy = assignments.get("buy_bot_template")
                    template_id_sell = assignments.get("sell_bot_template")
        except:
            pass
        
        status = {
            "buy_bot": {
                "status": "running" if buy_running else "stopped",
                "running": buy_running,
                "pid": self.buy_bot_process.pid if buy_running else None,
                "template_id": template_id_buy,
                "uptime": None,
                "last_trade": None,
                "active_positions": 0
            },
            "sell_bot": {
                "status": "running" if sell_running else "stopped",
                "running": sell_running,
                "pid": self.sell_bot_process.pid if sell_running else None,
                "template_id": template_id_sell,
                "uptime": None,
                "last_trade": None,
                "active_positions": 0
            }
        }
        
        # Add CPU and memory usage if running
        if buy_running:
            try:
                process = psutil.Process(self.buy_bot_process.pid)
                status["buy_bot"]["cpu_percent"] = process.cpu_percent()
                status["buy_bot"]["memory_mb"] = process.memory_info().rss / 1024 / 1024
                # Calculate uptime
                create_time = process.create_time()
                status["buy_bot"]["uptime"] = int(datetime.now().timestamp() - create_time)
            except:
                pass
        
        if sell_running:
            try:
                process = psutil.Process(self.sell_bot_process.pid)
                status["sell_bot"]["cpu_percent"] = process.cpu_percent()
                status["sell_bot"]["memory_mb"] = process.memory_info().rss / 1024 / 1024
                # Calculate uptime
                create_time = process.create_time()
                status["sell_bot"]["uptime"] = int(datetime.now().timestamp() - create_time)
            except:
                pass
        
        return status
    
    def restart_buy_bot(self) -> Dict:
        """Restart the BUY bot"""
        stop_result = self.stop_buy_bot()
        if stop_result["status"] == "error" and "not running" not in stop_result["message"]:
            return stop_result
        
        return self.start_buy_bot()
    
    def restart_sell_bot(self) -> Dict:
        """Restart the SELL bot"""
        stop_result = self.stop_sell_bot()
        if stop_result["status"] == "error" and "not running" not in stop_result["message"]:
            return stop_result
        
        return self.start_sell_bot()


# Global bot manager instance
bot_manager = BotManager()

# Made with Bob
