import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService, AccountInfo, BotStatus } from '../../core/services/api.service';
import { WebsocketService } from '../../core/services/websocket.service';
import { Subscription, interval } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
  accountInfo: AccountInfo | null = null;
  botStatus: BotStatus | null = null;
  positionsSummary: any = null;
  performanceMetrics: any = null;
  
  totalPnL = 0;
  buyPnL = 0;
  sellPnL = 0;
  
  loading = true;
  error: string | null = null;
  
  private subscriptions: Subscription[] = [];
  private refreshInterval: any;

  constructor(
    private apiService: ApiService,
    private websocketService: WebsocketService
  ) {}

  ngOnInit(): void {
    this.loadDashboardData();
    this.setupWebSocketSubscriptions();
    this.setupAutoRefresh();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(sub => sub.unsubscribe());
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval);
    }
  }

  loadDashboardData(): void {
    this.loading = true;
    this.error = null;

    // Load account info
    this.apiService.getAccountInfo().subscribe({
      next: (data) => {
        this.accountInfo = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading account info:', err);
        this.error = 'Failed to load account information';
        this.loading = false;
      }
    });

    // Load bot status
    this.apiService.getBotStatus().subscribe({
      next: (data) => {
        this.botStatus = data;
      },
      error: (err) => {
        console.error('Error loading bot status:', err);
      }
    });

    // Load positions summary
    this.apiService.getPositionsSummary().subscribe({
      next: (data) => {
        this.positionsSummary = data;
        this.totalPnL = data.total_profit || 0;
        this.buyPnL = data.buy_profit || 0;
        this.sellPnL = data.sell_profit || 0;
      },
      error: (err) => {
        console.error('Error loading positions summary:', err);
      }
    });

    // Load performance metrics
    this.apiService.getPerformanceMetrics(7).subscribe({
      next: (data) => {
        this.performanceMetrics = data;
      },
      error: (err) => {
        console.error('Error loading performance metrics:', err);
      }
    });
  }

  setupWebSocketSubscriptions(): void {
    // Subscribe to P&L updates
    const pnlSub = this.websocketService.getPnLUpdates().subscribe({
      next: (data) => {
        this.totalPnL = data.total_pnl;
        this.buyPnL = data.buy_pnl;
        this.sellPnL = data.sell_pnl;
      }
    });
    this.subscriptions.push(pnlSub);

    // Subscribe to bot status changes
    const botSub = this.websocketService.getBotStatusChanges().subscribe({
      next: (data) => {
        this.loadBotStatus();
      }
    });
    this.subscriptions.push(botSub);

    // Subscribe to WebSocket events
    if (this.websocketService.isConnected()) {
      this.websocketService.subscribeToPnL();
    }
  }

  setupAutoRefresh(): void {
    // Refresh data every 30 seconds
    this.refreshInterval = setInterval(() => {
      this.loadDashboardData();
    }, 30000);
  }

  loadBotStatus(): void {
    this.apiService.getBotStatus().subscribe({
      next: (data) => {
        this.botStatus = data;
      },
      error: (err) => {
        console.error('Error loading bot status:', err);
      }
    });
  }

  refresh(): void {
    this.loadDashboardData();
  }

  getPnLClass(value: number): string {
    if (value > 0) return 'positive';
    if (value < 0) return 'negative';
    return 'neutral';
  }

  getBotStatusClass(running: boolean): string {
    return running ? 'running' : 'stopped';
  }

  getBotStatusText(running: boolean): string {
    return running ? 'Running' : 'Stopped';
  }
}

// Made with Bob
