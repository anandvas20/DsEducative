"""
Gemini AI Service - Provides AI-powered trading signals
Implements background threading, rate limiting, and caching
"""

import json
import time
import threading
from typing import Optional, Dict, Any
from datetime import datetime
import logging

try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

from ..core.config import settings


logger = logging.getLogger(__name__)


class GeminiService:
    """
    Gemini AI service for trading signal generation
    Uses background threading to avoid blocking main trading logic
    """
    
    def __init__(self, api_key: str, model: str = "gemini-2.0-flash-exp"):
        self.api_key = api_key
        self.model = model
        self.enabled = GEMINI_AVAILABLE and bool(api_key)
        
        # Cache for AI responses
        self.cache = {
            'buy': {
                'data': None,
                'timestamp': 0,
                'is_valid': False
            },
            'sell': {
                'data': None,
                'timestamp': 0,
                'is_valid': False
            }
        }
        
        # Rate limiting tracker
        self.rate_limit_tracker = {
            'error_count': 0,
            'last_error_time': 0,
            'in_cooldown': False,
            'cooldown_until': 0,
            'last_update_attempt': 0
        }
        
        # Threading
        self.thread_lock = threading.Lock()
        self.background_thread = None
        self.thread_running = False
        
        # Configuration
        self.update_interval = 60  # Update every 60 seconds
        self.max_retries = 3
        self.retry_delay = 5
        self.cooldown_duration = 300  # 5 minutes cooldown on rate limit
        self.cache_max_age = 120  # Warn if cache older than 2 minutes
        
        if not self.enabled:
            logger.warning("Gemini AI not available or API key not configured")
        else:
            logger.info(f"Gemini AI service initialized with model: {self.model}")
    
    def start_background_updater(self):
        """Start the background thread for cache updates"""
        if not self.enabled:
            logger.info("Gemini AI disabled. Background updater not started.")
            return
        
        if self.background_thread and self.background_thread.is_alive():
            logger.warning("Gemini background updater already running")
            return
        
        self.thread_running = True
        self.background_thread = threading.Thread(
            target=self._background_updater,
            daemon=True,
            name="GeminiBackgroundUpdater"
        )
        self.background_thread.start()
        logger.info("Gemini AI background updater started")
    
    def stop_background_updater(self):
        """Stop the background updater thread"""
        if not self.background_thread or not self.background_thread.is_alive():
            return
        
        logger.info("Stopping Gemini AI background updater...")
        self.thread_running = False
        self.background_thread.join(timeout=5)
        logger.info("Gemini AI background updater stopped")
    
    def _background_updater(self):
        """Background thread that periodically updates AI cache"""
        logger.info("Gemini AI background updater thread started")
        
        while self.thread_running:
            try:
                # Check cooldown status
                with self.thread_lock:
                    if self.rate_limit_tracker['in_cooldown']:
                        remaining = self.rate_limit_tracker['cooldown_until'] - time.time()
                        if remaining > 0:
                            logger.debug(f"Gemini API in cooldown. Remaining: {int(remaining)}s")
                            time.sleep(self.update_interval)
                            continue
                        else:
                            # Cooldown ended
                            self.rate_limit_tracker['in_cooldown'] = False
                            self.rate_limit_tracker['error_count'] = 0
                            logger.info("Gemini API cooldown period ended")
                
                # Update both BUY and SELL caches
                # In production, you would fetch real market data here
                # For now, we'll just mark the service as ready
                
                time.sleep(self.update_interval)
                
            except Exception as e:
                logger.error(f"Error in Gemini background updater: {e}", exc_info=True)
                time.sleep(30)
        
        logger.info("Gemini AI background updater thread stopped")
    
    def get_trading_signal(self, bot_type: str, market_data: Dict[str, Any]) -> Optional[Dict]:
        """
        Get trading signal from cache (non-blocking)
        
        Args:
            bot_type: 'buy' or 'sell'
            market_data: Current market data with indicators
            
        Returns:
            Dict with AI analysis or None if not available
        """
        if not self.enabled:
            return None
        
        if bot_type not in ['buy', 'sell']:
            logger.error(f"Invalid bot_type: {bot_type}")
            return None
        
        with self.thread_lock:
            cache_entry = self.cache[bot_type]
            
            if not cache_entry['is_valid']:
                return None
            
            # Check cache age
            cache_age = time.time() - cache_entry['timestamp']
            
            if cache_age > self.cache_max_age:
                logger.warning(f"AI cache for {bot_type} is stale ({int(cache_age)}s old)")
            
            return cache_entry['data']
    
    def update_cache(self, bot_type: str, market_data: Dict[str, Any]) -> bool:
        """
        Update AI cache with fresh analysis (can be called from background thread)
        
        Args:
            bot_type: 'buy' or 'sell'
            market_data: Market data with indicators
            
        Returns:
            True if successful, False otherwise
        """
        if not self.enabled:
            return False
        
        if bot_type not in ['buy', 'sell']:
            return False
        
        # Check cooldown
        now = time.time()
        with self.thread_lock:
            if self.rate_limit_tracker['in_cooldown']:
                if now < self.rate_limit_tracker['cooldown_until']:
                    return False
        
        # Prepare prompt
        prompt = self._prepare_prompt(bot_type, market_data)
        
        # Call Gemini API with retry logic
        for attempt in range(self.max_retries):
            try:
                client = genai.Client(api_key=self.api_key)
                
                response = client.models.generate_content(
                    model=self.model,
                    contents=prompt
                )
                
                # Parse response
                response_text = response.text.strip()
                
                # Remove markdown code blocks if present
                if "```json" in response_text:
                    parts = response_text.split("```json")
                    if len(parts) > 1:
                        json_part = parts[1].split("```")[0]
                        response_text = json_part.strip()
                elif response_text.startswith("```"):
                    response_text = response_text.split("```")[1]
                    if response_text.startswith("json"):
                        response_text = response_text[4:]
                    response_text = response_text.strip()
                
                result = json.loads(response_text)
                
                # Validate response
                required_keys = ["entry_decision", "market_context", "entry_timing", "position_sizing"]
                if not all(key in result for key in required_keys):
                    logger.error(f"Invalid AI response format: missing keys")
                    return False
                
                # Update cache
                with self.thread_lock:
                    self.cache[bot_type] = {
                        'data': result,
                        'timestamp': now,
                        'is_valid': True
                    }
                    self.rate_limit_tracker['error_count'] = 0
                    self.rate_limit_tracker['last_update_attempt'] = now
                
                logger.info(f"AI cache updated for {bot_type} bot: {result['entry_decision']['signal']}")
                return True
                
            except json.JSONDecodeError as e:
                logger.error(f"Failed to parse AI response: {e}")
                return False
                
            except Exception as e:
                error_str = str(e)
                
                # Handle rate limit errors
                if "429" in error_str or "RESOURCE_EXHAUSTED" in error_str:
                    with self.thread_lock:
                        self.rate_limit_tracker['error_count'] += 1
                        self.rate_limit_tracker['last_error_time'] = now
                    
                    if self.rate_limit_tracker['error_count'] >= 2:
                        with self.thread_lock:
                            self.rate_limit_tracker['in_cooldown'] = True
                            self.rate_limit_tracker['cooldown_until'] = now + self.cooldown_duration
                        logger.error(f"Gemini API rate limit exceeded. Entering cooldown for {self.cooldown_duration}s")
                        return False
                    
                    if attempt < self.max_retries - 1:
                        backoff_delay = self.retry_delay * (2 ** attempt)
                        logger.warning(f"Rate limit hit (attempt {attempt + 1}/{self.max_retries}). Retrying in {backoff_delay}s...")
                        time.sleep(backoff_delay)
                        continue
                else:
                    logger.error(f"Gemini API error: {error_str}")
                    if attempt < self.max_retries - 1:
                        time.sleep(self.retry_delay)
                        continue
                    return False
        
        return False
    
    def _prepare_prompt(self, bot_type: str, market_data: Dict[str, Any]) -> str:
        """Prepare AI prompt based on bot type and market data"""
        market_data_json = json.dumps(market_data, indent=2)
        
        now_dt = datetime.now()
        current_date = now_dt.strftime("%Y-%m-%d")
        current_time = now_dt.strftime("%H:%M")
        day_of_week = now_dt.strftime("%A")
        hour = now_dt.hour
        
        # Determine trading session
        if 2 <= hour < 8:
            session = "Asian (Low liquidity, range-bound)"
        elif 8 <= hour < 13:
            session = "European (Moderate liquidity, trend development)"
        elif 13 <= hour < 21:
            session = "US (High liquidity, major moves)"
        else:
            session = "After-hours (Very low liquidity, avoid)"
        
        signal_type = "BUY" if bot_type == "buy" else "SELL"
        entry_options = "IMMEDIATE|WAIT_FOR_DIP|WAIT_FOR_BREAKOUT|WAIT_FOR_NEWS|AVOID_TODAY" if bot_type == "buy" else "IMMEDIATE|WAIT_FOR_RALLY|WAIT_FOR_BREAKDOWN|WAIT_FOR_NEWS|AVOID_TODAY"
        
        prompt = f"""
You are a professional XAU/USD (Gold) trading expert with 20 years of experience.

CURRENT CONTEXT:
- Date: {current_date} ({day_of_week})
- Time: {current_time} IST
- Session: {session}

MARKET DATA:
{market_data_json}

YOUR TASK: Analyze if NOW is a good time to enter a {signal_type} position.

Consider:
1. News & Events: Are there major economic events today (US CPI, NFP, FOMC, Fed speeches)? If major news within 2 hours, recommend WAIT.
2. Market Session: Asian=range-bound, European=trend-following, US=high volatility, After-hours=avoid
3. Technical Setup: Is price at good level? Indicators aligned? Clear trend or choppy?
4. Risk Factors: Spread widening? Volatility too high/low? Stop-loss hunting zones?
5. Entry Timing: Enter now? Wait for pullback/rally? Wait for breakout/breakdown? Avoid today?

Return ONLY this JSON (no markdown):
{{
  "entry_decision": {{
    "signal": "{signal_type}|WAIT|AVOID",
    "confidence": 0-100,
    "entry_quality": "EXCELLENT|GOOD|FAIR|POOR",
    "optimal_entry_price": price_level,
    "reasoning": "Detailed why {signal_type}/WAIT/AVOID"
  }},
  "market_context": {{
    "session_assessment": "How current session affects entry",
    "news_today": "Any major news/events today",
    "volatility_level": "LOW|NORMAL|HIGH|EXTREME",
    "market_sentiment": "RISK_ON|RISK_OFF|NEUTRAL"
  }},
  "technical_assessment": {{
    "trend_quality": "STRONG|MODERATE|WEAK|CHOPPY",
    "support_resistance": "near support/resistance/middle",
    "indicator_alignment": "ALIGNED|MIXED|CONFLICTING"
  }},
  "risk_warnings": ["warning1", "warning2"],
  "entry_timing": {{
    "timing": "{entry_options}",
    "wait_for_price": price_level_if_waiting,
    "reason": "Why this timing"
  }},
  "position_sizing": {{
    "recommended_size": "FULL|HALF|QUARTER|MINIMAL",
    "reason": "Why this size"
  }},
  "legacy_fields": {{
    "signal": "{signal_type}|HOLD",
    "entry": price_level,
    "stop_loss": price_level,
    "take_profit_1": price_level,
    "take_profit_2": price_level,
    "reason": "brief explanation"
  }}
}}

Be specific about TODAY's conditions. Make educated assessment based on typical patterns for {day_of_week}.
"""
        return prompt
    
    def get_cache_status(self) -> Dict:
        """Get status of AI cache for monitoring"""
        with self.thread_lock:
            return {
                'enabled': self.enabled,
                'buy_cache': {
                    'valid': self.cache['buy']['is_valid'],
                    'age': int(time.time() - self.cache['buy']['timestamp']) if self.cache['buy']['timestamp'] > 0 else None,
                    'last_signal': self.cache['buy']['data']['entry_decision']['signal'] if self.cache['buy']['is_valid'] else None
                },
                'sell_cache': {
                    'valid': self.cache['sell']['is_valid'],
                    'age': int(time.time() - self.cache['sell']['timestamp']) if self.cache['sell']['timestamp'] > 0 else None,
                    'last_signal': self.cache['sell']['data']['entry_decision']['signal'] if self.cache['sell']['is_valid'] else None
                },
                'rate_limit': {
                    'in_cooldown': self.rate_limit_tracker['in_cooldown'],
                    'error_count': self.rate_limit_tracker['error_count'],
                    'cooldown_remaining': int(self.rate_limit_tracker['cooldown_until'] - time.time()) if self.rate_limit_tracker['in_cooldown'] else 0
                }
            }


# Global Gemini service instance
gemini_service = None

def get_gemini_service() -> Optional[GeminiService]:
    """Get or create global Gemini service instance"""
    global gemini_service
    
    if gemini_service is None:
        api_key = settings.GEMINI_API_KEY
        if api_key:
            gemini_service = GeminiService(api_key=api_key)
            gemini_service.start_background_updater()
        else:
            logger.warning("Gemini API key not configured")
    
    return gemini_service


# Made with Bob