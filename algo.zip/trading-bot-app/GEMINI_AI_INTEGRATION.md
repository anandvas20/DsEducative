# Gemini AI Integration Guide

## Overview

The trading bot backend now includes full Gemini AI integration for intelligent trading signal generation. This document explains how to set up and use the AI features.

## Features

✅ **Background Threading**: AI calls run in separate thread, never blocking trading logic
✅ **Rate Limiting**: Automatic handling of API rate limits with exponential backoff
✅ **Caching**: Non-blocking cache reads for instant signal access
✅ **Cooldown Mode**: Automatic cooldown on rate limit errors
✅ **Enhanced Prompts**: Context-aware prompts with session, news, and timing analysis
✅ **Separate BUY/SELL Analysis**: Independent AI analysis for each bot type

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   FastAPI Backend                        │
├─────────────────────────────────────────────────────────┤
│                                                           │
│  ┌──────────────────────────────────────────────────┐  │
│  │         Gemini Service (gemini_service.py)       │  │
│  │                                                    │  │
│  │  ┌──────────────────────────────────────────┐   │  │
│  │  │   Background Updater Thread              │   │  │
│  │  │   - Runs every 60 seconds                │   │  │
│  │  │   - Fetches market data                  │   │  │
│  │  │   - Calls Gemini API                     │   │  │
│  │  │   - Updates cache (thread-safe)          │   │  │
│  │  └──────────────────────────────────────────┘   │  │
│  │                                                    │  │
│  │  ┌──────────────────────────────────────────┐   │  │
│  │  │   AI Cache (BUY & SELL)                  │   │  │
│  │  │   - entry_decision                       │   │  │
│  │  │   - market_context                       │   │  │
│  │  │   - technical_assessment                 │   │  │
│  │  │   - entry_timing                         │   │  │
│  │  │   - position_sizing                      │   │  │
│  │  │   - risk_warnings                        │   │  │
│  │  └──────────────────────────────────────────┘   │  │
│  │                                                    │  │
│  │  ┌──────────────────────────────────────────┐   │  │
│  │  │   Rate Limit Tracker                     │   │  │
│  │  │   - Error count                          │   │  │
│  │  │   - Cooldown status                      │   │  │
│  │  │   - Last update time                     │   │  │
│  │  └──────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────┘  │
│                                                           │
│  ┌──────────────────────────────────────────────────┐  │
│  │         API Routes (/api/gemini/*)               │  │
│  │   - GET  /status                                 │  │
│  │   - GET  /signal/{bot_type}                      │  │
│  │   - POST /update/{bot_type}                      │  │
│  │   - POST /start-updater                          │  │
│  │   - POST /stop-updater                           │  │
│  └──────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

## Setup

### 1. Get Gemini API Key

1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create a new API key
3. Copy the key

### 2. Configure Environment

Edit `backend/.env`:

```bash
# Gemini AI Configuration
GEMINI_API_KEY=your_actual_api_key_here
GEMINI_MODEL=gemini-2.0-flash-exp
GEMINI_ENABLED=true
GEMINI_UPDATE_INTERVAL=60
GEMINI_MAX_RETRIES=3
GEMINI_RETRY_DELAY=5
GEMINI_COOLDOWN_DURATION=300
```

### 3. Install Dependencies

```bash
cd trading-bot-app/backend
pip install -r requirements.txt
```

Required packages:
- `google-generativeai==0.3.2` - Gemini AI SDK
- `psutil==5.9.6` - Process monitoring

### 4. Initialize Database

```bash
cd trading-bot-app/backend
python -m app.db.init_db
```

This creates MySQL tables for:
- Trade history
- Bot configurations
- Performance metrics
- Bot status logs
- System logs

## API Endpoints

### GET /api/gemini/status

Get Gemini AI service status.

**Response:**
```json
{
  "enabled": true,
  "available": true,
  "buy_cache": {
    "valid": true,
    "age": 45,
    "last_signal": "BUY"
  },
  "sell_cache": {
    "valid": true,
    "age": 47,
    "last_signal": "WAIT"
  },
  "rate_limit": {
    "in_cooldown": false,
    "error_count": 0,
    "cooldown_remaining": 0
  }
}
```

### GET /api/gemini/signal/{bot_type}

Get current AI trading signal from cache (non-blocking).

**Parameters:**
- `bot_type`: `buy` or `sell`

**Response:**
```json
{
  "entry_decision": {
    "signal": "BUY",
    "confidence": 75,
    "entry_quality": "GOOD",
    "optimal_entry_price": 2650.50,
    "reasoning": "Strong bullish momentum with RSI at 45..."
  },
  "market_context": {
    "session_assessment": "European session with moderate liquidity",
    "news_today": "No major events scheduled",
    "volatility_level": "NORMAL",
    "market_sentiment": "RISK_ON"
  },
  "technical_assessment": {
    "trend_quality": "STRONG",
    "support_resistance": "near support",
    "indicator_alignment": "ALIGNED"
  },
  "risk_warnings": [
    "Spread slightly elevated at 0.45"
  ],
  "entry_timing": {
    "timing": "IMMEDIATE",
    "wait_for_price": null,
    "reason": "Good entry setup with aligned indicators"
  },
  "position_sizing": {
    "recommended_size": "FULL",
    "reason": "Strong setup with low risk"
  },
  "legacy_fields": {
    "signal": "BUY",
    "entry": 2650.50,
    "stop_loss": 2645.00,
    "take_profit_1": 2655.00,
    "take_profit_2": 2660.00,
    "reason": "Bullish momentum"
  }
}
```

### POST /api/gemini/update/{bot_type}

Manually trigger AI cache update with market data.

**Parameters:**
- `bot_type`: `buy` or `sell`

**Request Body:**
```json
{
  "symbol": "XAUUSD",
  "timeframe": "M1",
  "price": 2650.50,
  "rsi": 45.5,
  "macd": 0.25,
  "macd_signal": 0.20,
  "ema20": 2649.00,
  "ema50": 2647.00,
  "ema200": 2640.00,
  "atr": 2.5,
  "support": 2645.00,
  "resistance": 2655.00,
  "volume": 1500,
  "trend": "BULLISH",
  "mtf_trend": "STRONG_BULLISH",
  "spread": 0.40
}
```

**Response:**
```json
{
  "status": "success",
  "message": "AI cache updated for buy bot",
  "bot_type": "buy"
}
```

### POST /api/gemini/start-updater

Start the background updater thread.

**Response:**
```json
{
  "status": "success",
  "message": "Background updater started"
}
```

### POST /api/gemini/stop-updater

Stop the background updater thread.

**Response:**
```json
{
  "status": "success",
  "message": "Background updater stopped"
}
```

## Usage in Trading Bots

### Python Example

```python
from app.core.gemini_service import get_gemini_service

# Get service instance
gemini = get_gemini_service()

# Check if available
if gemini and gemini.enabled:
    # Get signal from cache (non-blocking)
    signal = gemini.get_trading_signal('buy', {})
    
    if signal:
        entry_decision = signal['entry_decision']
        
        if entry_decision['signal'] == 'BUY' and entry_decision['confidence'] >= 70:
            # Execute trade
            print(f"AI recommends BUY with {entry_decision['confidence']}% confidence")
            print(f"Reasoning: {entry_decision['reasoning']}")
            
            # Check timing
            timing = signal['entry_timing']
            if timing['timing'] == 'IMMEDIATE':
                # Enter now
                pass
            elif timing['timing'] == 'WAIT_FOR_DIP':
                # Wait for better price
                print(f"Wait for price: {timing['wait_for_price']}")
```

## Rate Limiting

### Free Tier Limits
- **10 requests per minute (RPM)**
- **1,500 requests per day (RPD)**

### Handling Strategy

1. **Background Updates**: Updates run every 60 seconds (well within limits)
2. **Exponential Backoff**: Retries with increasing delays (5s, 10s, 20s)
3. **Cooldown Mode**: After 2 rate limit errors, enters 5-minute cooldown
4. **Cache Fallback**: Trading continues with cached data during cooldown

### Monitoring

Check rate limit status:
```bash
curl http://localhost:8000/api/gemini/status
```

## AI Response Structure

### Entry Decision
- `signal`: BUY/SELL/WAIT/AVOID
- `confidence`: 0-100 (percentage)
- `entry_quality`: EXCELLENT/GOOD/FAIR/POOR
- `optimal_entry_price`: Recommended entry price
- `reasoning`: Detailed explanation

### Market Context
- `session_assessment`: How current session affects entry
- `news_today`: Major economic events
- `volatility_level`: LOW/NORMAL/HIGH/EXTREME
- `market_sentiment`: RISK_ON/RISK_OFF/NEUTRAL

### Technical Assessment
- `trend_quality`: STRONG/MODERATE/WEAK/CHOPPY
- `support_resistance`: Price position relative to S/R
- `indicator_alignment`: ALIGNED/MIXED/CONFLICTING

### Entry Timing
- `timing`: IMMEDIATE/WAIT_FOR_DIP/WAIT_FOR_BREAKOUT/WAIT_FOR_NEWS/AVOID_TODAY
- `wait_for_price`: Target price if waiting
- `reason`: Why this timing

### Position Sizing
- `recommended_size`: FULL/HALF/QUARTER/MINIMAL
- `reason`: Why this size

## Best Practices

### 1. Always Check Cache Validity
```python
signal = gemini.get_trading_signal('buy', {})
if signal:
    # Use signal
else:
    # Fallback to technical indicators only
```

### 2. Respect Confidence Levels
```python
if entry_decision['confidence'] >= 80:
    # High confidence - full position
elif entry_decision['confidence'] >= 60:
    # Medium confidence - half position
else:
    # Low confidence - skip or minimal position
```

### 3. Monitor Cache Age
```python
status = gemini.get_cache_status()
if status['buy_cache']['age'] > 120:
    # Cache is stale (>2 minutes old)
    # Consider waiting for fresh update
```

### 4. Handle Cooldown Gracefully
```python
if status['rate_limit']['in_cooldown']:
    remaining = status['rate_limit']['cooldown_remaining']
    print(f"AI in cooldown for {remaining}s. Using cached data.")
```

## Troubleshooting

### Issue: "Gemini AI service not available"

**Solution:**
1. Check API key in `.env`
2. Verify `google-generativeai` is installed
3. Check logs for initialization errors

### Issue: Rate limit errors

**Solution:**
1. Increase `GEMINI_UPDATE_INTERVAL` (default: 60s)
2. Reduce manual update calls
3. Wait for cooldown to end (5 minutes)

### Issue: Stale cache warnings

**Solution:**
1. Check background updater is running
2. Verify network connectivity
3. Check Gemini API status

### Issue: Invalid response format

**Solution:**
1. Update to latest `google-generativeai` package
2. Check model name is correct
3. Review API logs for errors

## Performance

- **Cache Read**: <1ms (thread-safe dictionary lookup)
- **API Call**: 1-3 seconds (runs in background)
- **Update Frequency**: Every 60 seconds
- **Memory Usage**: ~50MB (includes model cache)

## Security

- API key stored in `.env` (never committed)
- Thread-safe cache operations
- No sensitive data in prompts
- Rate limiting prevents abuse

## Future Enhancements

- [ ] Multi-model support (GPT-4, Claude)
- [ ] Historical signal tracking
- [ ] Performance analytics
- [ ] Custom prompt templates
- [ ] Real-time news integration
- [ ] Sentiment analysis

## Support

For issues or questions:
1. Check logs: `trading-bot-app/backend/logs/`
2. Review API docs: `http://localhost:8000/docs`
3. Test endpoint: `http://localhost:8000/api/gemini/status`

---

**Made with Bob** 🤖