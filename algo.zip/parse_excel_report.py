#!/usr/bin/env python3
"""Parse the Excel trading report"""

import zipfile
import xml.etree.ElementTree as ET
from collections import defaultdict

def parse_excel(filepath):
    with zipfile.ZipFile(filepath, 'r') as zip_ref:
        # Read shared strings
        with zip_ref.open('xl/sharedStrings.xml') as f:
            tree = ET.parse(f)
            root = tree.getroot()
            # Extract text from all <t> elements
            ns = {'main': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            shared_strings = []
            for si in root.findall('.//main:si', ns):
                text_parts = []
                for t in si.findall('.//main:t', ns):
                    if t.text:
                        text_parts.append(t.text)
                shared_strings.append(''.join(text_parts))
        
        print(f"Total shared strings: {len(shared_strings)}")
        print("\n" + "="*100)
        print("ALL SHARED STRINGS (Trading Data):")
        print("="*100)
        for i, s in enumerate(shared_strings):
            print(f"{i:3d}: {s}")
        
        # Try to read worksheet with different encoding
        print("\n" + "="*100)
        print("ATTEMPTING TO READ WORKSHEET DATA:")
        print("="*100)
        try:
            with zip_ref.open('xl/worksheets/sheet1.xml') as f:
                # Try reading as binary first
                content = f.read()
                print(f"Worksheet size: {len(content)} bytes")
                
                # Try different encodings
                for encoding in ['utf-8', 'latin-1', 'cp1252']:
                    try:
                        decoded = content.decode(encoding)
                        print(f"\nSuccessfully decoded with {encoding}")
                        print(f"First 3000 characters:\n{decoded[:3000]}")
                        break
                    except:
                        continue
        except Exception as e:
            print(f"Error reading worksheet: {e}")

if __name__ == "__main__":
    parse_excel('/Users/anandgotluri/Desktop/algo/ReportHistory-183982817.xlsx')

# Made with Bob
