import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';

interface BotTemplate {
  id: string;
  name: string;
  description: string;
  config: BotConfig;
  isDefault?: boolean;
}

interface BotConfig {
  // Trading Parameters
  symbol: string;
  lot_size: number;
  max_positions: number;
  
  // Ladder Configuration
  num_ladders: number;
  ladder_gap_points: number;
  
  // Profit Targets
  profit_target_points: number;
  trailing_profit_enabled: boolean;
  trailing_profit_distance: number;
  partial_profit_enabled: boolean;
  partial_profit_percentage: number;
  
  // Risk Management
  max_daily_loss: number;
  max_drawdown_percent: number;
  
  // Daily Profit Target
  daily_profit_target?: number;
  close_all_on_daily_target: boolean;
  stop_trading_on_daily_target: boolean;
  
  // Trading Hours
  trading_start_hour: number;
  trading_start_minute: number;
  trading_end_hour: number;
  trading_end_minute: number;
  trading_timezone: string;
  
  // Skip Trading Days
  skip_monday: boolean;
  skip_tuesday: boolean;
  skip_wednesday: boolean;
  skip_thursday: boolean;
  skip_friday: boolean;
  skip_saturday: boolean;
  skip_sunday: boolean;
}

interface BotAssignment {
  buy_bot_template: string;
  sell_bot_template: string;
}

@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  // Templates
  templates: BotTemplate[] = [];
  selectedTemplate: BotTemplate | null = null;
  editingTemplate: BotTemplate | null = null;
  
  // Bot Assignments
  assignments: BotAssignment = {
    buy_bot_template: 'default',
    sell_bot_template: 'default'
  };
  
  // UI State
  loading = false;
  saveSuccess = false;
  saveError = '';
  activeView: 'templates' | 'assignments' | 'editor' = 'templates';
  
  // New Template
  newTemplateName = '';
  newTemplateDescription = '';
  showNewTemplateDialog = false;

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.loadTemplates();
    this.loadAssignments();
  }

  loadTemplates() {
    this.loading = true;
    // Load templates from backend
    this.apiService.getConfig().subscribe({
      next: (config: any) => {
        this.templates = config.templates || this.getDefaultTemplates();
        this.loading = false;
      },
      error: (error: any) => {
        console.error('Failed to load templates:', error);
        this.templates = this.getDefaultTemplates();
        this.loading = false;
      }
    });
  }

  loadAssignments() {
    this.apiService.getConfig().subscribe({
      next: (config: any) => {
        if (config.assignments) {
          this.assignments = config.assignments;
        }
      },
      error: (error: any) => {
        console.error('Failed to load assignments:', error);
      }
    });
  }

  getDefaultTemplates(): BotTemplate[] {
    const baseConfig = {
      daily_profit_target: undefined,
      close_all_on_daily_target: false,
      stop_trading_on_daily_target: false,
      trading_start_hour: 0,
      trading_start_minute: 0,
      trading_end_hour: 23,
      trading_end_minute: 59,
      trading_timezone: 'UTC',
      skip_monday: false,
      skip_tuesday: false,
      skip_wednesday: false,
      skip_thursday: false,
      skip_friday: false,
      skip_saturday: true,
      skip_sunday: true
    };

    return [
      {
        id: 'default',
        name: 'Default',
        description: 'Standard balanced configuration',
        isDefault: true,
        config: {
          symbol: 'XAUUSD',
          lot_size: 0.01,
          max_positions: 5,
          num_ladders: 5,
          ladder_gap_points: 50,
          profit_target_points: 100,
          trailing_profit_enabled: true,
          trailing_profit_distance: 30,
          partial_profit_enabled: true,
          partial_profit_percentage: 50,
          max_daily_loss: 1000,
          max_drawdown_percent: 10,
          ...baseConfig
        }
      },
      {
        id: 'conservative',
        name: 'Conservative',
        description: 'Lower risk, smaller positions',
        isDefault: true,
        config: {
          symbol: 'XAUUSD',
          lot_size: 0.01,
          max_positions: 3,
          num_ladders: 3,
          ladder_gap_points: 30,
          profit_target_points: 80,
          trailing_profit_enabled: false,
          trailing_profit_distance: 20,
          partial_profit_enabled: true,
          partial_profit_percentage: 50,
          max_daily_loss: 500,
          max_drawdown_percent: 5,
          ...baseConfig
        }
      },
      {
        id: 'aggressive',
        name: 'Aggressive',
        description: 'Higher risk, larger positions',
        isDefault: true,
        config: {
          symbol: 'XAUUSD',
          lot_size: 0.02,
          max_positions: 8,
          num_ladders: 8,
          ladder_gap_points: 100,
          profit_target_points: 150,
          trailing_profit_enabled: true,
          trailing_profit_distance: 50,
          partial_profit_enabled: false,
          partial_profit_percentage: 50,
          max_daily_loss: 2000,
          max_drawdown_percent: 15,
          ...baseConfig
        }
      }
    ];
  }

  selectTemplate(template: BotTemplate) {
    this.selectedTemplate = template;
    this.activeView = 'editor';
    this.editingTemplate = JSON.parse(JSON.stringify(template));
  }

  createNewTemplate() {
    if (!this.newTemplateName.trim()) {
      this.saveError = 'Template name is required';
      return;
    }

    const newTemplate: BotTemplate = {
      id: `custom_${Date.now()}`,
      name: this.newTemplateName,
      description: this.newTemplateDescription,
      config: JSON.parse(JSON.stringify(this.templates[0].config))
    };

    this.templates.push(newTemplate);
    this.selectTemplate(newTemplate);
    this.showNewTemplateDialog = false;
    this.newTemplateName = '';
    this.newTemplateDescription = '';
  }

  copyTemplate(template: BotTemplate) {
    const copiedTemplate: BotTemplate = {
      id: `custom_${Date.now()}`,
      name: `${template.name} (Copy)`,
      description: `Copy of ${template.name}`,
      config: JSON.parse(JSON.stringify(template.config))
    };

    this.templates.push(copiedTemplate);
    this.selectTemplate(copiedTemplate);
  }

  deleteTemplate(template: BotTemplate) {
    if (template.isDefault) {
      this.saveError = 'Cannot delete default templates';
      return;
    }

    if (confirm(`Delete template "${template.name}"?`)) {
      this.templates = this.templates.filter(t => t.id !== template.id);
      this.saveTemplates();
    }
  }

  saveTemplate() {
    if (!this.editingTemplate) return;

    const index = this.templates.findIndex(t => t.id === this.editingTemplate!.id);
    if (index !== -1) {
      this.templates[index] = this.editingTemplate;
    }

    this.saveTemplates();
    this.activeView = 'templates';
    this.editingTemplate = null;
  }

  saveTemplates() {
    this.loading = true;
    this.saveSuccess = false;
    this.saveError = '';

    const config = {
      templates: this.templates,
      assignments: this.assignments
    };

    this.apiService.updateConfig(config).subscribe({
      next: () => {
        this.loading = false;
        this.saveSuccess = true;
        setTimeout(() => this.saveSuccess = false, 3000);
      },
      error: (error: any) => {
        this.loading = false;
        this.saveError = error.message || 'Failed to save templates';
        setTimeout(() => this.saveError = '', 5000);
      }
    });
  }

  assignTemplate(bot: 'buy' | 'sell', templateId: string) {
    if (bot === 'buy') {
      this.assignments.buy_bot_template = templateId;
    } else {
      this.assignments.sell_bot_template = templateId;
    }
    this.saveTemplates();
  }

  cancelEdit() {
    this.activeView = 'templates';
    this.editingTemplate = null;
  }

  getAssignedTemplate(bot: 'buy' | 'sell'): BotTemplate | undefined {
    const templateId = bot === 'buy' ? this.assignments.buy_bot_template : this.assignments.sell_bot_template;
    return this.templates.find(t => t.id === templateId);
  }
}

// Made with Bob
