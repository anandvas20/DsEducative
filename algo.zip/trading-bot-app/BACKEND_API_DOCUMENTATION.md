# Backend API Documentation

## Overview
Complete REST API documentation for the Trading Bot Management System with template-based configuration.

## Base URL
```
http://localhost:8000
```

## API Endpoints

### Configuration Management

#### Get Configuration
```http
GET /api/config
```

**Response:**
```json
{
  "templates": [
    {
      "id": "default",
      "name": "Default",
      "description": "Standard balanced configuration",
      "is_default": true,
      "config": {
        "symbol": "XAUUSD",
        "lot_size": 0.01,
        "max_positions": 5,
        "num_ladders": 5,
        "ladder_gap_points": 50,
        "profit_target_points": 100,
        "trailing_profit_enabled": true,
        "trailing_profit_distance": 30,
        "partial_profit_enabled": true,
        "partial_profit_percentage": 50,
        "max_daily_loss": 1000,
        "max_drawdown_percent": 10
      },
      "created_at": "2024-01-01T00:00:00Z",
      "updated_at": "2024-01-01T00:00:00Z"
    }
  ],
  "assignments": {
    "buy_bot_template": "default",
    "sell_bot_template": "default"
  },
  "mt5_login": "",
  "mt5_password": "",
  "mt5_server": "",
  "gemini_api_key": "",
  "gemini_enabled": true
}
```

#### Update Configuration
```http
PUT /api/config
Content-Type: application/json
```

**Request Body:**
```json
{
  "templates": [...],
  "assignments": {...},
  "mt5_login": "12345678",
  "mt5_password": "password",
  "mt5_server": "BrokerName-Demo",
  "gemini_api_key": "AIza...",
  "gemini_enabled": true
}
```

**Response:**
```json
{
  "success": true,
  "message": "Configuration updated successfully",
  "data": {
    "config": {...}
  }
}
```

### Template Management

#### Get All Templates
```http
GET /api/config/templates
```

**Response:**
```json
[
  {
    "id": "default",
    "name": "Default",
    "description": "Standard balanced configuration",
    "is_default": true,
    "config": {...},
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z"
  }
]
```

#### Get Template by ID
```http
GET /api/config/templates/{template_id}
```

**Response:**
```json
{
  "id": "default",
  "name": "Default",
  "description": "Standard balanced configuration",
  "is_default": true,
  "config": {...},
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T00:00:00Z"
}
```

#### Create Template
```http
POST /api/config/templates
Content-Type: application/json
```

**Request Body:**
```json
{
  "name": "My Custom Template",
  "description": "Custom configuration for specific strategy",
  "config": {
    "symbol": "XAUUSD",
    "lot_size": 0.01,
    "max_positions": 5,
    "num_ladders": 5,
    "ladder_gap_points": 50,
    "profit_target_points": 100,
    "trailing_profit_enabled": true,
    "trailing_profit_distance": 30,
    "partial_profit_enabled": true,
    "partial_profit_percentage": 50,
    "max_daily_loss": 1000,
    "max_drawdown_percent": 10
  }
}
```

**Response:**
```json
{
  "id": "custom_1234567890",
  "name": "My Custom Template",
  "description": "Custom configuration for specific strategy",
  "is_default": false,
  "config": {...},
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T00:00:00Z"
}
```

#### Update Template
```http
PUT /api/config/templates/{template_id}
Content-Type: application/json
```

**Request Body:**
```json
{
  "name": "Updated Template Name",
  "description": "Updated description",
  "config": {...}
}
```

**Response:**
```json
{
  "id": "custom_1234567890",
  "name": "Updated Template Name",
  "description": "Updated description",
  "is_default": false,
  "config": {...},
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T12:00:00Z"
}
```

#### Delete Template
```http
DELETE /api/config/templates/{template_id}
```

**Response:**
```json
{
  "success": true,
  "message": "Template 'My Custom Template' deleted successfully"
}
```

**Error Response (if template is assigned):**
```json
{
  "success": false,
  "error": "Cannot delete template assigned to BUY bot"
}
```

#### Copy Template
```http
POST /api/config/templates/{template_id}/copy
```

**Response:**
```json
{
  "id": "custom_1234567891",
  "name": "Default (Copy)",
  "description": "Copy of Default",
  "is_default": false,
  "config": {...},
  "created_at": "2024-01-01T00:00:00Z",
  "updated_at": "2024-01-01T00:00:00Z"
}
```

### Template Assignments

#### Get Assignments
```http
GET /api/config/assignments
```

**Response:**
```json
{
  "buy_bot_template": "default",
  "sell_bot_template": "aggressive"
}
```

#### Assign Template to Bot
```http
POST /api/config/assignments
Content-Type: application/json
```

**Request Body:**
```json
{
  "bot_id": "buy",
  "template_id": "aggressive"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Template 'Aggressive' assigned to BUY bot",
  "data": {
    "bot_id": "buy",
    "template_id": "aggressive",
    "template_name": "Aggressive"
  }
}
```

#### Reset Configuration
```http
POST /api/config/reset
```

**Response:**
```json
{
  "success": true,
  "message": "Configuration reset to defaults",
  "data": {
    "config": {...}
  }
}
```

### Bot Control

#### Get All Bots Status
```http
GET /api/bots
```

**Response:**
```json
[
  {
    "bot_id": "buy",
    "status": "running",
    "uptime": 3600,
    "last_trade": "2024-01-01T12:00:00Z",
    "active_positions": 3,
    "template_id": "default"
  },
  {
    "bot_id": "sell",
    "status": "stopped",
    "uptime": null,
    "last_trade": null,
    "active_positions": 0,
    "template_id": "aggressive"
  }
]
```

#### Get Bot Status
```http
GET /api/bots/{bot_id}
```

#### Start Bot
```http
POST /api/bots/{bot_id}/start
```

#### Stop Bot
```http
POST /api/bots/{bot_id}/stop
```

#### Restart Bot
```http
POST /api/bots/{bot_id}/restart
```

### Positions

#### Get All Positions
```http
GET /api/positions
```

**Response:**
```json
{
  "total_positions": 5,
  "buy_positions": 3,
  "sell_positions": 2,
  "total_profit": 150.50,
  "total_volume": 0.15,
  "positions": [
    {
      "ticket": 123456,
      "symbol": "XAUUSD",
      "type": "buy",
      "volume": 0.01,
      "open_price": 2000.00,
      "current_price": 2010.00,
      "profit": 10.00,
      "open_time": "2024-01-01T12:00:00Z",
      "magic": 777,
      "comment": "Grid Level 1"
    }
  ]
}
```

#### Close Position
```http
POST /api/positions/{ticket}/close
```

#### Close All Positions
```http
POST /api/positions/close-all
```

### Analytics

#### Get Statistics
```http
GET /api/analytics/statistics
```

**Response:**
```json
{
  "total_trades": 100,
  "winning_trades": 65,
  "losing_trades": 35,
  "win_rate": 65.0,
  "total_profit": 5000.00,
  "total_loss": -2000.00,
  "net_profit": 3000.00,
  "average_win": 76.92,
  "average_loss": -57.14,
  "profit_factor": 2.5,
  "max_drawdown": 500.00
}
```

#### Get Daily Performance
```http
GET /api/analytics/daily
```

#### Get Equity Curve
```http
GET /api/analytics/equity
```

## Data Models

### BotConfig
```typescript
{
  symbol: string;              // Trading symbol
  lot_size: number;            // Base lot size (min: 0.01)
  max_positions: number;       // Max concurrent positions (1-20)
  num_ladders: number;         // Number of ladder levels (1-10)
  ladder_gap_points: number;   // Gap between ladders (min: 10)
  profit_target_points: number; // Profit target (min: 10)
  trailing_profit_enabled: boolean;
  trailing_profit_distance: number; // Trailing distance (min: 10)
  partial_profit_enabled: boolean;
  partial_profit_percentage: number; // Percentage (10-90)
  max_daily_loss: number;      // Max daily loss (min: 100)
  max_drawdown_percent: number; // Max drawdown (1-50)
}
```

### BotTemplate
```typescript
{
  id: string;                  // Unique identifier
  name: string;                // Template name (1-100 chars)
  description: string;         // Description (max 500 chars)
  config: BotConfig;           // Configuration object
  is_default: boolean;         // Whether it's a default template
  created_at: datetime;        // Creation timestamp
  updated_at: datetime;        // Last update timestamp
}
```

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "error": "Invalid request parameters",
  "details": {
    "field": "lot_size",
    "message": "Must be at least 0.01"
  }
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": "Template 'custom_123' not found"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "error": "Failed to save configuration",
  "details": {
    "message": "Disk write error"
  }
}
```

## WebSocket Events

### Connection
```javascript
const socket = io('http://localhost:8000');
```

### Events

#### bot_status_changed
```json
{
  "event_type": "bot_status_changed",
  "data": {
    "bot_id": "buy",
    "old_status": "stopped",
    "new_status": "running",
    "reason": "User started bot",
    "timestamp": "2024-01-01T12:00:00Z"
  }
}
```

#### trade_opened
```json
{
  "event_type": "trade_opened",
  "data": {
    "ticket": 123456,
    "symbol": "XAUUSD",
    "type": "buy",
    "volume": 0.01,
    "price": 2000.00,
    "timestamp": "2024-01-01T12:00:00Z"
  }
}
```

#### trade_closed
```json
{
  "event_type": "trade_closed",
  "data": {
    "ticket": 123456,
    "symbol": "XAUUSD",
    "type": "buy",
    "volume": 0.01,
    "price": 2010.00,
    "profit": 10.00,
    "timestamp": "2024-01-01T12:05:00Z"
  }
}
```

## Rate Limiting
- No rate limiting currently implemented
- Recommended: 100 requests per minute per IP

## Authentication
- Currently no authentication required
- Recommended: Add JWT authentication for production

## CORS
- Allowed origins: `http://localhost:4200`
- All methods and headers allowed

---

**Made with Bob** 🤖