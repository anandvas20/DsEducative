import { Routes } from '@angular/router';
import { DashboardComponent } from './features/dashboard/dashboard.component';

export const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { 
    path: 'bot-control', 
    loadComponent: () => import('./features/bot-control/bot-control.component').then(m => m.BotControlComponent)
  },
  { 
    path: 'positions', 
    loadComponent: () => import('./features/positions/positions.component').then(m => m.PositionsComponent)
  },
  { 
    path: 'analytics', 
    loadComponent: () => import('./features/analytics/analytics.component').then(m => m.AnalyticsComponent)
  },
  { 
    path: 'settings', 
    loadComponent: () => import('./features/settings/settings.component').then(m => m.SettingsComponent)
  },
  { path: '**', redirectTo: '/dashboard' }
];

// Made with Bob
