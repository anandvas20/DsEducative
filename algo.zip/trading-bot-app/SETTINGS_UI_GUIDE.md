# Settings UI Configuration Guide

## Overview
The Settings UI provides a comprehensive interface for configuring all aspects of the trading bot, including profit targets, ladder settings, risk management, and more.

## Features Implemented

### 1. **Trading Parameters Tab** 📊
Configure basic trading settings:
- **Symbol**: Trading instrument (e.g., XAUUSD, EURUSD)
- **Lot Size**: Base position size
- **Max Positions**: Maximum concurrent positions allowed

### 2. **Ladder Configuration Tab** 🪜
**Key Feature: Dynamic Ladder Management**
- **Number of Ladders**: Adjustable from 1-10 levels
- **Gap Between Ladders**: Distance in points between each level
- **Visual Preview**: Real-time visualization of ladder structure
- **Total Range Calculator**: Shows total coverage in points

**Example Configuration:**
```
Ladders: 5
Gap: 50 points
Total Range: 250 points

Level 1 (0 pts)
Level 2 (50 pts)
Level 3 (100 pts)
Level 4 (150 pts)
Level 5 (200 pts)
```

### 3. **Profit Target Configuration Tab** 💰
**Key Feature: Dynamic Profit Management**

#### Base Profit Target
- Set profit target in points
- Adjustable in 10-point increments

#### Trailing Profit
- **Enable/Disable**: Toggle trailing profit feature
- **Trailing Distance**: How far to trail behind best price
- **Benefit**: Captures more profit in strong trends

#### Partial Profit Taking
- **Enable/Disable**: Toggle partial exits
- **Percentage**: Amount to close at profit target (10-90%)
- **Benefit**: Locks in profits while keeping position open

**Profit Strategy Summary:**
The UI displays a real-time summary of your profit strategy:
- Base target
- Trailing status and distance
- Partial close percentage

### 4. **Risk Management Tab** 🛡️
- **Max Daily Loss**: Stop trading if loss exceeds this amount
- **Max Drawdown**: Maximum allowed drawdown percentage

### 5. **MT5 Connection Tab** 🔌
Configure MetaTrader 5 connection:
- MT5 Login (account number)
- MT5 Password (secure input)
- MT5 Server name

### 6. **Gemini AI Tab** 🤖
- **Enable/Disable AI**: Toggle AI-powered decision making
- **API Key**: Secure input for Gemini API key
- **Features List**: Shows all AI capabilities

## How to Use

### Changing Ladder Configuration

1. Navigate to **Ladder Tab**
2. Adjust **Number of Ladders** slider (1-10)
3. Set **Gap Between Ladders** in points
4. View real-time preview of ladder structure
5. Click **Save Configuration**

**Example Use Cases:**
- **Tight Range**: 3 ladders, 30-point gap (90 points total)
- **Medium Range**: 5 ladders, 50-point gap (250 points total)
- **Wide Range**: 8 ladders, 100-point gap (800 points total)

### Configuring Profit Targets

1. Navigate to **Profit Tab**
2. Set **Base Profit Target** (e.g., 100 points)
3. Enable **Trailing Profit** if desired
   - Set trailing distance (e.g., 30 points)
4. Enable **Partial Profit** if desired
   - Set percentage to close (e.g., 50%)
5. Review strategy summary
6. Click **Save Configuration**

**Example Strategies:**

**Conservative:**
```
Profit Target: 80 points
Trailing: Disabled
Partial: Enabled (50%)
```

**Aggressive:**
```
Profit Target: 150 points
Trailing: Enabled (40 pts)
Partial: Disabled
```

**Balanced:**
```
Profit Target: 100 points
Trailing: Enabled (30 pts)
Partial: Enabled (50%)
```

## Configuration Persistence

All settings are:
- ✅ Saved to backend (`bot_config.json`)
- ✅ Loaded on application start
- ✅ Applied to running bots in real-time
- ✅ Backed up automatically

## API Integration

The Settings UI communicates with the backend via:

### GET `/api/config`
Retrieves current configuration

### PUT `/api/config`
Updates configuration with new values

### POST `/api/config/reset`
Resets to default configuration

## Real-Time Updates

When you save configuration:
1. Frontend sends updated config to backend
2. Backend validates and saves to file
3. Running bots reload configuration
4. Changes take effect on next trade cycle
5. Success/error message displayed to user

## Visual Feedback

The UI provides:
- ✅ **Loading States**: Spinner during save/load
- ✅ **Success Messages**: Green alert on successful save
- ✅ **Error Messages**: Red alert with error details
- ✅ **Real-Time Previews**: Visual representation of settings
- ✅ **Validation**: Input constraints and warnings

## Responsive Design

The Settings UI is fully responsive:
- **Desktop**: Full-width tabs with side-by-side layout
- **Tablet**: Stacked layout with scrollable tabs
- **Mobile**: Single-column layout with touch-friendly controls

## Security Features

- 🔒 Password fields are masked
- 🔒 API keys are hidden by default
- 🔒 Sensitive data encrypted in transit
- 🔒 Configuration file permissions restricted

## Best Practices

### Ladder Configuration
1. Start with fewer ladders (3-5) for testing
2. Adjust gap based on symbol volatility
3. Monitor total range vs. typical price movement
4. Increase ladders gradually as you gain confidence

### Profit Targets
1. Set realistic targets based on historical data
2. Use trailing profit in trending markets
3. Use partial profit in ranging markets
4. Test different combinations in demo account

### Risk Management
1. Never risk more than 2% per trade
2. Set daily loss limit to protect capital
3. Monitor drawdown regularly
4. Adjust position sizes based on account balance

## Troubleshooting

### Configuration Not Saving
- Check backend connection
- Verify file permissions
- Check browser console for errors

### Changes Not Applied
- Restart bots after major changes
- Verify configuration file updated
- Check bot logs for errors

### UI Not Loading
- Clear browser cache
- Check API endpoint availability
- Verify Angular dependencies installed

## Future Enhancements

Planned features:
- [ ] Configuration templates (Conservative, Balanced, Aggressive)
- [ ] Import/Export configuration files
- [ ] Configuration history and rollback
- [ ] A/B testing different configurations
- [ ] Performance comparison charts
- [ ] Automated optimization suggestions

## Support

For issues or questions:
1. Check bot logs: `gold_grid_bot.log`
2. Review backend logs: `uvicorn.log`
3. Check configuration file: `bot_config.json`
4. Verify MT5 connection status

---

**Made with Bob** 🤖