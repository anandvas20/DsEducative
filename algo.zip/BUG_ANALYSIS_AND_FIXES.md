# Trading Bot Critical Issues Analysis & Fixes

## Executive Summary
The bot experienced catastrophic failure with losses escalating from -$0.31 to -$108.04 in ~6 minutes due to multiple critical bugs.

---

## 🔴 CRITICAL ISSUES IDENTIFIED

### 1. **Hedge Magic Number Bug (MOST CRITICAL)**
**Location:** Line 772 in `get_live_hedge()`
```python
if (position.magic == MAGIC + 1 and  # ❌ WRONG!
```

**Problem:** 
- Hedges are opened with `MAGIC` (same as buy positions)
- But the code checks for `MAGIC + 1` to find hedges
- **Result:** Bot NEVER finds existing hedges, opens unlimited hedges

**Evidence from logs:**
```
21:59:23 | HEDGE OPENED | pnl=-41.81 | lot=0.14
21:59:24 | HEDGE OPENED | pnl=-41.87 | lot=0.14  # ← Should have found first hedge!
21:59:26 | HEDGE OPENED | pnl=-46.18 | lot=0.14  # ← Still opening more!
21:59:27 | HEDGE OPENED | pnl=-49.65 | lot=0.14  # ← Disaster!
```

**Fix:**
```python
# Option A: Use MAGIC + 1 when opening hedges
def open_hedge(lot):
    """Open a hedge position (sell) with different magic number"""
    return sell(lot, magic=MAGIC + 1)

# Option B: Check for MAGIC (simpler)
def get_live_hedge():
    positions = get_positions(force=True)
    for position in positions:
        if (position.magic == MAGIC and  # ✅ FIXED
            position.type == mt5.POSITION_TYPE_SELL):
            return position
    return None
```

---

### 2. **Retcode 10019 - Insufficient Funds**
**Problem:** 
- Error code 10019 = `TRADE_RETCODE_NO_MONEY`
- Bot kept trying to open positions without checking account balance
- Each failed attempt wasted time and created log spam

**Evidence:**
```
21:59:28 | ORDER RETRY 1/3 | retcode=10019
21:59:28 | ORDER RETRY 2/3 | retcode=10019
21:59:28 | ORDER RETRY 3/3 | retcode=10019
21:59:28 | ERROR | ORDER FAILED AFTER RETRIES
```

**Fix:** Add balance check before trading
```python
def can_afford_trade(lot, order_type):
    """Check if account has sufficient margin for trade"""
    account_info = mt5.account_info()
    if not account_info:
        return False
    
    # Get required margin
    symbol_info = mt5.symbol_info(SYMBOL)
    if not symbol_info:
        return False
    
    tick = mt5.symbol_info_tick(SYMBOL)
    if not tick:
        return False
    
    price = tick.ask if order_type == mt5.ORDER_TYPE_BUY else tick.bid
    required_margin = (lot * symbol_info.trade_contract_size * price) / account_info.leverage
    
    # Add 20% buffer for safety
    required_margin *= 1.2
    
    return account_info.margin_free >= required_margin

def buy(lot):
    if not can_afford_trade(lot, mt5.ORDER_TYPE_BUY):
        log.warning(f"BUY SKIPPED — Insufficient margin for {lot} lots")
        return False
    # ... rest of buy logic
```

---

### 3. **No Hedge Cooldown Period**
**Problem:**
- `hedge_manager()` called every second in main loop
- No time-based restriction between hedges
- `last_hedge_time` variable exists but never checked!

**Fix:**
```python
def hedge_manager(buy_pnl, total_lot):
    global hedge_ticket
    global last_hedge_time
    
    # Add cooldown check
    HEDGE_COOLDOWN = 60  # 60 seconds between hedges
    if last_hedge_time and (time.time() - last_hedge_time) < HEDGE_COOLDOWN:
        return  # Too soon to hedge again
    
    hedge_position = get_live_hedge()
    
    if hedge_position:
        hedge_ticket = hedge_position.ticket
    else:
        hedge_ticket = None
    
    # ... rest of logic
```

---

### 4. **Aggressive Grid Recovery**
**Problem:**
- `LOT_MULTIPLIER = 1.0` means no scaling
- Grid entries happen too frequently (MIN_GRID_GAP = 0.5)
- No maximum position limit

**Current behavior:**
```
21:55:49 | Positions=1
21:55:59 | Positions=2
21:56:02 | Positions=3
21:56:27 | Positions=4
21:57:31 | Positions=5
21:57:51 | Positions=6
```

**Fix:**
```python
# Add position limits
MAX_BUY_POSITIONS = 10
MAX_TOTAL_POSITIONS = 15

def grid_engine(df):
    global lot_index
    
    if df is None or len(df) < 50:
        return
    
    positions = get_positions(force=True)
    buy_positions = [p for p in positions if p.type == mt5.POSITION_TYPE_BUY]
    
    # ✅ Add position limit check
    if len(buy_positions) >= MAX_BUY_POSITIONS:
        log.warning(f"Max buy positions reached: {len(buy_positions)}")
        return
    
    if len(positions) >= MAX_TOTAL_POSITIONS:
        log.warning(f"Max total positions reached: {len(positions)}")
        return
    
    # ... rest of logic
```

---

### 5. **Weak Hedge Trigger Logic**
**Problem:**
```python
def dynamic_hedge_trigger(atr, total_lot, trend_state):
    if atr is None:
        return -50.0
    return -30.0 - (total_lot * 5)
```

- With 0.28 lots: trigger = -30 - (0.28 * 5) = -31.4
- Bot hit -41.81 before first hedge
- Trigger becomes MORE aggressive as lot size increases (wrong direction!)

**Fix:**
```python
def dynamic_hedge_trigger(atr, total_lot, trend_state):
    """Calculate dynamic hedge trigger based on ATR and trend"""
    if atr is None:
        atr = 2.0  # Default ATR for gold
    
    # Base trigger: -2x ATR in dollars
    base_trigger = -2.0 * atr * 10  # ~$20-40 for typical gold ATR
    
    # Make LESS aggressive as positions grow (more conservative)
    lot_penalty = total_lot * 10  # Each 0.1 lot adds $1 buffer
    
    # Trend adjustment: more conservative in weak trends
    trend_multiplier = 1.0 if trend_state > 0.5 else 1.5
    
    trigger = (base_trigger - lot_penalty) * trend_multiplier
    
    return max(trigger, -100.0)  # Never worse than -$100
```

---

## 📊 Timeline Analysis

| Time | Event | PnL | Positions | Issue |
|------|-------|-----|-----------|-------|
| 21:55:48 | Bot started | 0 | 0 | - |
| 21:55:49 | First buy | -0.31 | 1 | Normal |
| 21:59:23 | **4 hedges opened in 4 seconds!** | -54.62 | 15 | 🔴 Magic number bug |
| 21:59:28+ | Retcode 10019 spam begins | -54.62 | 15 | 🔴 No money |
| 22:01:29 | Still adding positions | -104.20 | 25 | 🔴 No limits |

---

## 🛠️ IMPLEMENTATION PRIORITY

### Priority 1 (CRITICAL - Fix Immediately)
1. ✅ Fix hedge magic number bug
2. ✅ Add balance check before trades
3. ✅ Add hedge cooldown period
4. ✅ Add position limits

### Priority 2 (HIGH - Fix Soon)
5. ✅ Improve hedge trigger logic
6. ✅ Add better error handling for retcode 10019
7. ✅ Increase MIN_GRID_GAP to reduce entries

### Priority 3 (MEDIUM - Improvements)
8. Add emergency stop loss at account level
9. Add daily loss limit
10. Improve logging to reduce spam

---

## 🎯 Recommended Configuration Changes

```python
# More conservative settings
MIN_GRID_GAP = 1.5  # Increased from 0.5
LOT_MULTIPLIER = 0.8  # Reduce lot size in recovery
MAX_BUY_POSITIONS = 8  # Hard limit
MAX_TOTAL_POSITIONS = 12  # Including hedges
HEDGE_COOLDOWN = 60  # Seconds between hedges
HEDGE_RATIO = 0.3  # Reduced from 0.5
```

---

## 📝 Testing Checklist

Before running live again:
- [ ] Test hedge detection with demo account
- [ ] Verify balance checks work
- [ ] Confirm position limits enforced
- [ ] Test hedge cooldown timing
- [ ] Monitor for retcode 10019 errors
- [ ] Verify only ONE hedge opens per trigger

---

## 💡 Additional Recommendations

1. **Add Circuit Breaker:**
```python
MAX_DAILY_LOSS = 200.0  # Stop trading if daily loss exceeds this

def daily_loss_check():
    # Implement actual daily P&L tracking
    if daily_pnl < -MAX_DAILY_LOSS:
        log.critical(f"Daily loss limit hit: {daily_pnl}")
        close_all()
        sys.exit(1)
```

2. **Better Retcode Handling:**
```python
def send_order_with_retry(request, attempts=3, delay=0.2):
    for i in range(attempts):
        result = mt5.order_send(request)
        
        if result and result.retcode == mt5.TRADE_RETCODE_DONE:
            return result
        
        if result:
            # Don't retry on certain errors
            if result.retcode == 10019:  # No money
                log.error(f"Insufficient funds - stopping retries")
                return None
            
            log.warning(f"ORDER RETRY {i + 1}/{attempts} | retcode={result.retcode}")
        
        time.sleep(delay)
    
    log.error("ORDER FAILED AFTER RETRIES")
    return None
```

3. **Hedge Verification:**
```python
def verify_hedge_opened(expected_lot):
    """Verify hedge was actually opened"""
    time.sleep(0.5)  # Wait for position to register
    hedge = get_live_hedge()
    if hedge and abs(hedge.volume - expected_lot) < 0.001:
        return True
    log.error(f"Hedge verification failed! Expected {expected_lot} lot")
    return False
```

---

## 🔍 Root Cause Summary

The catastrophic failure was caused by a **perfect storm** of bugs:

1. **Magic number mismatch** → Unlimited hedges opened
2. **No balance check** → Continued trying to trade with no money
3. **No position limits** → Accumulated 25 positions
4. **No hedge cooldown** → Multiple hedges in seconds
5. **Weak trigger logic** → Hedges opened too late

**Result:** $108 loss in 6 minutes with 25 open positions.

---

## ✅ Success Criteria After Fixes

- Maximum 1 hedge position at a time
- No retcode 10019 errors
- Position count stays under limits
- Hedges open with proper cooldown
- Losses contained within risk parameters