"""
Database initialization script
Creates all tables and optionally seeds initial data
"""

from .database import init_db, engine
from .models import Base
import logging

logger = logging.getLogger(__name__)


def initialize_database():
    """Initialize database tables"""
    try:
        logger.info("Creating database tables...")
        init_db()
        logger.info("✓ Database tables created successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to initialize database: {e}")
        return False


def seed_initial_data():
    """Seed initial data (optional)"""
    # Add any initial data seeding here if needed
    pass


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    initialize_database()

# Made with Bob