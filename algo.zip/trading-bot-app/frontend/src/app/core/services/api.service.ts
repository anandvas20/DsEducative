import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

export interface BotStatus {
  buy_bot: {
    running: boolean;
    pid?: number;
    cpu_percent?: number;
    memory_mb?: number;
  };
  sell_bot: {
    running: boolean;
    pid?: number;
    cpu_percent?: number;
    memory_mb?: number;
  };
}

export interface Position {
  ticket: number;
  time: string;
  type: string;
  volume: number;
  price_open: number;
  price_current: number;
  sl: number;
  tp: number;
  profit: number;
  swap: number;
  comment: string;
  magic: number;
}

export interface AccountInfo {
  balance: number;
  equity: number;
  margin: number;
  free_margin: number;
  margin_level: number;
  profit: number;
  currency: string;
  leverage: number;
}

export interface PerformanceMetrics {
  total_trades: number;
  winning_trades: number;
  losing_trades: number;
  win_rate: number;
  total_profit: number;
  gross_profit: number;
  gross_loss: number;
  average_profit: number;
  average_loss: number;
  profit_factor: number;
  largest_win: number;
  largest_loss: number;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'http://localhost:8000/api';

  constructor(private http: HttpClient) {}

  private getHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Content-Type': 'application/json'
    });
  }

  private handleError(error: any): Observable<never> {
    console.error('API Error:', error);
    return throwError(() => error);
  }

  // Bot Control
  startBuyBot(): Observable<any> {
    return this.http.post(`${this.apiUrl}/bots/buy/start`, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  stopBuyBot(): Observable<any> {
    return this.http.post(`${this.apiUrl}/bots/buy/stop`, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  restartBuyBot(): Observable<any> {
    return this.http.post(`${this.apiUrl}/bots/buy/restart`, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  startSellBot(): Observable<any> {
    return this.http.post(`${this.apiUrl}/bots/sell/start`, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  stopSellBot(): Observable<any> {
    return this.http.post(`${this.apiUrl}/bots/sell/stop`, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  restartSellBot(): Observable<any> {
    return this.http.post(`${this.apiUrl}/bots/sell/restart`, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  getBotStatus(): Observable<BotStatus> {
    return this.http.get<BotStatus>(`${this.apiUrl}/bots/status`)
      .pipe(catchError(this.handleError));
  }

  stopAllBots(): Observable<any> {
    return this.http.post(`${this.apiUrl}/bots/stop-all`, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  // Positions
  getLivePositions(): Observable<Position[]> {
    return this.http.get<Position[]>(`${this.apiUrl}/positions/live`)
      .pipe(catchError(this.handleError));
  }

  getPositionHistory(days: number = 7): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/positions/history?days=${days}`)
      .pipe(catchError(this.handleError));
  }

  closePosition(ticket: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/positions/close/${ticket}`, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  closeAllPositions(type?: string): Observable<any> {
    const url = type ? `${this.apiUrl}/positions/close-all?position_type=${type}` : `${this.apiUrl}/positions/close-all`;
    return this.http.post(url, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  getPositionsSummary(): Observable<any> {
    return this.http.get(`${this.apiUrl}/positions/summary`)
      .pipe(catchError(this.handleError));
  }

  // Analytics
  getAccountInfo(): Observable<AccountInfo> {
    return this.http.get<AccountInfo>(`${this.apiUrl}/analytics/account`)
      .pipe(catchError(this.handleError));
  }

  getSymbolInfo(): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics/symbol`)
      .pipe(catchError(this.handleError));
  }

  getPerformanceMetrics(days: number = 7): Observable<PerformanceMetrics> {
    return this.http.get<PerformanceMetrics>(`${this.apiUrl}/analytics/performance?days=${days}`)
      .pipe(catchError(this.handleError));
  }


  // Configuration
  getConfig(): Observable<any> {
    return this.http.get(`${this.apiUrl}/config`)
      .pipe(catchError(this.handleError));
  }

  updateConfig(config: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/config`, config, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  getDefaultConfig(): Observable<any> {
    return this.http.get(`${this.apiUrl}/config/default`)
      .pipe(catchError(this.handleError));
  }

  resetConfig(): Observable<any> {
    return this.http.post(`${this.apiUrl}/config/reset`, {}, { headers: this.getHeaders() })
      .pipe(catchError(this.handleError));
  }

  // Analytics endpoints
  getAnalytics(days: number = 30): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics/statistics?days=${days}`)
      .pipe(catchError(this.handleError));
  }

  getTradeHistory(days: number = 30, limit: number = 100): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics/history?days=${days}&limit=${limit}`)
      .pipe(catchError(this.handleError));
  }

  getPendingOrders(): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics/pending-orders`)
      .pipe(catchError(this.handleError));
  }

  getDailyPnL(days: number = 30): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics/daily-pnl?days=${days}`)
      .pipe(catchError(this.handleError));
  }

  getEquityCurve(days: number = 7): Observable<any> {
    return this.http.get(`${this.apiUrl}/analytics/equity-curve?days=${days}`)
      .pipe(catchError(this.handleError));
  }
}

// Made with Bob
