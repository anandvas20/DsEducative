# 🤖 Gemini AI Trading Bot Setup Guide

## Overview
The trading bot now includes **Google Gemini AI** integration for intelligent trading decisions. The AI analyzes market data and provides BUY/SELL/HOLD signals with confidence levels.

---

## 📋 Prerequisites

### 1. Install Google Gemini AI Package
```bash
pip install google-genai
```

### 2. Get Gemini API Key
1. Visit [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Sign in with your Google account
3. Click "Create API Key"
4. Copy your API key

---

## 🔧 Configuration

### Set Environment Variable

**Windows (Command Prompt):**
```cmd
set GEMINI_API_KEY=your_api_key_here
```

**Windows (PowerShell):**
```powershell
$env:GEMINI_API_KEY="your_api_key_here"
```

**Linux/Mac:**
```bash
export GEMINI_API_KEY="your_api_key_here"
```

**Permanent Setup (Windows):**
1. Search "Environment Variables" in Windows
2. Click "Environment Variables"
3. Under "User variables", click "New"
4. Variable name: `GEMINI_API_KEY`
5. Variable value: Your API key
6. Click OK

**Permanent Setup (Linux/Mac):**
Add to `~/.bashrc` or `~/.zshrc`:
```bash
export GEMINI_API_KEY="your_api_key_here"
```

---

## 🚀 How It Works

### 1. Market Data Collection
The bot collects and sends **precomputed indicators** to Gemini (not raw OHLC):
- Current price
- RSI (14-period)
- MACD & MACD Signal
- EMA 20, 50, 200
- ATR (volatility)
- Support & Resistance levels
- Volume
- Trend direction (BULLISH/BEARISH)
- Multi-timeframe trend (M1, M5, M15)
- Spread

### 2. AI Analysis
Gemini AI analyzes the data using professional trading rules:

**BUY Signals:**
- Trend is BULLISH or STRONG_BULLISH
- RSI between 30-70 (not overbought)
- MACD > MACD_Signal (bullish crossover)
- Price near support or breaking resistance
- Multi-timeframe trend confirms

**SELL Signals:**
- Trend is BEARISH or STRONG_BEARISH
- RSI between 30-70 (not oversold)
- MACD < MACD_Signal (bearish crossover)
- Price near resistance or breaking support
- Multi-timeframe trend confirms

**HOLD Signals:**
- Conflicting signals
- RSI overbought (>70) or oversold (<30)
- Low confidence
- Mixed multi-timeframe trend

### 3. AI Response Format
```json
{
  "signal": "BUY|SELL|HOLD",
  "confidence": 85,
  "entry": 3350.25,
  "stop_loss": 3345.00,
  "take_profit_1": 3355.00,
  "take_profit_2": 3360.00,
  "reason": "Strong bullish trend with MACD crossover near support"
}
```

### 4. Decision Integration
- **High Confidence (≥70%)**: AI decision overrides traditional indicators
- **BUY Signal**: Confirms entry if other conditions met
- **SELL Signal**: Blocks BUY entry
- **HOLD Signal**: Blocks entry
- **Low Confidence (<70%)**: Falls back to traditional indicators

### 5. Caching
- AI decisions are cached for **180 seconds (3 minutes)**
- Reduces API calls and costs significantly
- Ensures consistent decisions within the cache period
- Only 1 API call every 3 minutes = ~480 calls/day
- Well within free tier limits

---

## 📊 Bot Behavior

### With Gemini AI Enabled:
```
1. Check AI signal (if confidence ≥70%)
   ├─ BUY → Proceed with entry checks
   ├─ SELL → Block BUY entry
   └─ HOLD → Block entry
2. Check Multi-Timeframe Analysis
3. Check Support/Resistance
4. Execute trade if all conditions pass
```

### Without Gemini AI (Fallback):
```
1. Check Multi-Timeframe Analysis
2. Check Support/Resistance
3. Execute trade if all conditions pass
```

---

## 🔍 Monitoring

### Log Messages

**AI Confirmation:**
```
✅ AI CONFIRMS BUY - Confidence: 85% | Reason: Strong bullish trend with MACD crossover
```

**AI Block:**
```
AI BLOCKS entry - Signal: HOLD | Confidence: 75% | Reason: RSI overbought, wait for pullback
```

**AI Cached Decision:**
```
Using cached AI decision: BUY (confidence: 85%)
```

**AI Error:**
```
Gemini API error: [error details]
```

---

## 💰 Cost Considerations

### Gemini API Pricing (as of 2024)
- **gemini-2.0-flash-exp**: FREE tier available
- **Rate Limits**: 15 requests per minute (free tier)
- **Token Limits**: Generous free quota

### Optimization
- **3-minute cache**: Reduces API calls by ~99.5%
- **Precomputed indicators**: Reduces token usage
- **Efficient prompts**: Minimizes response tokens

**Example Usage:**
- Without cache: 1 call per second = ~86,400 calls/day
- With 3-minute cache: ~480 calls/day
- Well within free tier limits (15 requests/minute)

---

## 🛠️ Configuration Options

### In `algo_withouthedge.py`:

```python
# Gemini Configuration
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GEMINI_MODEL = "gemini-2.0-flash-exp"  # Fast and efficient
GEMINI_ENABLED = GEMINI_AVAILABLE and len(GEMINI_API_KEY) > 0
GEMINI_CACHE_DURATION = 180  # Cache for 180 seconds (3 minutes)
```

**Adjust Cache Duration:**
- Current: 180 seconds (3 minutes) - Optimal balance
- Increase for fewer API calls (e.g., 300 seconds = 5 minutes)
- Decrease for more responsive AI (e.g., 120 seconds = 2 minutes)

**Change Model:**
- `gemini-2.0-flash-exp`: Fastest, free
- `gemini-1.5-pro`: More accurate, paid
- `gemini-1.5-flash`: Balanced

---

## 🧪 Testing

### Test AI Integration:
```python
# Run bot with AI enabled
python algo_withouthedge.py
```

### Check AI Status:
Look for startup message:
```
[IMPORT] Google Gemini AI loaded successfully
```

Or:
```
[WARNING] Google Gemini AI not available
[INFO] Bot will run without AI assistance
```

### Verify API Key:
```python
import os
print(os.getenv("GEMINI_API_KEY"))
```

---

## 🚨 Troubleshooting

### Issue: "Google Gemini AI not available"
**Solution:** Install the package
```bash
pip install google-genai
```

### Issue: "Gemini API error: 401 Unauthorized"
**Solution:** Check your API key
```bash
echo $GEMINI_API_KEY  # Linux/Mac
echo %GEMINI_API_KEY%  # Windows CMD
```

### Issue: "Rate limit exceeded"
**Solution:** Cache is already set to 3 minutes. If still hitting limits, increase further:
```python
GEMINI_CACHE_DURATION = 300  # 5 minutes
```

### Issue: "Invalid JSON response"
**Solution:** The bot automatically handles this and falls back to traditional indicators

---

## 📈 Performance Comparison

### Traditional Indicators Only:
- Entry decisions based on EMA, ATR, S/R
- Fixed rules
- No market context understanding

### With Gemini AI:
- ✅ Contextual market analysis
- ✅ Adaptive to market conditions
- ✅ Considers multiple factors simultaneously
- ✅ Provides reasoning for decisions
- ✅ High confidence filtering (≥70%)

---

## 🔐 Security Best Practices

1. **Never commit API keys to Git**
2. **Use environment variables**
3. **Rotate keys periodically**
4. **Monitor API usage**
5. **Set up billing alerts**

---

## 📝 Example Workflow

1. **Set API Key:**
   ```bash
   export GEMINI_API_KEY="your_key_here"
   ```

2. **Start Bot:**
   ```bash
   python algo_withouthedge.py
   ```

3. **Monitor Logs:**
   ```
   [IMPORT] Google Gemini AI loaded successfully
   AI Decision: BUY | Confidence: 85% | Reason: Strong bullish momentum
   ✅ AI CONFIRMS BUY - Confidence: 85%
   MTF Trend | M1:True | M5:True | M15:True | Strength:3/3
   ✅ FAVORABLE ENTRY - Near support
   ```

4. **Trade Executed:**
   ```
   BUY order placed: 0.01 lots @ 3350.25
   ```

---

## 🎯 Summary

- **Easy Setup**: Just install package and set API key
- **Intelligent Trading**: AI analyzes market conditions
- **Cost Effective**: Free tier sufficient for most users
- **Fallback Safe**: Works without AI if unavailable
- **High Confidence**: Only acts on ≥70% confidence signals
- **Cached Decisions**: 3-minute cache reduces API calls by 99.5%
- **Efficient**: Only ~480 API calls/day (well within free limits)

**Ready to trade smarter with AI! 🚀**