# 🔍 Issues Found in algo_withouthedge_sell.py

## Critical Issues Identified

### 1. ❌ Lot Index Never Resets
**Location:** Lines 873, 926-927

**Problem:**
```python
# First entry
if len(sell_positions) == 0:
    lot_index = 0  # ✅ Sets to 0 for first entry
    if sell(LOT_LADDER[lot_index]):
        entry_times.append(time.time())
    return

# Recovery entries
if gap >= dynamic_gap:
    if lot_index < len(LOT_LADDER) - 1:
        lot_index += 1  # ❌ Increments but NEVER resets!
    
    lot = LOT_LADDER[lot_index] * LOT_MULTIPLIER
```

**Issue:** 
- When all positions close and bot starts fresh, `lot_index` is still at the last value
- Example: If lot_index reached 8, next cycle starts at 8 instead of 0
- Bot will use maximum lot size (0.04) for first entry instead of 0.01!

**Impact:**
- Incorrect lot sizing on new cycles
- Higher risk on fresh entries
- Violates the ladder strategy

---

### 2. ❌ Lot Index Can Exceed Array Bounds
**Location:** Line 929

**Problem:**
```python
lot = LOT_LADDER[lot_index] * LOT_MULTIPLIER
```

**Issue:**
- LOT_LADDER has 9 elements (indices 0-8)
- lot_index can increment beyond 8 if positions keep opening
- Will cause IndexError: list index out of range

**Example Scenario:**
```
Position 1: lot_index = 0 → LOT_LADDER[0] = 0.01 ✅
Position 2: lot_index = 1 → LOT_LADDER[1] = 0.01 ✅
...
Position 9: lot_index = 8 → LOT_LADDER[8] = 0.04 ✅
Position 10: lot_index = 9 → LOT_LADDER[9] = ❌ CRASH!
```

---

### 3. ⚠️ Lot Multiplier Applied Incorrectly
**Location:** Line 929

**Problem:**
```python
lot = LOT_LADDER[lot_index] * LOT_MULTIPLIER  # 0.8
```

**Issue:**
- LOT_MULTIPLIER = 0.8 makes lots SMALLER, not larger
- Recovery entries should use LARGER lots, not smaller
- Example: 0.04 * 0.8 = 0.032 (smaller than intended)

**Expected Behavior:**
- Recovery should use progressively larger lots
- Multiplier should be ≥ 1.0 for martingale-style recovery

---

### 4. ⚠️ Lot Index Not Synchronized with Position Count
**Location:** Lines 926-927

**Problem:**
```python
if lot_index < len(LOT_LADDER) - 1:
    lot_index += 1
```

**Issue:**
- lot_index increments independently of actual positions
- If a sell order fails, lot_index still increments
- Next successful order uses wrong lot size

**Example:**
```
Position 1: lot_index=0, sell(0.01) ✅
Position 2: lot_index=1, sell(0.01) ❌ FAILED
Position 3: lot_index=2, sell(0.01) ✅ (should be index 1!)
```

---

## 📊 Current Configuration Analysis

```python
LOT_LADDER = [
    0.01,  # Index 0
    0.01,  # Index 1
    0.01,  # Index 2
    0.02,  # Index 3
    0.02,  # Index 4
    0.02,  # Index 5
    0.03,  # Index 6
    0.03,  # Index 7
    0.04   # Index 8
]

MAX_SELL_POSITIONS = 5  # But LOT_LADDER has 9 entries!
LOT_MULTIPLIER = 0.8    # Makes lots smaller, not larger!
```

**Mismatch:**
- LOT_LADDER supports 9 positions
- MAX_SELL_POSITIONS limits to 5
- Only indices 0-4 will be used (0.01, 0.01, 0.01, 0.02, 0.02)
- Indices 5-8 are unreachable

---

## ✅ Recommended Fixes

### Fix 1: Reset lot_index When Positions Close
```python
def grid_engine(df):
    global lot_index
    
    if df is None or len(df) < 50:
        return
    
    positions = get_positions(force=True)
    
    sell_positions = [
        p for p in positions
        if p.type == mt5.POSITION_TYPE_SELL
    ]
    
    # ✅ FIX: Reset lot_index when no positions
    if len(sell_positions) == 0:
        lot_index = 0  # Reset for fresh start
    
    # ... rest of code
```

### Fix 2: Use Position Count for Lot Index
```python
# Instead of incrementing lot_index, use position count
def grid_engine(df):
    global lot_index
    
    # ... position checks ...
    
    # First entry
    if len(sell_positions) == 0:
        lot_index = 0
        if sell(LOT_LADDER[lot_index]):
            entry_times.append(time.time())
        return
    
    # Recovery entries - use position count
    if gap >= dynamic_gap:
        # ✅ FIX: Use position count, not incremented index
        lot_index = min(len(sell_positions), len(LOT_LADDER) - 1)
        
        lot = LOT_LADDER[lot_index] * LOT_MULTIPLIER
        
        if sell(lot):
            entry_times.append(time.time())
```

### Fix 3: Adjust LOT_LADDER for MAX_SELL_POSITIONS
```python
# Match LOT_LADDER to MAX_SELL_POSITIONS
LOT_LADDER = [
    0.01,  # Position 1
    0.01,  # Position 2
    0.02,  # Position 3
    0.02,  # Position 4
    0.03   # Position 5
]

MAX_SELL_POSITIONS = 5
```

### Fix 4: Fix LOT_MULTIPLIER Logic
```python
# Option A: Remove multiplier (use ladder as-is)
lot = LOT_LADDER[lot_index]

# Option B: Use multiplier > 1.0 for aggressive recovery
LOT_MULTIPLIER = 1.2  # 20% larger for recovery
lot = LOT_LADDER[lot_index] * LOT_MULTIPLIER

# Option C: Apply multiplier only to recovery entries
if len(sell_positions) == 0:
    lot = LOT_LADDER[0]  # First entry: no multiplier
else:
    lot = LOT_LADDER[lot_index] * LOT_MULTIPLIER  # Recovery: with multiplier
```

---

## 🎯 Complete Fixed Version

```python
def grid_engine(df):
    """✅ FIXED: Proper lot index management"""
    global lot_index
    
    if df is None or len(df) < 50:
        return
    
    positions = get_positions(force=True)
    
    sell_positions = [
        p for p in positions
        if p.type == mt5.POSITION_TYPE_SELL
    ]
    
    # ✅ FIX: Reset lot_index when no positions
    if len(sell_positions) == 0:
        lot_index = 0
    
    # Position limit checks
    if len(sell_positions) >= MAX_SELL_POSITIONS:
        log.warning(
            f"Max sell positions reached: {len(sell_positions)}",
            throttle_key="max_sell_positions",
            throttle_interval=30
        )
        return
    
    if len(positions) >= MAX_TOTAL_POSITIONS:
        log.warning(
            f"Max total positions reached: {len(positions)}",
            throttle_key="max_total_positions",
            throttle_interval=30
        )
        return
    
    tick = safe_tick()
    if not tick:
        return
    
    ema_fast = df['ema_fast']
    ema_slow = df['ema_slow']
    atr_now = df['atr'].iloc[-1]
    
    # First entry with strong filters
    if len(sell_positions) == 0:
        # Entry cooldown check
        if entry_times:
            last_entry = entry_times[-1]
            if time.time() - last_entry < MIN_ENTRY_DELAY:
                return
        
        # RSI filter
        rsi_ok = df['rsi'].iloc[-1] > 35
        
        # ATR filter
        atr_ok = atr_now > latest_atr_mean * 0.8 if latest_atr_mean else True
        
        # Bearish candle confirmation
        bearish_candle = df['close'].iloc[-1] < df['open'].iloc[-1]
        
        # Combined entry signal
        bearish = (
            ema_fast.iloc[-1] < ema_slow.iloc[-1]
            and higher_tf_bearish()
            and rsi_ok
            and atr_ok
            and bearish_candle
        )
        
        if bearish and spread_ok(max_spread=35):
            # ✅ FIX: Use first lot without multiplier
            if sell(LOT_LADDER[0]):
                entry_times.append(time.time())
            return
    
    # Grid recovery entries
    last_price = last_sell_price()
    
    # Prevent selling into strong uptrends
    strong_uptrend = (
        ema_fast.iloc[-1] > ema_slow.iloc[-1]
        and ema_fast.iloc[-2] > ema_slow.iloc[-2]
    )
    
    if strong_uptrend:
        log.warning(
            "Strong uptrend detected - skipping recovery entry",
            throttle_key="uptrend_skip",
            throttle_interval=30
        )
        return
    
    # Entry cooldown for recovery
    if entry_times:
        last_entry = entry_times[-1]
        if time.time() - last_entry < MIN_ENTRY_DELAY:
            return
    
    gap = abs(tick.ask - last_price)
    
    # Adaptive grid spacing
    base_gap = 3.0
    position_gap = math.pow(len(sell_positions), 1.4)
    atr_gap = atr_now * 0.7
    
    dynamic_gap = max(
        base_gap + position_gap,
        atr_gap
    )
    
    log.info(
        f"Grid Gap={dynamic_gap:.2f} | "
        f"Current Gap={gap:.2f} | "
        f"Positions={len(sell_positions)}",
        throttle_key="grid_gap",
        throttle_interval=5
    )
    
    if gap >= dynamic_gap:
        # ✅ FIX: Use position count for lot index with bounds check
        lot_index = min(len(sell_positions), len(LOT_LADDER) - 1)
        
        # ✅ FIX: Use lot without multiplier (or use multiplier > 1.0)
        lot = LOT_LADDER[lot_index]
        
        if sell(lot):
            entry_times.append(time.time())
```

---

## 📋 Summary of Changes Needed

1. ✅ Reset `lot_index = 0` when `len(sell_positions) == 0`
2. ✅ Use `lot_index = min(len(sell_positions), len(LOT_LADDER) - 1)` for recovery
3. ✅ Remove or fix `LOT_MULTIPLIER` (currently makes lots smaller)
4. ✅ Align `LOT_LADDER` size with `MAX_SELL_POSITIONS`
5. ✅ Add bounds checking to prevent array index errors

---

## 🧪 Testing Scenarios

After fixes, test these scenarios:

1. **Fresh Start:** First position should use 0.01 lot
2. **Recovery:** Each position should use correct ladder lot
3. **Position Close:** After all close, next cycle starts at 0.01
4. **Max Positions:** Should stop at position 5 with 0.03 lot
5. **Failed Orders:** lot_index should match actual position count

---

## ⚠️ Risk Assessment

**Before Fixes:**
- 🔴 HIGH: Can crash with IndexError
- 🔴 HIGH: Wrong lot sizes on new cycles
- 🟡 MEDIUM: Lot multiplier reduces instead of increases lots

**After Fixes:**
- 🟢 LOW: Proper lot sizing
- 🟢 LOW: No array bounds errors
- 🟢 LOW: Consistent behavior across cycles