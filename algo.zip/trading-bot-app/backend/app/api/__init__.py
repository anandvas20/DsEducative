"""
API package for trading bot management
"""

# Made with Bob