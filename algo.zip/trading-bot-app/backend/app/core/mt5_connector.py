"""
MT5 Connector - Interface with MetaTrader 5
"""

import MetaTrader5 as mt5
from typing import List, Dict, Optional
from datetime import datetime
import pandas as pd


class MT5Connector:
    """MetaTrader 5 connection and data fetching"""
    
    def __init__(self):
        self.connected = False
        self.symbol = "XAUUSDm"
    
    def connect(self, login: Optional[int] = None, password: Optional[str] = None, 
                server: Optional[str] = None) -> bool:
        """Connect to MT5"""
        if not mt5.initialize():
            print("MT5 initialization failed")
            return False
        
        if login and password and server:
            if not mt5.login(login, password, server):
                print(f"MT5 login failed: {mt5.last_error()}")
                return False
        
        self.connected = True
        return True
    
    def disconnect(self):
        """Disconnect from MT5"""
        mt5.shutdown()
        self.connected = False
    
    def get_positions(self) -> List[Dict]:
        """Get all open positions"""
        if not self.connected:
            return []
        
        positions = mt5.positions_get(symbol=self.symbol)
        if positions is None:
            return []
        
        result = []
        for pos in positions:
            result.append({
                "ticket": pos.ticket,
                "time": datetime.fromtimestamp(pos.time).isoformat(),
                "type": "BUY" if pos.type == mt5.POSITION_TYPE_BUY else "SELL",
                "volume": pos.volume,
                "price_open": pos.price_open,
                "price_current": pos.price_current,
                "sl": pos.sl,
                "tp": pos.tp,
                "profit": pos.profit,
                "swap": pos.swap,
                "comment": pos.comment,
                "magic": pos.magic
            })
        
        return result
    
    def get_account_info(self) -> Dict:
        """Get account information"""
        if not self.connected:
            return {}
        
        account = mt5.account_info()
        if account is None:
            return {}
        
        return {
            "balance": account.balance,
            "equity": account.equity,
            "margin": account.margin,
            "free_margin": account.margin_free,
            "margin_level": account.margin_level,
            "profit": account.profit,
            "currency": account.currency,
            "leverage": account.leverage
        }
    
    def get_symbol_info(self) -> Dict:
        """Get symbol information"""
        if not self.connected:
            return {}
        
        symbol_info = mt5.symbol_info(self.symbol)
        if symbol_info is None:
            return {}
        
        tick = mt5.symbol_info_tick(self.symbol)
        
        return {
            "symbol": self.symbol,
            "bid": tick.bid if tick else 0,
            "ask": tick.ask if tick else 0,
            "spread": (tick.ask - tick.bid) if tick else 0,
            "digits": symbol_info.digits,
            "point": symbol_info.point,
            "volume_min": symbol_info.volume_min,
            "volume_max": symbol_info.volume_max,
            "volume_step": symbol_info.volume_step
        }
    
    def close_position(self, ticket: int) -> Dict:
        """Close a specific position"""
        if not self.connected:
            return {"status": "error", "message": "Not connected to MT5"}
        
        position = mt5.positions_get(ticket=ticket)
        if not position:
            return {"status": "error", "message": "Position not found"}
        
        position = position[0]
        
        # Determine order type (opposite of position type)
        order_type = mt5.ORDER_TYPE_SELL if position.type == mt5.POSITION_TYPE_BUY else mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(self.symbol).bid if order_type == mt5.ORDER_TYPE_SELL else mt5.symbol_info_tick(self.symbol).ask
        
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "position": ticket,
            "symbol": self.symbol,
            "volume": position.volume,
            "type": order_type,
            "price": price,
            "magic": position.magic,
            "comment": "Closed via API",
        }
        
        result = mt5.order_send(request)
        
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            return {
                "status": "error",
                "message": f"Failed to close position: {result.comment}",
                "retcode": result.retcode
            }
        
        return {
            "status": "success",
            "message": "Position closed successfully",
            "ticket": ticket,
            "profit": position.profit
        }
    
    def close_all_positions(self, position_type: Optional[str] = None) -> Dict:
        """Close all positions (optionally filtered by type)"""
        if not self.connected:
            return {"status": "error", "message": "Not connected to MT5"}
        
        positions = self.get_positions()
        
        if position_type:
            positions = [p for p in positions if p["type"] == position_type]
        
        closed_count = 0
        failed_count = 0
        total_profit = 0.0
        
        for pos in positions:
            result = self.close_position(pos["ticket"])
            if result["status"] == "success":
                closed_count += 1
                total_profit += result.get("profit", 0)
            else:
                failed_count += 1
        
        return {
            "status": "success" if failed_count == 0 else "partial",
            "closed": closed_count,
            "failed": failed_count,
            "total_profit": total_profit
        }
    
    def get_history(self, days: int = 7) -> List[Dict]:
        """Get trade history for the last N days"""
        if not self.connected:
            return []
        
        from_date = datetime.now().timestamp() - (days * 24 * 60 * 60)
        to_date = datetime.now().timestamp()
        
        deals = mt5.history_deals_get(from_date, to_date, group=self.symbol)
        if deals is None:
            return []
        
        result = []
        for deal in deals:
            result.append({
                "ticket": deal.ticket,
                "order": deal.order,
                "time": datetime.fromtimestamp(deal.time).isoformat(),
                "type": "BUY" if deal.type == mt5.DEAL_TYPE_BUY else "SELL",
                "volume": deal.volume,
                "price": deal.price,
                "profit": deal.profit,
                "swap": deal.swap,
                "commission": deal.commission,
                "comment": deal.comment,
                "magic": deal.magic
            })
        
        return result
    
    def get_pending_orders(self) -> List[Dict]:
        """Get all pending orders"""
        if not self.connected:
            return []
        
        orders = mt5.orders_get(symbol=self.symbol)
        if orders is None:
            return []
        
        result = []
        for order in orders:
            result.append({
                "ticket": order.ticket,
                "time_setup": datetime.fromtimestamp(order.time_setup).isoformat(),
                "type": self._get_order_type_string(order.type),
                "volume": order.volume_current,
                "price_open": order.price_open,
                "sl": order.sl,
                "tp": order.tp,
                "price_current": order.price_current,
                "symbol": order.symbol,
                "comment": order.comment,
                "magic": order.magic
            })
        
        return result
    
    def _get_order_type_string(self, order_type: int) -> str:
        """Convert order type to string"""
        order_types = {
            mt5.ORDER_TYPE_BUY: "BUY",
            mt5.ORDER_TYPE_SELL: "SELL",
            mt5.ORDER_TYPE_BUY_LIMIT: "BUY_LIMIT",
            mt5.ORDER_TYPE_SELL_LIMIT: "SELL_LIMIT",
            mt5.ORDER_TYPE_BUY_STOP: "BUY_STOP",
            mt5.ORDER_TYPE_SELL_STOP: "SELL_STOP",
            mt5.ORDER_TYPE_BUY_STOP_LIMIT: "BUY_STOP_LIMIT",
            mt5.ORDER_TYPE_SELL_STOP_LIMIT: "SELL_STOP_LIMIT"
        }
        return order_types.get(order_type, "UNKNOWN")


# Global MT5 connector instance
mt5_connector = MT5Connector()

# Made with Bob
