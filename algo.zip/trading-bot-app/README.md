# 📊 Trading Bot Management Application

A full-stack web application for managing and monitoring XAU/USD (Gold) trading bots with real-time updates, analytics, and AI-powered insights.

## 🏗️ Architecture

- **Frontend**: Angular 17+ (TypeScript)
- **Backend**: Python FastAPI
- **Real-time**: WebSockets (Socket.IO)
- **Trading Platform**: MetaTrader 5
- **AI**: Google Gemini AI

## 📁 Project Structure

```
trading-bot-app/
├── backend/                    # Python FastAPI backend
│   ├── app/
│   │   ├── api/
│   │   │   └── routes/        # API endpoints
│   │   ├── core/              # Core functionality
│   │   ├── models/            # Database models
│   │   ├── schemas/           # Pydantic schemas
│   │   └── main.py            # FastAPI app
│   └── requirements.txt
│
└── frontend/                   # Angular frontend
    ├── src/
    │   ├── app/
    │   │   ├── core/          # Services & guards
    │   │   ├── features/      # Feature modules
    │   │   └── shared/        # Shared components
    │   └── environments/
    └── package.json
```

## 🚀 Quick Start

### Prerequisites

- Python 3.10+
- Node.js 18+ & npm
- MetaTrader 5 installed
- PostgreSQL (optional, for trade history)
- Redis (optional, for caching)

### Backend Setup

1. **Navigate to backend directory**
```bash
cd trading-bot-app/backend
```

2. **Create virtual environment**
```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Create .env file**
```bash
cat > .env << EOF
# MT5 Credentials
MT5_LOGIN=your_login
MT5_PASSWORD=your_password
MT5_SERVER=your_server

# Database (optional)
DATABASE_URL=postgresql://user:password@localhost:5432/trading_bot

# Redis (optional)
REDIS_HOST=localhost
REDIS_PORT=6379

# Security
SECRET_KEY=your-secret-key-change-this
EOF
```

5. **Run the backend**
```bash
cd app
python main.py
```

Backend will be available at: `http://localhost:8000`
API docs at: `http://localhost:8000/docs`

### Frontend Setup

1. **Navigate to frontend directory**
```bash
cd trading-bot-app/frontend
```

2. **Install Angular CLI globally** (if not installed)
```bash
npm install -g @angular/cli
```

3. **Create Angular project**
```bash
ng new trading-bot-frontend --routing --style=scss
cd trading-bot-frontend
```

4. **Install dependencies**
```bash
npm install socket.io-client
npm install chart.js ng2-charts
npm install @angular/material @angular/cdk
```

5. **Run the frontend**
```bash
ng serve
```

Frontend will be available at: `http://localhost:4200`

## 📡 API Endpoints

### Bot Control
- `POST /api/bots/buy/start` - Start BUY bot
- `POST /api/bots/buy/stop` - Stop BUY bot
- `POST /api/bots/sell/start` - Start SELL bot
- `POST /api/bots/sell/stop` - Stop SELL bot
- `GET /api/bots/status` - Get bot status

### Positions
- `GET /api/positions/live` - Get open positions
- `GET /api/positions/history` - Get trade history
- `POST /api/positions/close/{ticket}` - Close position
- `POST /api/positions/close-all` - Close all positions
- `GET /api/positions/summary` - Get positions summary

### Analytics
- `GET /api/analytics/account` - Get account info
- `GET /api/analytics/performance` - Get performance metrics
- `GET /api/analytics/equity-curve` - Get equity curve
- `GET /api/analytics/daily-pnl` - Get daily P&L

### Configuration
- `GET /api/config` - Get configuration
- `PUT /api/config` - Update configuration
- `POST /api/config/reset` - Reset to defaults

## 🔌 WebSocket Events

### Client → Server
- `subscribe_positions` - Subscribe to position updates
- `subscribe_logs` - Subscribe to log updates
- `subscribe_pnl` - Subscribe to P&L updates

### Server → Client
- `position_update` - Real-time position changes
- `log_message` - New log entries
- `pnl_update` - P&L updates
- `bot_status_change` - Bot started/stopped

## 🎨 Features

### Dashboard
- Real-time P&L display
- Active positions count
- Bot status indicators
- Performance charts
- Win rate & profit factor

### Bot Control
- Start/Stop BUY bot
- Start/Stop SELL bot
- Emergency close all positions
- Bot health monitoring

### Live Positions
- Real-time position list
- Individual position close
- Bulk actions
- P&L tracking

### Analytics
- Equity curve
- Daily P&L chart
- Win/Loss distribution
- Trade history table
- Export to CSV

### Configuration
- Edit bot parameters
- Lot ladder configuration
- Grid spacing settings
- AI settings
- Save/Load presets

### AI Insights
- Current Gemini AI signal
- Entry decision (BUY/WAIT/AVOID)
- Confidence level
- Market context
- Risk warnings

## 🔧 Configuration

### Bot Parameters

**BUY Bot:**
- Symbol: XAUUSDm
- Magic: 777
- Lot Ladder: [0.01, 0.02, 0.04, 0.06, 0.08, 0.12, 0.14, 0.15, 0.16]
- Min Grid Gap: 5.0
- Max Positions: 9

**SELL Bot:**
- Symbol: XAUUSDm
- Magic: 20241202
- Lot Ladder: [0.01, 0.02, 0.04, 0.06, 0.08, 0.12, 0.14, 0.15, 0.16]
- Min Grid Gap: 5.0
- Max Positions: 9

### Risk Management
- Max Daily Loss: $200
- Max Total Positions: 12
- Min Entry Delay: 120 seconds

## 🛠️ Development

### Backend Development
```bash
cd backend/app
uvicorn main:socket_app --reload --host 0.0.0.0 --port 8000
```

### Frontend Development
```bash
cd frontend/trading-bot-frontend
ng serve --open
```

### Run Tests
```bash
# Backend
pytest

# Frontend
ng test
```

## 📦 Deployment

### Backend (Production)
```bash
# Using Gunicorn
gunicorn -w 4 -k uvicorn.workers.UvicornWorker app.main:socket_app --bind 0.0.0.0:8000

# Using Docker
docker build -t trading-bot-backend .
docker run -p 8000:8000 trading-bot-backend
```

### Frontend (Production)
```bash
# Build for production
ng build --configuration production

# Serve with Nginx
# Copy dist/ folder to /var/www/html/
```

## 🔒 Security

- Change `SECRET_KEY` in production
- Use environment variables for sensitive data
- Enable HTTPS in production
- Implement authentication (JWT)
- Rate limiting on API endpoints

## 📊 Monitoring

- Bot process health checks
- MT5 connection status
- API response times
- WebSocket connection status
- Error logging

## 🐛 Troubleshooting

### MT5 Connection Issues
- Verify MT5 is running
- Check login credentials
- Ensure symbol "XAUUSDm" exists
- Check firewall settings

### Bot Not Starting
- Check bot file paths in config
- Verify Python environment
- Check log files for errors
- Ensure MT5 is connected

### WebSocket Not Connecting
- Check CORS settings
- Verify backend is running
- Check browser console for errors
- Ensure port 8000 is accessible

## 📝 License

MIT License - feel free to use for personal or commercial projects

## 🤝 Contributing

Contributions welcome! Please open an issue or submit a pull request.

## 📧 Support

For issues or questions, please open a GitHub issue.

---

**Built with ❤️ for algorithmic traders**