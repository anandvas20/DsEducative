#!/usr/bin/env python3
"""
Gemini API Key Test Script
Tests if the Gemini API key is valid and working using the same prompt as the trading bot
"""

import sys
import os
import json
import time

# Try to import the google-genai package
try:
    from google import genai
    GEMINI_AVAILABLE = True
    print("✅ google-genai package is installed")
except ImportError:
    GEMINI_AVAILABLE = False
    print("❌ google-genai package is NOT installed")
    print("   Install it with: pip install google-genai")
    sys.exit(1)

# Configuration
GEMINI_API_KEY = "AQ.Ab8RN6L0AQS87ZzRnJ6ZSGwt12TCSE-8b7eRYgtdJahtCOGOyg"
GEMINI_MODEL = "gemini-3.1-flash-lite"

def test_gemini_api():
    """Test Gemini API connection and functionality using actual trading bot prompt"""
    
    print("\n" + "="*80)
    print("GEMINI API KEY TEST - USING ACTUAL TRADING BOT PROMPT")
    print("="*80)
    
    # Check if API key is set
    if not GEMINI_API_KEY or len(GEMINI_API_KEY) < 10:
        print("❌ API Key is not set or too short")
        print(f"   Current key length: {len(GEMINI_API_KEY)}")
        return False
    
    print(f"✅ API Key is set (length: {len(GEMINI_API_KEY)})")
    print(f"   Key preview: {GEMINI_API_KEY[:10]}...{GEMINI_API_KEY[-10:]}")
    
    # Test API connection
    try:
        print(f"\n📡 Testing connection to Gemini API...")
        print(f"   Model: {GEMINI_MODEL}")
        
        # Initialize client
        client = genai.Client(api_key=GEMINI_API_KEY)
        print("✅ Client initialized successfully")
        
        # Prepare realistic market data (same format as trading bot)
        market_data = {
            "symbol": "XAUUSDm",
            "timeframe": "M1",
            "price": 2650.50,
            "rsi": 58.32,
            "macd": 0.0234,
            "macd_signal": 0.0189,
            "ema20": 2649.80,
            "ema50": 2647.20,
            "ema200": 2640.50,
            "atr": 2.45,
            "support": 2645.00,
            "resistance": 2655.00,
            "volume": 1250,
            "trend": "BULLISH",
            "mtf_trend": "STRONG_BULLISH",
            "spread": 0.35
        }
        
        market_data_json = json.dumps(market_data, indent=2)
        
        # Use the EXACT same prompt as the trading bot
        prompt = f"""
You are a professional gold (XAU/USD) trading AI. Analyze the market data and return ONLY valid JSON.

Market Data:
{market_data_json}

Trading Rules:
1. BUY when:
   - Trend is BULLISH or STRONG_BULLISH
   - RSI between 30-70 (not overbought)
   - MACD > MACD_Signal (bullish crossover)
   - Price near support or breaking resistance
   - Multi-timeframe trend confirms

2. SELL when:
   - Trend is BEARISH or STRONG_BEARISH
   - RSI between 30-70 (not oversold)
   - MACD < MACD_Signal (bearish crossover)
   - Price near resistance or breaking support
   - Multi-timeframe trend confirms

3. HOLD when:
   - Conflicting signals
   - RSI overbought (>70) or oversold (<30)
   - Low confidence
   - Mixed multi-timeframe trend

Return ONLY this JSON format (no markdown, no explanation):
{{
  "signal": "BUY|SELL|HOLD",
  "confidence": 0-100,
  "entry": price_level,
  "stop_loss": price_level,
  "take_profit_1": price_level,
  "take_profit_2": price_level,
  "reason": "brief_explanation"
}}
"""
        
        print("\n" + "="*80)
        print("📤 SENDING PROMPT TO GEMINI API:")
        print("="*80)
        print(prompt)
        print("="*80)
        
        # Call Gemini API
        print("\n⏳ Waiting for API response...")
        start_time = time.time()
        
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt
        )
        
        elapsed_time = time.time() - start_time
        
        if response and response.text:
            response_text = response.text.strip()
            
            print("\n" + "="*80)
            print(f"📥 RECEIVED RESPONSE (took {elapsed_time:.2f}s):")
            print("="*80)
            print(response_text)
            print("="*80)
            
            # Try to parse as JSON (same as trading bot)
            try:
                # Remove markdown code blocks if present
                cleaned_response = response_text
                if cleaned_response.startswith("```"):
                    cleaned_response = cleaned_response.split("```")[1]
                    if cleaned_response.startswith("json"):
                        cleaned_response = cleaned_response[4:]
                    cleaned_response = cleaned_response.strip()
                
                result = json.loads(cleaned_response)
                
                print("\n✅ JSON PARSING SUCCESSFUL!")
                print("\n📊 PARSED TRADING SIGNAL:")
                print("="*80)
                print(f"  Signal:        {result.get('signal', 'N/A')}")
                print(f"  Confidence:    {result.get('confidence', 'N/A')}%")
                print(f"  Entry:         {result.get('entry', 'N/A')}")
                print(f"  Stop Loss:     {result.get('stop_loss', 'N/A')}")
                print(f"  Take Profit 1: {result.get('take_profit_1', 'N/A')}")
                print(f"  Take Profit 2: {result.get('take_profit_2', 'N/A')}")
                print(f"  Reason:        {result.get('reason', 'N/A')}")
                print("="*80)
                
                # Validate required keys
                required_keys = ["signal", "confidence", "entry", "stop_loss", "take_profit_1", "take_profit_2", "reason"]
                missing_keys = [key for key in required_keys if key not in result]
                
                if missing_keys:
                    print(f"\n⚠️  WARNING: Missing keys in response: {missing_keys}")
                    return False
                
                print("\n" + "="*80)
                print("✅ ALL TESTS PASSED - API KEY IS VALID AND WORKING!")
                print("✅ Response format matches trading bot requirements!")
                print("="*80)
                return True
                
            except json.JSONDecodeError as e:
                print(f"\n❌ JSON PARSING FAILED: {e}")
                print("   The API returned text but it's not valid JSON")
                return False
        else:
            print("❌ API returned empty response")
            return False
            
    except Exception as e:
        print(f"\n❌ ERROR: {type(e).__name__}")
        print(f"   Message: {str(e)}")
        
        # Provide helpful error messages
        if "API_KEY_INVALID" in str(e) or "invalid" in str(e).lower():
            print("\n💡 Troubleshooting:")
            print("   - Check if your API key is correct")
            print("   - Verify the key hasn't expired")
            print("   - Make sure you're using the correct key format")
        elif "RATE_LIMIT" in str(e) or "quota" in str(e).lower():
            print("\n💡 Troubleshooting:")
            print("   - You may have exceeded the rate limit")
            print("   - Free tier: 10 requests per minute, 1,500 per day")
            print("   - Wait a few minutes and try again")
        elif "PERMISSION_DENIED" in str(e):
            print("\n💡 Troubleshooting:")
            print("   - Check if the API key has proper permissions")
            print("   - Verify the model name is correct")
        else:
            print("\n💡 Troubleshooting:")
            print("   - Check your internet connection")
            print("   - Verify the google-genai package is up to date")
            print("   - Try: pip install --upgrade google-genai")
        
        print("\n" + "="*60)
        print("❌ TEST FAILED")
        print("="*60)
        return False

def check_rate_limits():
    """Display information about Gemini API rate limits"""
    print("\n" + "="*60)
    print("GEMINI API RATE LIMITS (Free Tier)")
    print("="*60)
    print("\nModel: gemini-2.5-flash")
    print("  • Requests per minute (RPM): 10")
    print("  • Requests per day (RPD): 1,500")
    print("  • Tokens per minute (TPM): 1,000,000")
    print("\nModel: gemini-2.5-flash-lite (Alternative)")
    print("  • Requests per minute (RPM): 15")
    print("  • Requests per day (RPD): 1,500")
    print("  • Tokens per minute (TPM): 1,000,000")
    print("\n💡 Tips:")
    print("  • Use background updater with 10-minute intervals")
    print("  • Cache responses to reduce API calls")
    print("  • Monitor your usage at: https://aistudio.google.com")
    print("="*60)

if __name__ == "__main__":
    print("\n🚀 Starting Gemini API Test...\n")
    
    # Run the test
    success = test_gemini_api()
    
    # Show rate limit info
    check_rate_limits()
    
    # Exit with appropriate code
    if success:
        print("\n✅ Test completed successfully!")
        sys.exit(0)
    else:
        print("\n❌ Test failed. Please check the errors above.")
        sys.exit(1)

# Made with Bob
