
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("=" * 60)
print("GOLD ALGO BOT - LOADING...")
print("=" * 60)

import os
import sys
import time
import json
import math
import logging
import threading
import traceback
from queue import Queue
from collections import deque
from functools import wraps
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor
from logging.handlers import RotatingFileHandler

print("[IMPORT] Standard libraries loaded successfully")

# Try importing required packages with error handling
try:
    import MetaTrader5 as mt5
    print("[IMPORT] MetaTrader5 loaded successfully")
except ImportError as e:
    print(f"\n[ERROR] Failed to import MetaTrader5: {e}")
    print("[FIX] Install with: pip install MetaTrader5")
    sys.exit(1)

try:
    import numpy as np
    print("[IMPORT] NumPy loaded successfully")
except ImportError as e:
    print(f"\n[ERROR] Failed to import numpy: {e}")
    print("[FIX] Install with: pip install numpy")
    sys.exit(1)

try:
    import pandas as pd
    print("[IMPORT] Pandas loaded successfully")
except ImportError as e:
    print(f"\n[ERROR] Failed to import pandas: {e}")
    print("[FIX] Install with: pip install pandas")
    sys.exit(1)

try:
    from google import genai
    print("[IMPORT] Google Gemini AI loaded successfully")
    GEMINI_AVAILABLE = True
except ImportError as e:
    print(f"\n[WARNING] Google Gemini AI not available: {e}")
    print("[INFO] Install with: pip install google-genai")
    print("[INFO] Bot will run without AI assistance")
    GEMINI_AVAILABLE = False

print("[IMPORT] All required packages loaded successfully\n")

# =========================================================
# ADVANCED LOGGING CONFIGURATION
# =========================================================

class ThrottledLogger:
    """
    Advanced logging system with throttling,
    rotation, and structured logging.
    """

    def __init__(self, name="GoldAlgoBot"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)  # Changed from DEBUG to INFO
        self.logger.propagate = False

        # Clear existing handlers
        self.logger.handlers.clear()

        # Throttle tracking
        self._throttle_cache = {}
        self._throttle_lock = threading.Lock()

        # Performance metrics
        self._perf_metrics = {}
        self._perf_lock = threading.Lock()

        self._setup_handlers()

    def _setup_handlers(self):
        """Optimized logging setup - reduced file handlers and backup counts"""
        simple_formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(message)s',
            datefmt='%H:%M:%S'
        )

        # Console handler only - minimal logging
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.WARNING)  # Only warnings and errors to console
        console_handler.setFormatter(simple_formatter)
        self.logger.addHandler(console_handler)

        # Single main log file - larger size, fewer backups
        main_file_handler = RotatingFileHandler(
            'gold_grid_bot.log',
            maxBytes=50 * 1024 * 1024,  # 50MB before rotation
            backupCount=2,  # Keep only 2 backups
            encoding='utf-8'
        )
        main_file_handler.setLevel(logging.INFO)
        main_file_handler.setFormatter(simple_formatter)
        self.logger.addHandler(main_file_handler)

    def throttle(self, key, interval=5.0):
        with self._throttle_lock:
            now = time.time()
            last_time = self._throttle_cache.get(key, 0)

            if now - last_time >= interval:
                self._throttle_cache[key] = now
                return True

            return False

    def debug(self, msg, throttle_key=None, throttle_interval=5.0):
        if throttle_key:
            if not self.throttle(throttle_key, throttle_interval):
                return

        self.logger.debug(msg)

    def info(self, msg, throttle_key=None, throttle_interval=5.0):
        if throttle_key:
            if not self.throttle(throttle_key, throttle_interval):
                return

        self.logger.info(msg)

    def warning(self, msg, throttle_key=None, throttle_interval=5.0):
        if throttle_key:
            if not self.throttle(throttle_key, throttle_interval):
                return

        self.logger.warning(msg)

    def error(self, msg, exc_info=False, throttle_key=None, throttle_interval=5.0):
        if throttle_key:
            if not self.throttle(throttle_key, throttle_interval):
                return

        self.logger.error(msg, exc_info=exc_info)

    def critical(self, msg, exc_info=False):
        self.logger.critical(msg, exc_info=exc_info)

    def trade(self, action, **kwargs):
        details = " | ".join([f"{k}={v}" for k, v in kwargs.items()])
        self.logger.info(f"TRADE | {action} | {details}")


# =========================================================
# LOGGER INIT
# =========================================================

log = ThrottledLogger("GoldAlgoBot")


# =========================================================
# PERFORMANCE DECORATOR
# =========================================================

def monitor_performance(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()

        try:
            result = func(*args, **kwargs)
            duration = time.time() - start_time

            log.debug(
                f"PERF | {func.__name__} | {duration:.4f}s",
                throttle_key=f"perf_{func.__name__}",
                throttle_interval=10
            )

            return result

        except Exception as e:
            log.error(
                f"Exception in {func.__name__}: {str(e)}",
                exc_info=True
            )
            raise

    return wrapper


# =========================================================
# GLOBAL CONFIG
# =========================================================

SYMBOL = "XAUUSDm"
MAGIC = 777
TIMEFRAME = mt5.TIMEFRAME_M1

EMA_FAST = 5
EMA_SLOW = 9

LOT_LADDER = [
    0.01,
    0.02,
    0.04,
    0.06,
    0.08,
    0.12,
    0.14,
    0.15,
    0.16
]

STATE_FILE = "bot_state.json"

# Hedge configuration
MIN_GRID_GAP = 5.0  # ✅ INCREASED to 5.0 for more conservative spacing
LOT_MULTIPLIER = 1.0  # ✅ UPDATED: Use full lot sizes from LOT_LADDER

# Position limits - NEW
MAX_BUY_POSITIONS = 9  # ✅ UPDATED: Matches LOT_LADDER length (9 entries)
MAX_TOTAL_POSITIONS = 12
MAX_DAILY_LOSS = 200.0  # Stop trading if daily loss exceeds this

# =========================================================
# GEMINI AI CONFIGURATION
# =========================================================

GEMINI_API_KEY = "AQ.Ab8RN6L0AQS87ZzRnJ6ZSGwt12TCSE-8b7eRYgtdJahtCOGOyg" # Set via environment variable
GEMINI_MODEL = "gemini-3.1-flash-lite" # Full model path for google-genai package
GEMINI_ENABLED = GEMINI_AVAILABLE and len(GEMINI_API_KEY) > 0

# Background updater configuration - OPTIMIZED FOR FREE TIER
# Free Tier Limits (gemini-2.5-flash): 10 RPM, 1,500 RPD
# Alternative: gemini-2.5-flash-lite has 15 RPM for faster updates
GEMINI_UPDATE_INTERVAL = 600  # Update cache every 10 minutes (144 requests/day - safe for free tier)
GEMINI_MAX_RETRIES = 2  # Maximum retry attempts (reduced to avoid RPM breach)
GEMINI_RETRY_DELAY = 90  # Base retry delay in seconds (>60s to avoid RPM limit)
GEMINI_RATE_LIMIT_COOLDOWN = 600  # Cooldown period in seconds after hitting rate limit (10 minutes)

# Gemini AI cache - updated by background thread (enhanced structure)
gemini_ai_cache = {
    'entry_decision': {},
    'market_context': {},
    'technical_assessment': {},
    'risk_warnings': [],
    'entry_timing': {},
    'position_sizing': {},
    'legacy_fields': {},  # For backward compatibility
    'timestamp': 0,
    'is_valid': False
}

# Rate limiting tracking
gemini_rate_limit_tracker = {
    'last_error_time': 0,
    'error_count': 0,
    'in_cooldown': False,
    'cooldown_until': 0,
    'last_update_attempt': 0
}

# Background thread control
gemini_background_thread = None
gemini_thread_running = False
gemini_thread_lock = threading.Lock()

# AI decision cache
ai_decision_cache = {
    'signal': None,
    'timestamp': 0,
    'confidence': 0
}


# =========================================================
# GLOBAL STATE
# =========================================================

lot_index = 0
latest_atr = None
latest_atr_mean = None

positions_cache = []
positions_cache_time = 0
positions_lock = threading.Lock()

trade_queue = Queue()
entry_lock = threading.Lock()
trade_lock = threading.Lock()

speed_cache = deque()
entry_times = []


# =========================================================
# MT5 LOGIN
# =========================================================

# MT5 Credentials
MT5_PATH = r"C:\Program Files\MetaTrader 5\terminal64.exe"
MT5_LOGIN = 433567390
MT5_PASSWORD = "Trading@123"
MT5_SERVER = "Exness-MT5Trial7"


def load_mt5_credentials():
    """Load MT5 credentials from constants"""
    return MT5_LOGIN, MT5_PASSWORD, MT5_SERVER


@monitor_performance
def init_mt5():
    print(f"\n[INIT] Attempting MT5 connection...")
    print(f"[INIT] Path: {MT5_PATH}")
    print(f"[INIT] Login: {MT5_LOGIN}")
    print(f"[INIT] Server: {MT5_SERVER}")
    
    login, password, server = load_mt5_credentials()

    if not mt5.initialize(
        path=MT5_PATH,
        login=login,
        password=password,
        server=server
    ):
        code, msg = mt5.last_error()
        error_msg = f"MT5 INIT FAILED | Code: {code} | Message: {msg}"
        print(f"\n[ERROR] {error_msg}")
        log.error(error_msg)
        raise RuntimeError(error_msg)

    print(f"[SUCCESS] MT5 initialized successfully")
    log.info("MT5 initialized successfully")
    
    # Print account info
    account_info = mt5.account_info()
    if account_info:
        print(f"[INFO] Account: {account_info.login}")
        print(f"[INFO] Balance: ${account_info.balance:.2f}")
        print(f"[INFO] Equity: ${account_info.equity:.2f}")
        log.info(f"Account {account_info.login} | Balance: ${account_info.balance:.2f}")
    
    # Verify symbol exists
    print(f"\n[VERIFY] Checking symbol: {SYMBOL}")
    symbol_info = mt5.symbol_info(SYMBOL)
    if symbol_info is None:
        print(f"[ERROR] Symbol '{SYMBOL}' not found!")
        print("[INFO] Available GOLD symbols:")
        symbols = mt5.symbols_get()
        gold_symbols = [s.name for s in symbols if 'GOLD' in s.name.upper() or 'XAU' in s.name.upper()]
        for sym in gold_symbols[:10]:  # Show first 10
            print(f"  - {sym}")
        raise RuntimeError(f"Symbol '{SYMBOL}' not available on this broker")
    
    # Enable symbol for trading
    if not symbol_info.visible:
        print(f"[INFO] Enabling symbol {SYMBOL} for trading...")
        if not mt5.symbol_select(SYMBOL, True):
            print(f"[WARNING] Could not enable symbol {SYMBOL}")
    
    print(f"[SUCCESS] Symbol {SYMBOL} verified and ready")
    print(f"[INFO] Bid: {symbol_info.bid:.2f} | Ask: {symbol_info.ask:.2f}")
    print(f"[INFO] Spread: {symbol_info.spread} points\n")


# =========================================================
# POSITION HELPERS
# =========================================================

@monitor_performance
def get_positions(force=False):
    global positions_cache
    global positions_cache_time

    now = time.time()

    with positions_lock:
        if force or (now - positions_cache_time) > 0.15:
            data = mt5.positions_get(symbol=SYMBOL)
            positions_cache = data if data else []
            positions_cache_time = now

        return list(positions_cache)


def floating_pnl():
    """Calculate floating PnL for BUY positions only"""
    return sum(
        position.profit
        for position in get_positions()
        if position.type == mt5.POSITION_TYPE_BUY
    )


def total_buy_volume():
    return sum(
        p.volume
        for p in get_positions(force=True)
        if p.type == mt5.POSITION_TYPE_BUY
    )


# =========================================================
# INDICATORS
# =========================================================

def RSI(series, period=14):
    """Calculate RSI indicator"""
    delta = series.diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi


def MACD(series, fast=12, slow=26, signal=9):
    """Calculate MACD indicator"""
    ema_fast = series.ewm(span=fast).mean()
    ema_slow = series.ewm(span=slow).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal).mean()
    return macd_line, signal_line


def ATR(df, period=14):
    tr = np.maximum(
        df['high'] - df['low'],
        np.maximum(
            abs(df['high'] - df['close'].shift()),
            abs(df['low'] - df['close'].shift())
        )
    )

    return tr.rolling(period).mean()


# =========================================================
# GEMINI AI INTEGRATION
# =========================================================

def prepare_market_data_for_ai(df, mtf_data=None, sr_analysis=None):
    """
    Prepare market data in JSON format for Gemini AI
    Sends precomputed indicators instead of raw OHLC
    """
    if df is None or len(df) < 20:
        return None
    
    tick = safe_tick()
    if not tick:
        return None
    
    # Calculate indicators
    current_price = df['close'].iloc[-1]
    rsi = RSI(df['close'], 14).iloc[-1]
    macd_line, macd_signal = MACD(df['close'])
    macd = macd_line.iloc[-1]
    macd_sig = macd_signal.iloc[-1]
    
    ema20 = df['close'].ewm(span=20).mean().iloc[-1]
    ema50 = df['close'].ewm(span=50).mean().iloc[-1]
    ema200 = df['close'].ewm(span=200).mean().iloc[-1] if len(df) >= 200 else ema50
    
    atr = df['atr'].iloc[-1] if 'atr' in df.columns else ATR(df, 14).iloc[-1]
    
    # Trend direction
    trend = "BULLISH" if df['ema_fast'].iloc[-1] > df['ema_slow'].iloc[-1] else "BEARISH"
    
    # Support/Resistance from analysis
    support = sr_analysis['nearest_support'] if sr_analysis and sr_analysis['nearest_support'] else current_price - (atr * 2)
    resistance = sr_analysis['nearest_resistance'] if sr_analysis and sr_analysis['nearest_resistance'] else current_price + (atr * 2)
    
    # Multi-timeframe trend
    mtf_trend = "NEUTRAL"
    if mtf_data:
        m5_bullish = mtf_data.get('M5', {}).get('ema_fast', pd.Series([0])).iloc[-1] > mtf_data.get('M5', {}).get('ema_slow', pd.Series([0])).iloc[-1] if 'M5' in mtf_data else False
        m15_bullish = mtf_data.get('M15', {}).get('ema_fast', pd.Series([0])).iloc[-1] > mtf_data.get('M15', {}).get('ema_slow', pd.Series([0])).iloc[-1] if 'M15' in mtf_data else False
        
        if m5_bullish and m15_bullish:
            mtf_trend = "STRONG_BULLISH"
        elif not m5_bullish and not m15_bullish:
            mtf_trend = "STRONG_BEARISH"
        else:
            mtf_trend = "MIXED"
    
    # Volume (approximate from tick volume)
    volume = int(df['tick_volume'].iloc[-1]) if 'tick_volume' in df.columns else 1000
    
    market_data = {
        "symbol": SYMBOL,
        "timeframe": "M1",
        "price": round(float(current_price), 2),
        "rsi": round(float(rsi), 2),
        "macd": round(float(macd), 4),
        "macd_signal": round(float(macd_sig), 4),
        "ema20": round(float(ema20), 2),
        "ema50": round(float(ema50), 2),
        "ema200": round(float(ema200), 2),
        "atr": round(float(atr), 2),
        "support": round(float(support), 2),
        "resistance": round(float(resistance), 2),
        "volume": volume,
        "trend": trend,
        "mtf_trend": mtf_trend,
        "spread": round(tick.ask - tick.bid, 2)
    }
    
    return market_data


def update_gemini_cache_background(market_data):
    """
    Background function to update Gemini AI cache
    This runs in a separate thread and never blocks the main trading logic
    """
    global gemini_ai_cache, gemini_rate_limit_tracker
    
    if not GEMINI_ENABLED:
        return
    
    now = time.time()
    
    # Check if we're in cooldown period
    if gemini_rate_limit_tracker['in_cooldown']:
        if now < gemini_rate_limit_tracker['cooldown_until']:
            remaining = int(gemini_rate_limit_tracker['cooldown_until'] - now)
            log.warning(
                f"Gemini API in cooldown. Remaining: {remaining}s. Cache update skipped.",
                throttle_key="gemini_cooldown",
                throttle_interval=120
            )
            return
        else:
            # Cooldown period over, reset tracker
            with gemini_thread_lock:
                gemini_rate_limit_tracker['in_cooldown'] = False
                gemini_rate_limit_tracker['error_count'] = 0
            log.info("Gemini API cooldown period ended. Resuming cache updates.")
    
    # Retry logic with exponential backoff
    for attempt in range(GEMINI_MAX_RETRIES):
        try:
            # Prepare prompt with enhanced context
            market_data_json = json.dumps(market_data, indent=2)
            
            # Get current date/time for context
            from datetime import datetime
            now_dt = datetime.now()
            current_date = now_dt.strftime("%Y-%m-%d")
            current_time = now_dt.strftime("%H:%M")
            day_of_week = now_dt.strftime("%A")
            hour = now_dt.hour
            
            # Determine trading session
            if 2 <= hour < 8:
                session = "Asian (Low liquidity, range-bound)"
            elif 8 <= hour < 13:
                session = "European (Moderate liquidity, trend development)"
            elif 13 <= hour < 21:
                session = "US (High liquidity, major moves)"
            else:
                session = "After-hours (Very low liquidity, avoid)"
            
            prompt = f"""
You are a professional XAU/USD (Gold) trading expert with 20 years of experience.

CURRENT CONTEXT:
- Date: {current_date} ({day_of_week})
- Time: {current_time} IST
- Session: {session}

MARKET DATA:
{market_data_json}

YOUR TASK: Analyze if NOW is a good time to enter a BUY position.

Consider:
1. News & Events: Are there major economic events today (US CPI, NFP, FOMC, Fed speeches)? If major news within 2 hours, recommend WAIT.
2. Market Session: Asian=range-bound, European=trend-following, US=high volatility, After-hours=avoid
3. Technical Setup: Is price at good level? Indicators aligned? Clear trend or choppy?
4. Risk Factors: Spread widening? Volatility too high/low? Stop-loss hunting zones?
5. Entry Timing: Enter now? Wait for pullback? Wait for breakout? Avoid today?

Return ONLY this JSON (no markdown):
{{
  "entry_decision": {{
    "signal": "BUY|WAIT|AVOID",
    "confidence": 0-100,
    "entry_quality": "EXCELLENT|GOOD|FAIR|POOR",
    "optimal_entry_price": price_level,
    "reasoning": "Detailed why BUY/WAIT/AVOID"
  }},
  "market_context": {{
    "session_assessment": "How current session affects entry",
    "news_today": "Any major news/events today",
    "volatility_level": "LOW|NORMAL|HIGH|EXTREME",
    "market_sentiment": "RISK_ON|RISK_OFF|NEUTRAL"
  }},
  "technical_assessment": {{
    "trend_quality": "STRONG|MODERATE|WEAK|CHOPPY",
    "support_resistance": "near support/resistance/middle",
    "indicator_alignment": "ALIGNED|MIXED|CONFLICTING"
  }},
  "risk_warnings": ["warning1", "warning2"],
  "entry_timing": {{
    "timing": "IMMEDIATE|WAIT_FOR_DIP|WAIT_FOR_BREAKOUT|WAIT_FOR_NEWS|AVOID_TODAY",
    "wait_for_price": price_level_if_waiting,
    "reason": "Why this timing"
  }},
  "position_sizing": {{
    "recommended_size": "FULL|HALF|QUARTER|MINIMAL",
    "reason": "Why this size"
  }},
  "legacy_fields": {{
    "signal": "BUY|SELL|HOLD",
    "entry": price_level,
    "stop_loss": price_level,
    "take_profit_1": price_level,
    "take_profit_2": price_level,
    "reason": "brief explanation"
  }}
}}

Be specific about TODAY's conditions. Make educated assessment based on typical patterns for {day_of_week}.
"""
            
            # Call Gemini API
            client = genai.Client(api_key=GEMINI_API_KEY)
            
            response = client.models.generate_content(
                model=GEMINI_MODEL,
                contents=prompt
            )
            
            # Parse response
            response_text = response.text.strip()
            
            # Remove markdown code blocks if present
            if "```json" in response_text:
                parts = response_text.split("```json")
                if len(parts) > 1:
                    json_part = parts[1].split("```")[0]
                    response_text = json_part.strip()
            elif response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]
                response_text = response_text.strip()
            
            result = json.loads(response_text)
            
            # Validate enhanced response format
            required_keys = ["entry_decision", "market_context", "entry_timing", "position_sizing"]
            if not all(key in result for key in required_keys):
                log.error(f"Invalid AI response format (missing keys): {result.keys()}")
                return
            
            # Success! Update cache with enhanced structure
            with gemini_thread_lock:
                gemini_ai_cache.update({
                    'entry_decision': result.get('entry_decision', {}),
                    'market_context': result.get('market_context', {}),
                    'technical_assessment': result.get('technical_assessment', {}),
                    'risk_warnings': result.get('risk_warnings', []),
                    'entry_timing': result.get('entry_timing', {}),
                    'position_sizing': result.get('position_sizing', {}),
                    'legacy_fields': result.get('legacy_fields', {}),
                    'timestamp': now,
                    'is_valid': True
                })
                gemini_rate_limit_tracker['error_count'] = 0
                gemini_rate_limit_tracker['last_update_attempt'] = now
            
            # Enhanced logging
            entry_dec = result['entry_decision']
            market_ctx = result['market_context']
            timing = result['entry_timing']
            pos_size = result['position_sizing']
            
            log.info(
                f"AI ENTRY ANALYSIS:\n"
                f"  Signal: {entry_dec['signal']} ({entry_dec['confidence']}%) | Quality: {entry_dec['entry_quality']}\n"
                f"  Session: {market_ctx['session_assessment']}\n"
                f"  News: {market_ctx.get('news_today', 'None')}\n"
                f"  Volatility: {market_ctx['volatility_level']} | Sentiment: {market_ctx['market_sentiment']}\n"
                f"  Timing: {timing['timing']} | Size: {pos_size['recommended_size']}\n"
                f"  Reason: {entry_dec['reasoning']}",
                throttle_key="ai_cache_update",
                throttle_interval=60
            )
            
            return
            
        except json.JSONDecodeError as e:
            log.error(f"Failed to parse AI response as JSON: {e}")
            return
            
        except Exception as e:
            error_str = str(e)
            
            # Check if it's a rate limit error (429 RESOURCE_EXHAUSTED)
            if "429" in error_str or "RESOURCE_EXHAUSTED" in error_str or "quota" in error_str.lower():
                with gemini_thread_lock:
                    gemini_rate_limit_tracker['error_count'] += 1
                    gemini_rate_limit_tracker['last_error_time'] = now
                
                # Extract retry delay from error message if available
                retry_delay = GEMINI_RETRY_DELAY
                if "retry in" in error_str.lower():
                    try:
                        import re
                        match = re.search(r'retry in (\d+(?:\.\d+)?)', error_str.lower())
                        if match:
                            retry_delay = float(match.group(1))
                    except:
                        pass
                
                # Enter cooldown mode after rate limit errors
                if gemini_rate_limit_tracker['error_count'] >= 2:
                    with gemini_thread_lock:
                        gemini_rate_limit_tracker['in_cooldown'] = True
                        gemini_rate_limit_tracker['cooldown_until'] = now + GEMINI_RATE_LIMIT_COOLDOWN
                    log.error(
                        f"Gemini API rate limit exceeded. Entering cooldown for {GEMINI_RATE_LIMIT_COOLDOWN}s. "
                        f"Free tier limits: 10 RPM, 1,500 RPD. Bot continues with cached data."
                    )
                    return
                
                # If not in cooldown yet, try exponential backoff
                if attempt < GEMINI_MAX_RETRIES - 1:
                    backoff_delay = min(retry_delay * (2 ** attempt), 300)
                    log.warning(
                        f"Gemini API rate limit hit (attempt {attempt + 1}/{GEMINI_MAX_RETRIES}). "
                        f"Retrying in {backoff_delay:.1f}s..."
                    )
                    time.sleep(backoff_delay)
                    continue
                else:
                    log.error(
                        f"Gemini API rate limit exceeded after {GEMINI_MAX_RETRIES} attempts. "
                        f"Using cached data."
                    )
                    return
            else:
                # Other errors - log and retry
                log.error(f"Gemini API error: {error_str}")
                if attempt < GEMINI_MAX_RETRIES - 1:
                    time.sleep(5)
                    continue
                return


def gemini_background_updater():
    """
    Background thread that periodically updates Gemini AI cache
    Runs independently and never blocks main trading logic
    """
    global gemini_thread_running
    
    log.info("Gemini AI background updater started")
    
    while gemini_thread_running:
        try:
            # Check if MT5 connection is alive
            if not mt5_alive():
                log.warning("MT5 connection lost. Waiting to reconnect...", throttle_key="mt5_connection", throttle_interval=30)
                time.sleep(5)
                continue
            
            # Fetch fresh data frames to calculate indicators
            mtf_data = get_multi_timeframe_data()
            
            # Use M1 data if available, otherwise fallback to get_market_data
            df = mtf_data.get('M1') if mtf_data and 'M1' in mtf_data else get_market_data(200)
            
            if df is not None and len(df) >= 20:
                # Calculate Support/Resistance data from M5 timeframe
                sr_analysis = None
                if mtf_data and 'M5' in mtf_data:
                    sr_analysis = detect_support_resistance(mtf_data['M5'], lookback=50)
                
                # Format the proper rich JSON payload the prompt expects
                market_data = prepare_market_data_for_ai(df, mtf_data, sr_analysis)
                
                if market_data:
                    # Update cache in background
                    update_gemini_cache_background(market_data)
            
            # Wait for next update interval
            time.sleep(GEMINI_UPDATE_INTERVAL)
            
        except Exception as e:
            log.error(f"Error in Gemini background updater: {e}", exc_info=True)
            time.sleep(30)  # Wait before retry on error
    
    log.info("Gemini AI background updater stopped")


def start_gemini_background_updater():
    """Start the Gemini AI background updater thread"""
    global gemini_background_thread, gemini_thread_running
    
    if not GEMINI_ENABLED:
        log.info("Gemini AI disabled. Background updater not started.")
        return
    
    if gemini_background_thread and gemini_background_thread.is_alive():
        log.warning("Gemini background updater already running")
        return
    
    gemini_thread_running = True
    gemini_background_thread = threading.Thread(
        target=gemini_background_updater,
        daemon=True,
        name="GeminiUpdater"
    )
    gemini_background_thread.start()
    log.info("Gemini AI background updater thread started")


def stop_gemini_background_updater():
    """Stop the Gemini AI background updater thread"""
    global gemini_thread_running
    
    if gemini_background_thread and gemini_background_thread.is_alive():
        gemini_thread_running = False
        log.info("Stopping Gemini AI background updater...")
        gemini_background_thread.join(timeout=5)


def get_gemini_trading_signal():
    """
    Get enhanced trading signal from Gemini AI cache (non-blocking)
    Returns: dict with entry_decision, market_context, timing, position_sizing, etc. or None
    """
    global gemini_ai_cache
    
    if not GEMINI_ENABLED:
        return None
    
    with gemini_thread_lock:
        # Check if cache is valid
        if not gemini_ai_cache['is_valid']:
            return None
        
        # Check cache age (warn if stale but still return it)
        now = time.time()
        cache_age = now - gemini_ai_cache['timestamp']
        
        if cache_age > GEMINI_UPDATE_INTERVAL * 2:
            log.warning(
                f"AI cache is stale ({int(cache_age)}s old). Using anyway.",
                throttle_key="stale_cache",
                throttle_interval=120
            )
        
        # Return enhanced cached decision
        return {
            'entry_decision': gemini_ai_cache.get('entry_decision', {}),
            'market_context': gemini_ai_cache.get('market_context', {}),
            'technical_assessment': gemini_ai_cache.get('technical_assessment', {}),
            'risk_warnings': gemini_ai_cache.get('risk_warnings', []),
            'entry_timing': gemini_ai_cache.get('entry_timing', {}),
            'position_sizing': gemini_ai_cache.get('position_sizing', {}),
            'legacy_fields': gemini_ai_cache.get('legacy_fields', {})
        }


# =========================================================
# ORDER HELPERS
# =========================================================

def normalize_lot(symbol, lot):
    info = mt5.symbol_info(symbol)

    if not info:
        return lot

    return max(
        info.volume_min,
        round(lot / info.volume_step) * info.volume_step
    )


def send_order_with_retry(request, attempts=3, delay=0.2):
    """Send order with retry logic - FIXED: Better error handling"""
    for i in range(attempts):
        result = mt5.order_send(request)

        if result and result.retcode == mt5.TRADE_RETCODE_DONE:
            return result

        if result:
            # ✅ FIXED: Don't retry on certain errors
            if result.retcode == 10019:  # TRADE_RETCODE_NO_MONEY
                log.error(f"Insufficient funds (retcode 10019) - stopping retries")
                return None
            
            if result.retcode == 10018:  # TRADE_RETCODE_MARKET_CLOSED
                log.error(f"Market closed (retcode 10018) - stopping retries")
                return None
            
            log.warning(
                f"ORDER RETRY {i + 1}/{attempts} | retcode={result.retcode}"
            )

        time.sleep(delay)

    log.error("ORDER FAILED AFTER RETRIES")
    return None


def can_afford_trade(lot, order_type):
    """✅ NEW: Check if account has sufficient margin for trade"""
    account_info = mt5.account_info()
    if not account_info:
        return False
    
    # Get required margin
    symbol_info = mt5.symbol_info(SYMBOL)
    if not symbol_info:
        return False
    
    tick = mt5.symbol_info_tick(SYMBOL)
    if not tick:
        return False
    
    price = tick.ask if order_type == mt5.ORDER_TYPE_BUY else tick.bid
    contract_size = symbol_info.trade_contract_size
    leverage = account_info.leverage if account_info.leverage > 0 else 100
    
    required_margin = (lot * contract_size * price) / leverage
    
    # Add 20% buffer for safety
    required_margin *= 1.2
    
    available = account_info.margin_free
    
    if available < required_margin:
        log.warning(
            f"Insufficient margin: need ${required_margin:.2f}, "
            f"have ${available:.2f}"
        )
        return False
    
    return True


# =========================================================
# BUY FUNCTION
# =========================================================

@monitor_performance
def buy(lot):
    """Execute buy order - FIXED: Added balance check"""
    tick = mt5.symbol_info_tick(SYMBOL)

    if not tick:
        log.warning("BUY SKIPPED — No tick data")
        return False

    normalized_lot = normalize_lot(SYMBOL, lot)

    # ✅ FIXED: Check if we can afford this trade
    if not can_afford_trade(normalized_lot, mt5.ORDER_TYPE_BUY):
        log.warning(f"BUY SKIPPED — Insufficient margin for {normalized_lot} lots")
        return False

    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": normalized_lot,
        "type": mt5.ORDER_TYPE_BUY,
        "price": tick.ask,
        "magic": MAGIC,
        "deviation": 50,
        "comment": "Grid Buy",
        "type_filling": mt5.ORDER_FILLING_IOC,
        "type_time": mt5.ORDER_TIME_GTC,
    }

    result = send_order_with_retry(request)

    if result and result.retcode == mt5.TRADE_RETCODE_DONE:
        log.trade(
            "BUY_EXECUTED",
            lot=normalized_lot,
            price=tick.ask,
            ticket=result.order
        )
        return True

    return False


# =========================================================
# STATE MANAGEMENT
# =========================================================

def save_state():
    state = {
        "lot_index": lot_index,
    }

    try:
        with open(STATE_FILE, "w") as file:
            json.dump(state, file)

    except Exception as e:
        log.error(f"STATE SAVE FAILED: {e}")


# =========================================================
# MAIN LOOP
# =========================================================

@monitor_performance
def main_loop():
    log.info("Starting GoldAlgoBot...")

    while True:
        try:
            positions = get_positions(force=True)
            pnl = floating_pnl()

            log.info(
                f"Positions={len(positions)} | PnL={pnl:.2f}",
                throttle_key="status",
                throttle_interval=5
            )

            time.sleep(1)

        except KeyboardInterrupt:
            log.warning("Bot stopped by user")
            break

        except Exception as e:
            log.error(f"MAIN LOOP ERROR: {e}", exc_info=True)
            time.sleep(5)


# =========================================================
# ADDITIONAL RECOVERED FUNCTIONS (LATEST VERSION)
# =========================================================

# =========================================================
# SAFE TICK
# =========================================================

def safe_tick():
    try:
        tick = mt5.symbol_info_tick(SYMBOL)

        if tick is None:
            log.warning(
                "Tick data unavailable",
                throttle_key="tick_missing",
                throttle_interval=5
            )
            return None

        return tick

    except Exception as e:
        log.error(f"safe_tick failed: {e}", exc_info=True)
        return None


# =========================================================
# VERIFY POSITION EXISTS
# =========================================================

def verify_position_exists(ticket, retries=10, delay=0.2):
    for _ in range(retries):
        positions = mt5.positions_get(ticket=ticket)

        if positions:
            return True

        time.sleep(delay)

    log.critical(f"POSITION VERIFY FAILED | ticket={ticket}")
    return False


# =========================================================
# SPREAD CHECK
# =========================================================

def spread_ok(max_spread=60):
    tick = safe_tick()

    if not tick:
        return False

    spread = abs(tick.ask - tick.bid)

    if spread > max_spread:
        log.warning(
            f"Spread too high | spread={spread:.2f}",
            throttle_key="spread_high",
            throttle_interval=5
        )
        return False

    return True


# =========================================================
# MISSING FUNCTION STUBS
# =========================================================

def htf_trend_strength(position_count):
    """Calculate higher timeframe trend strength"""
    # Stub implementation - returns neutral trend
    return 0




def last_buy_price():
    """Get the price of the last buy position"""
    positions = get_positions(force=True)
    buy_positions = [
        p for p in positions
        if p.type == mt5.POSITION_TYPE_BUY
    ]
    
    if not buy_positions:
        return 0.0
    
    # Return the most recent buy position price
    return buy_positions[-1].price_open


def dynamic_tp_target(total_lot, position_count):
    """
    ✅ ENHANCED: Calculate dynamic take profit target based on:
    - Grid depth (position count)
    - Total lot size
    - Market volatility (ATR)
    - Trend strength
    - AI confidence
    """
    global latest_atr, gemini_ai_cache
    
    # Quick exit for single small position
    if position_count == 1 and total_lot <= 0.01:
        return 1.0
    
    # Base target
    base_target = 1.0
    
    # 1. Position-based scaling (exponential for deeper grids)
    position_multiplier = math.pow(position_count, 1.5)
    
    # 2. Lot size component
    lot_component = total_lot * 1.3
    
    # 3. Volatility adjustment (higher ATR = higher target for safety)
    volatility_multiplier = 1.0
    if latest_atr and latest_atr > 0:
        # If ATR is high (>2.0), increase target by up to 50%
        # If ATR is low (<1.0), can reduce target slightly
        if latest_atr > 2.0:
            volatility_multiplier = 1.0 + min((latest_atr - 2.0) * 0.25, 0.5)
        elif latest_atr < 1.0:
            volatility_multiplier = 0.9
    
    # 4. AI confidence adjustment
    ai_multiplier = 1.0
    if GEMINI_ENABLED and gemini_ai_cache.get('is_valid'):
        entry_dec = gemini_ai_cache.get('entry_decision', {})
        confidence = entry_dec.get('confidence', 50)
        quality = entry_dec.get('entry_quality', 'FAIR')
        
        # High confidence + excellent quality = can take profit earlier
        if confidence > 80 and quality == 'EXCELLENT':
            ai_multiplier = 0.85  # Reduce target by 15%
        # Low confidence or poor quality = wait for more profit
        elif confidence < 50 or quality == 'POOR':
            ai_multiplier = 1.2  # Increase target by 20%
    
    # 5. Trend strength adjustment (from multi-timeframe data)
    trend_multiplier = 1.0
    try:
        mtf_data = get_multi_timeframe_data()
        if mtf_data:
            trend_analysis = analyze_multi_timeframe_trend(mtf_data)
            if trend_analysis:
                strength = trend_analysis.get('trend_strength', 1)
                # Strong trend (3/3) = can take profit earlier
                if strength == 3:
                    trend_multiplier = 0.9
                # Weak trend (1/3) = wait for more profit
                elif strength == 1:
                    trend_multiplier = 1.15
    except:
        pass  # Fallback to default if MTF data unavailable
    
    # Calculate final target
    raw_target = base_target + position_multiplier + lot_component
    adjusted_target = raw_target * volatility_multiplier * ai_multiplier * trend_multiplier
    
    # Ensure minimum target of $1.0
    return max(1.0, adjusted_target)


def mt5_alive():
    """Check if MT5 connection is alive"""
    try:
        return mt5.terminal_info() is not None
    except:
        return False


def equity_circuit_breaker():
    """Check if equity circuit breaker should trigger"""
    # Stub implementation - always returns False
    return False


def equity_trailing_lock():
    """Check if equity trailing lock should trigger"""
    # Stub implementation - always returns False
    return False


def daily_drawdown_guard():
    """Check if daily drawdown limit is reached"""
    # Stub implementation - always returns False
    return False


def adaptive_engine():
    """Adaptive engine for dynamic parameter adjustment"""
    # Stub implementation - does nothing
    pass


def update_market_regime_mode(df, atr, atr_mean):
    """Update market regime mode based on volatility"""
    # Stub implementation - does nothing
    pass


def flat_trap_detector(df):
    """Detect flat/ranging market conditions"""
    # Stub implementation - does nothing
    pass


# =========================================================
# CLOSE ALL POSITIONS
# =========================================================

def close_all():
    """Close all BUY positions only"""
    positions = get_positions(force=True)

    for position in positions:
        try:
            # Only close BUY positions
            if position.type != mt5.POSITION_TYPE_BUY:
                continue

            tick = safe_tick()

            if not tick:
                continue

            request = {
                "action": mt5.TRADE_ACTION_DEAL,
                "symbol": SYMBOL,
                "volume": position.volume,
                "type": mt5.ORDER_TYPE_SELL,  # Close BUY with SELL
                "position": position.ticket,
                "price": tick.bid,
                "deviation": 50,
                "magic": MAGIC,
                "comment": "Close Buy",
                "type_filling": mt5.ORDER_FILLING_IOC,
                "type_time": mt5.ORDER_TIME_GTC,
            }

            result = mt5.order_send(request)

            if result and result.retcode == mt5.TRADE_RETCODE_DONE:
                log.trade(
                    "BUY_POSITION_CLOSED",
                    ticket=position.ticket,
                    profit=position.profit
                )

        except Exception as e:
            log.error(f"close_all failed: {e}", exc_info=True)


# =========================================================
# HEDGE POSITION FINDER
# =========================================================



# =========================================================
# MARKET DATA FETCH
# =========================================================

def get_market_data(bars=200):
    """Get M1 market data with indicators"""
    rates = mt5.copy_rates_from_pos(
        SYMBOL,
        TIMEFRAME,
        0,
        bars
    )

    if rates is None or len(rates) == 0:
        return None

    df = pd.DataFrame(rates)

    df['ema_fast'] = df['close'].ewm(span=EMA_FAST).mean()
    df['ema_slow'] = df['close'].ewm(span=EMA_SLOW).mean()
    df['atr'] = ATR(df, 14)

    return df


def get_multi_timeframe_data():
    """
    Get market data from multiple timeframes for better trend analysis
    Returns: dict with M1, M5, M15 dataframes
    """
    mtf_data = {}
    
    # M1 - 200 candles (3.3 hours) - for precise entry timing
    rates_m1 = mt5.copy_rates_from_pos(SYMBOL, mt5.TIMEFRAME_M1, 0, 200)
    if rates_m1 is not None and len(rates_m1) > 0:
        df_m1 = pd.DataFrame(rates_m1)
        df_m1['ema_fast'] = df_m1['close'].ewm(span=5).mean()
        df_m1['ema_slow'] = df_m1['close'].ewm(span=9).mean()
        df_m1['atr'] = ATR(df_m1, 14)
        mtf_data['M1'] = df_m1
    
    # M5 - 100 candles (8.3 hours) - for short-term trend
    rates_m5 = mt5.copy_rates_from_pos(SYMBOL, mt5.TIMEFRAME_M5, 0, 100)
    if rates_m5 is not None and len(rates_m5) > 0:
        df_m5 = pd.DataFrame(rates_m5)
        df_m5['ema_fast'] = df_m5['close'].ewm(span=9).mean()
        df_m5['ema_slow'] = df_m5['close'].ewm(span=21).mean()
        df_m5['atr'] = ATR(df_m5, 14)
        mtf_data['M5'] = df_m5
    
    # M15 - 50 candles (12.5 hours) - for medium-term trend
    rates_m15 = mt5.copy_rates_from_pos(SYMBOL, mt5.TIMEFRAME_M15, 0, 50)
    if rates_m15 is not None and len(rates_m15) > 0:
        df_m15 = pd.DataFrame(rates_m15)
        df_m15['ema_fast'] = df_m15['close'].ewm(span=9).mean()
        df_m15['ema_slow'] = df_m15['close'].ewm(span=21).mean()
        df_m15['atr'] = ATR(df_m15, 14)
        mtf_data['M15'] = df_m15
    
    return mtf_data if len(mtf_data) == 3 else None


def detect_support_resistance(df, lookback=50):
    """
    Detect key support and resistance levels using swing highs/lows
    Returns: dict with support/resistance levels and current price position
    """
    if df is None or len(df) < lookback:
        return None
    
    closes = df['close'].iloc[-lookback:].values
    highs = df['high'].iloc[-lookback:].values
    lows = df['low'].iloc[-lookback:].values
    current_price = closes[-1]
    
    # Find swing highs (resistance) - local maxima
    resistance_levels = []
    for i in range(2, len(highs) - 2):
        if highs[i] > highs[i-1] and highs[i] > highs[i-2] and \
           highs[i] > highs[i+1] and highs[i] > highs[i+2]:
            resistance_levels.append(highs[i])
    
    # Find swing lows (support) - local minima
    support_levels = []
    for i in range(2, len(lows) - 2):
        if lows[i] < lows[i-1] and lows[i] < lows[i-2] and \
           lows[i] < lows[i+1] and lows[i] < lows[i+2]:
            support_levels.append(lows[i])
    
    # Find nearest resistance above current price
    resistance_above = [r for r in resistance_levels if r > current_price]
    nearest_resistance = min(resistance_above) if resistance_above else None
    
    # Find nearest support below current price
    support_below = [s for s in support_levels if s < current_price]
    nearest_support = max(support_below) if support_below else None
    
    # Calculate distance to nearest levels
    distance_to_resistance = None
    distance_to_support = None
    
    if nearest_resistance:
        distance_to_resistance = nearest_resistance - current_price
    
    if nearest_support:
        distance_to_support = current_price - nearest_support
    
    # Determine if price is near resistance (within 3 points)
    near_resistance = distance_to_resistance is not None and distance_to_resistance < 3.0
    
    # Determine if price is near support (within 3 points)
    near_support = distance_to_support is not None and distance_to_support < 3.0
    
    # Check for breakout - price recently broke above resistance
    breakout_detected = False
    if resistance_levels:
        recent_resistance = max([r for r in resistance_levels if r < current_price], default=None)
        if recent_resistance and (current_price - recent_resistance) < 5.0:
            # Price is within 5 points above a recent resistance = potential breakout
            breakout_detected = True
    
    return {
        'current_price': current_price,
        'nearest_resistance': nearest_resistance,
        'nearest_support': nearest_support,
        'distance_to_resistance': distance_to_resistance,
        'distance_to_support': distance_to_support,
        'near_resistance': near_resistance,
        'near_support': near_support,
        'breakout_detected': breakout_detected,
        'resistance_levels': resistance_levels,
        'support_levels': support_levels
    }


def analyze_multi_timeframe_trend(mtf_data):
    """
    Analyze trend across multiple timeframes with support/resistance
    Returns: dict with trend analysis
    """
    if not mtf_data or len(mtf_data) != 3:
        return None
    
    analysis = {
        'M1_bullish': False,
        'M5_bullish': False,
        'M15_bullish': False,
        'trend_strength': 0,  # 0-3 (number of bullish timeframes)
        'trend_aligned': False,  # All timeframes agree
        'entry_allowed': False,
        'sr_analysis': None,  # Support/Resistance analysis
        'block_reason': None,
        'favorable_entry': False
    }
    
    # Check each timeframe
    if 'M1' in mtf_data:
        df_m1 = mtf_data['M1']
        analysis['M1_bullish'] = df_m1['ema_fast'].iloc[-1] > df_m1['ema_slow'].iloc[-1]
    
    if 'M5' in mtf_data:
        df_m5 = mtf_data['M5']
        analysis['M5_bullish'] = df_m5['ema_fast'].iloc[-1] > df_m5['ema_slow'].iloc[-1]
        
        # Detect support/resistance on M5 (more reliable than M1)
        analysis['sr_analysis'] = detect_support_resistance(df_m5, lookback=50)
    
    if 'M15' in mtf_data:
        df_m15 = mtf_data['M15']
        analysis['M15_bullish'] = df_m15['ema_fast'].iloc[-1] > df_m15['ema_slow'].iloc[-1]
    
    # Calculate trend strength
    analysis['trend_strength'] = sum([
        analysis['M1_bullish'],
        analysis['M5_bullish'],
        analysis['M15_bullish']
    ])
    
    # All timeframes aligned
    analysis['trend_aligned'] = analysis['trend_strength'] == 3
    
    # Entry allowed if at least M5 and M15 are bullish (stronger confirmation)
    analysis['entry_allowed'] = analysis['M5_bullish'] and analysis['M15_bullish']
    
    # ✅ CRITICAL: Block entry if near resistance (unless breakout confirmed)
    if analysis['sr_analysis']:
        sr = analysis['sr_analysis']
        
        # Don't buy near resistance unless it's a confirmed breakout
        if sr['near_resistance'] and not sr['breakout_detected']:
            analysis['entry_allowed'] = False
            analysis['block_reason'] = 'near_resistance'
        
        # Prefer entries near support or after breakout
        if sr['near_support'] or sr['breakout_detected']:
            analysis['favorable_entry'] = True
        else:
            analysis['favorable_entry'] = False
    
    return analysis


# =========================================================
# GRID ENTRY ENGINE
# =========================================================

def grid_engine(df, mtf_data=None):
    """✅ ENHANCED: Multi-timeframe trend analysis with proper lot index management"""
    global lot_index

    if df is None or len(df) < 50:
        return

    positions = get_positions(force=True)

    buy_positions = [
        p for p in positions
        if p.type == mt5.POSITION_TYPE_BUY
    ]

    # ✅ FIX: Always calculate lot_index from actual position count
    # This handles bot restarts when positions already exist
    if len(buy_positions) == 0:
        lot_index = 0
    else:
        # Use position count to determine lot_index (restart-safe)
        lot_index = min(len(buy_positions) - 1, len(LOT_LADDER) - 1)

    # ✅ FIXED: Add position limit checks
    if len(buy_positions) >= MAX_BUY_POSITIONS:
        log.warning(
            f"Max buy positions reached: {len(buy_positions)}",
            throttle_key="max_buy_positions",
            throttle_interval=30
        )
        return
    
    if len(positions) >= MAX_TOTAL_POSITIONS:
        log.warning(
            f"Max total positions reached: {len(positions)}",
            throttle_key="max_total_positions",
            throttle_interval=30
        )
        return

    tick = safe_tick()

    if not tick:
        return

    ema_fast = df['ema_fast']
    ema_slow = df['ema_slow']

    atr_now = df['atr'].iloc[-1]

    # ✅ ENHANCED: Multi-timeframe trend analysis with S/R detection
    trend_analysis = None
    if mtf_data:
        trend_analysis = analyze_multi_timeframe_trend(mtf_data)
        
        if trend_analysis:
            # Enhanced logging with S/R info
            sr_info = ""
            if trend_analysis['sr_analysis']:
                sr = trend_analysis['sr_analysis']
                res_dist = f"{sr['distance_to_resistance']:.1f}" if sr['distance_to_resistance'] is not None else 'N/A'
                sup_dist = f"{sr['distance_to_support']:.1f}" if sr['distance_to_support'] is not None else 'N/A'
                sr_info = f" | SR: Res={res_dist} Sup={sup_dist} Breakout={sr['breakout_detected']}"
            
            log.info(
                f"MTF Trend | M1:{trend_analysis['M1_bullish']} | "
                f"M5:{trend_analysis['M5_bullish']} | "
                f"M15:{trend_analysis['M15_bullish']} | "
                f"Strength:{trend_analysis['trend_strength']}/3 | "
                f"Entry:{trend_analysis['entry_allowed']}{sr_info}",
                throttle_key="mtf_trend",
                throttle_interval=10
            )

    # First entry
    if len(buy_positions) == 0:
        bullish = ema_fast.iloc[-1] > ema_slow.iloc[-1]
        
        # ✅ ENHANCED: Get AI trading signal with full context
        ai_signal = None
        lot_multiplier = 1.0  # Default full size
        
        if GEMINI_ENABLED:
            sr_analysis = trend_analysis['sr_analysis'] if trend_analysis else None
            market_data = prepare_market_data_for_ai(df, mtf_data, sr_analysis)
            
            if market_data:
                ai_signal = get_gemini_trading_signal()
            
            if ai_signal and ai_signal.get('entry_decision'):
                entry_dec = ai_signal['entry_decision']
                market_ctx = ai_signal.get('market_context', {})
                timing = ai_signal.get('entry_timing', {})
                pos_size = ai_signal.get('position_sizing', {})
                warnings = ai_signal.get('risk_warnings', [])
                
                # Log comprehensive AI analysis
                log.info(
                    f"AI ENTRY DECISION:\n"
                    f"  Signal: {entry_dec.get('signal', 'N/A')} ({entry_dec.get('confidence', 0)}%)\n"
                    f"  Quality: {entry_dec.get('entry_quality', 'N/A')}\n"
                    f"  Session: {market_ctx.get('session_assessment', 'N/A')}\n"
                    f"  Timing: {timing.get('timing', 'N/A')}\n"
                    f"  Size: {pos_size.get('recommended_size', 'FULL')}",
                    throttle_key="ai_entry_decision",
                    throttle_interval=60
                )
                
                # ✅ BLOCK if AI says AVOID
                if entry_dec.get('signal') == 'AVOID' and entry_dec.get('confidence', 0) > 60:
                    log.warning(
                        f"❌ AI BLOCKS ENTRY (AVOID): {entry_dec.get('reasoning', 'No reason')}",
                        throttle_key="ai_avoid",
                        throttle_interval=60
                    )
                    return
                
                # ✅ WAIT if AI suggests waiting
                if entry_dec.get('signal') == 'WAIT' and entry_dec.get('confidence', 0) > 60:
                    log.warning(
                        f"⏸️  AI SUGGESTS WAIT: {timing.get('reason', 'No reason')}\n"
                        f"   Wait for price: {timing.get('wait_for_price', 'N/A')}",
                        throttle_key="ai_wait",
                        throttle_interval=60
                    )
                    return
                
                # ✅ LOG warnings
                if warnings:
                    for warning in warnings:
                        log.warning(f"⚠️  AI WARNING: {warning}")
                
                # ✅ ADJUST lot size based on AI recommendation
                size_rec = pos_size.get('recommended_size', 'FULL')
                if size_rec == 'HALF':
                    lot_multiplier = 0.5
                    log.info(f"AI recommends HALF position: {pos_size.get('reason', '')}")
                elif size_rec == 'QUARTER':
                    lot_multiplier = 0.25
                    log.info(f"AI recommends QUARTER position: {pos_size.get('reason', '')}")
                elif size_rec == 'MINIMAL':
                    lot_multiplier = 0.1
                    log.info(f"AI recommends MINIMAL position: {pos_size.get('reason', '')}")
                
                # ✅ LOG entry quality
                quality = entry_dec.get('entry_quality', 'UNKNOWN')
                if quality in ['POOR', 'FAIR']:
                    log.warning(f"⚠️  Entry quality is {quality}: {entry_dec.get('reasoning', '')}")
                elif quality == 'EXCELLENT':
                    log.info(f"✅ EXCELLENT ENTRY SETUP: {entry_dec.get('reasoning', '')}")
        
        # ✅ ENHANCED: Use multi-timeframe confirmation with S/R for first entry
        if trend_analysis:
            # Check if entry is blocked by resistance
            if trend_analysis['block_reason'] == 'near_resistance':
                log.warning(
                    f"First entry BLOCKED - Price near resistance (avoid buying at ceiling)",
                    throttle_key="resistance_block",
                    throttle_interval=30
                )
                return
            
            # Require M5 and M15 to be bullish for first entry
            if not trend_analysis['entry_allowed']:
                log.warning(
                    f"First entry BLOCKED - MTF not aligned (M5:{trend_analysis['M5_bullish']}, M15:{trend_analysis['M15_bullish']})",
                    throttle_key="mtf_block",
                    throttle_interval=30
                )
                return
            
            # Log favorable entry conditions
            if trend_analysis['favorable_entry']:
                log.info(
                    "✅ FAVORABLE ENTRY - Near support or breakout detected",
                    throttle_key="favorable_entry",
                    throttle_interval=60
                )
        elif not bullish:
            # Fallback to M1 if MTF data unavailable
            return

        if spread_ok():
            # lot_index already reset to 0 at start of function
            # Use AI-adjusted lot size if available
            adjusted_lot = LOT_LADDER[0] * lot_multiplier
            if buy(adjusted_lot):
                log.info(f"Entry executed with AI-adjusted lot: {adjusted_lot} (multiplier: {lot_multiplier})")
            return

    # Grid recovery entries
    last_price = last_buy_price()

    gap = abs(tick.bid - last_price)

    # Adaptive grid spacing based on position count
    base_gap = 5.0  # ✅ INCREASED from 2.5 to 5.0 for more conservative spacing
    
    # Exponential growth: wider spacing for deeper grid levels
    # This protects against strong trends and reduces margin stress
    position_gap = math.pow(len(buy_positions), 1.5)  # ✅ INCREASED from 1.1 to 1.5 for wider gaps
    
    # ATR volatility adjustment
    atr_gap = atr_now * 1.0  # ✅ INCREASED from 0.5 to 1.0 for better volatility adaptation
    
    dynamic_gap = max(
        base_gap + position_gap,
        atr_gap
    )
    
    log.info(
        f"Grid Gap={dynamic_gap:.2f} | "
        f"Current Gap={gap:.2f} | "
        f"Positions={len(buy_positions)}",
        throttle_key="grid_gap",
        throttle_interval=5
    )

    if gap >= dynamic_gap:
        # ✅ ENHANCED: Multi-timeframe trend protection with S/R
        bullish = ema_fast.iloc[-1] > ema_slow.iloc[-1]
        
        # Use MTF analysis if available, otherwise fallback to M1
        if trend_analysis:
            # ✅ CRITICAL: Also check S/R for grid entries (less strict than first entry)
            if trend_analysis['block_reason'] == 'near_resistance':
                log.warning(
                    f"Grid entry SKIPPED - Price near resistance (avoid adding at ceiling)",
                    throttle_key="grid_resistance_block",
                    throttle_interval=30
                )
                return
            
            # For grid entries, require at least 2 out of 3 timeframes bullish
            if trend_analysis['trend_strength'] < 2:
                log.warning(
                    f"Grid entry SKIPPED - Weak MTF trend (strength:{trend_analysis['trend_strength']}/3)",
                    throttle_key="weak_mtf_trend",
                    throttle_interval=30
                )
                return
        elif not bullish:
            log.warning(
                f"Grid entry SKIPPED - Bearish M1 trend (EMA fast < slow)",
                throttle_key="bearish_skip",
                throttle_interval=30
            )
            return
        
        # ✅ NEW: Price stabilization check - look for reversal signs
        recent_closes = df['close'].iloc[-5:].values
        price_stabilizing = recent_closes[-1] > recent_closes[-3]  # Current > 3 candles ago
        
        if not price_stabilizing:
            log.warning(
                f"Grid entry SKIPPED - Price still falling (no stabilization)",
                throttle_key="falling_skip",
                throttle_interval=30
            )
            return
        
        # ✅ FIX: Use position count for lot index with bounds check
        # This ensures lot_index matches actual positions and prevents IndexError
        lot_index = min(len(buy_positions), len(LOT_LADDER) - 1)

        lot = LOT_LADDER[lot_index] * LOT_MULTIPLIER

        buy(lot)


# =========================================================
# TAKE PROFIT ENGINE (ENHANCED)
# =========================================================

# Global variables for trailing profit
tp_highest_pnl = 0.0
tp_trailing_active = False

def tp_engine():
    """
    ✅ ENHANCED: Take profit engine with trailing profit logic
    - Dynamic TP target based on multiple factors
    - Trailing profit: lock in gains when profit retraces
    - Partial profit taking for large gains
    """
    global lot_index, tp_highest_pnl, tp_trailing_active

    positions = get_positions(force=True)

    if not positions:
        # Reset trailing profit tracking when no positions
        tp_highest_pnl = 0.0
        tp_trailing_active = False
        return

    pnl = floating_pnl()
    total_lot = total_buy_volume()
    
    # Count BUY positions for grid depth
    buy_positions = [p for p in positions if p.type == mt5.POSITION_TYPE_BUY]
    position_count = len(buy_positions)

    target = dynamic_tp_target(total_lot, position_count)

    # Track highest PnL for trailing
    if pnl > tp_highest_pnl:
        tp_highest_pnl = pnl
    
    # Activate trailing when profit exceeds target by 50%
    if pnl >= target * 1.5:
        tp_trailing_active = True
        log.info(
            f"Trailing profit ACTIVATED | pnl={pnl:.2f} | highest={tp_highest_pnl:.2f}",
            throttle_key="trailing_active",
            throttle_interval=60
        )
    
    # Trailing profit logic: close if profit retraces 30% from highest
    if tp_trailing_active and pnl < tp_highest_pnl * 0.7:
        log.warning(
            f"TRAILING TP HIT | pnl={pnl:.2f} | highest={tp_highest_pnl:.2f} | retraced 30%"
        )
        close_all()
        lot_index = 0
        tp_highest_pnl = 0.0
        tp_trailing_active = False
        return
    
    # Standard TP: close when target reached
    if pnl >= target:
        log.warning(
            f"TP HIT | pnl={pnl:.2f} | target={target:.2f}"
        )
        close_all()
        lot_index = 0
        tp_highest_pnl = 0.0
        tp_trailing_active = False
        return
    
    # Partial profit taking for very large gains (3x target)
    if pnl >= target * 3.0 and position_count > 3:
        # Close half the positions to lock in profit
        positions_to_close = buy_positions[:len(buy_positions)//2]
        log.warning(
            f"PARTIAL TP | pnl={pnl:.2f} | target={target:.2f} | closing {len(positions_to_close)}/{len(buy_positions)} positions"
        )
        for pos in positions_to_close:
            try:
                request = {
                    "action": mt5.TRADE_ACTION_DEAL,
                    "position": pos.ticket,
                    "symbol": SYMBOL,
                    "volume": pos.volume,
                    "type": mt5.ORDER_TYPE_SELL,
                    "price": mt5.symbol_info_tick(SYMBOL).bid,
                    "magic": MAGIC,
                    "comment": "Partial TP",
                }
                mt5.order_send(request)
            except Exception as e:
                log.error(f"Failed to close position {pos.ticket}: {e}")


# =========================================================
# MAIN BOT LOOP (LATEST)
# =========================================================

def bot_loop():
    global latest_atr
    global latest_atr_mean

    print("\n[BOT] GoldAlgoBot main loop started with Multi-Timeframe Analysis")
    log.info("GoldAlgoBot started with MTF (M1, M5, M15)")

    loop_count = 0
    while True:
        try:
            loop_count += 1
            
            # MT5 connection health
            if not mt5_alive():
                print("[WARNING] MT5 connection lost, reconnecting...")
                log.warning("MT5 connection lost")
                time.sleep(2)
                continue

            # Account safety
            if equity_circuit_breaker():
                print("[WARNING] Equity circuit breaker triggered")
                continue

            if equity_trailing_lock():
                print("[WARNING] Equity trailing lock active")
                continue

            if daily_drawdown_guard():
                print("[WARNING] Daily drawdown guard active")
                log.warning("Daily drawdown guard active")
                time.sleep(30)
                continue

            # ✅ ENHANCED: Fetch multi-timeframe market data
            mtf_data = get_multi_timeframe_data()
            
            # Fallback to M1 only if MTF fails
            if mtf_data is None:
                log.warning("MTF data unavailable, using M1 only", throttle_key="mtf_fail", throttle_interval=60)
                df = get_market_data(200)
            else:
                df = mtf_data.get('M1')

            if df is None:
                if loop_count % 10 == 0:  # Print every 10 loops
                    print("[WARNING] Market data unavailable")
                time.sleep(1)
                continue

            latest_atr = df['atr'].iloc[-1]
            latest_atr_mean = df['atr'].rolling(50).mean().iloc[-1]

            # Update adaptive engine
            adaptive_engine()

            # Update regime mode
            update_market_regime_mode(
                df,
                latest_atr,
                latest_atr_mean
            )

            # Flat trap detection
            flat_trap_detector(df)

            # ✅ ENHANCED: Execute grid engine with multi-timeframe data
            grid_engine(df, mtf_data)

            # TP manager
            tp_engine()

            # Status logging
            log.info(
                f"PnL={floating_pnl():.2f} | "
                f"Lot={total_buy_volume():.2f} | "
                f"Positions={len(get_positions())}",
                throttle_key="status_log",
                throttle_interval=5
            )

            time.sleep(1)

        except KeyboardInterrupt:
            print("\n[INFO] Bot stopped manually")
            log.warning("Bot stopped manually")
            break

        except Exception as e:
            print(f"\n[ERROR] BOT LOOP ERROR: {e}")
            log.error(
                f"BOT LOOP ERROR: {e}",
                exc_info=True
            )
            traceback.print_exc()
            time.sleep(5)


# =========================================================
# FINAL ENTRY POINT
# =========================================================

if __name__ == "__main__":
    print("=" * 60)
    print("GOLD ALGO BOT - STARTING")
    print("=" * 60)
    
    try:
        init_mt5()
        
        # Start Gemini AI background updater
        start_gemini_background_updater()
        
        bot_loop()

    except KeyboardInterrupt:
        print("\n" + "=" * 60)
        print("BOT STOPPED BY USER")
        print("=" * 60)
        log.warning("Bot stopped by user")
        
    except Exception as e:
        print("\n" + "=" * 60)
        print(f"FATAL ERROR: {e}")
        print("=" * 60)
        log.critical(
            f"FATAL ERROR: {e}",
            exc_info=True
        )
        import traceback
        traceback.print_exc()
        
    finally:
        # Stop Gemini background updater
        stop_gemini_background_updater()
        
        print("\nShutting down MT5...")
        mt5.shutdown()
        print("MT5 shutdown complete")
        print("=" * 60)

