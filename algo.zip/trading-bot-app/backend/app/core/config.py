"""
Application configuration
"""

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application settings"""
    
    # API Settings
    API_V1_STR: str = "/api"
    PROJECT_NAME: str = "Trading Bot Management"
    
    # Database
    DATABASE_URL: str = "mysql+pymysql://user:password@localhost:3306/trading_bot"
    
    # Redis
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    
    # MT5 Settings
    MT5_LOGIN: Optional[int] = None
    MT5_PASSWORD: Optional[str] = None
    MT5_SERVER: Optional[str] = None
    
    # Bot Paths
    BUY_BOT_PATH: str = "../../algo_withouthedge.py"
    SELL_BOT_PATH: str = "../../algo_withouthedge_sell.py"
    
    # Gemini AI Settings
    GEMINI_API_KEY: Optional[str] = None
    GEMINI_MODEL: str = "gemini-2.0-flash-exp"
    GEMINI_ENABLED: bool = True
    GEMINI_UPDATE_INTERVAL: int = 60  # seconds
    GEMINI_MAX_RETRIES: int = 3
    GEMINI_RETRY_DELAY: int = 5  # seconds
    GEMINI_COOLDOWN_DURATION: int = 300  # 5 minutes
    
    # Security
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()

# Made with Bob
