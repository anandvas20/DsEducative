# Trading Bot Recommendations & Improvements

**Date**: June 3, 2026  
**Bots**: algo_withouthedge.py (BUY) & algo_withouthedge_sell.py (SELL)

---

## 📊 Summary of Changes Already Applied

### ✅ Completed:
1. **Grid Gap Spacing** - Increased to more conservative values
   - MIN_GRID_GAP: 1.5 → 5.0
   - base_gap: 2.5/3.0 → 5.0
   - position_gap exponent: 1.1/1.4 → 1.5
   - atr_gap multiplier: 0.5/0.7 → 1.0

2. **Profit Logic** - Unified across both bots
   - Single 0.01 lot position closes at $1.00
   - Formula: 1.0 + position_count^1.5 + (total_lot × 1.3)

---

## 🔧 High Priority Recommendations (Implement First)

### 1. Update Gemini AI Model ⭐⭐⭐

**Current Issue**: `gemini-2.5-flash` has quota limitations (20 requests/day)

**Solution**:
```python
# In both files, update line 239 (BUY) / 244 (SELL):
GEMINI_MODEL = "gemini-3.1-flash-lite"  # Change from "gemini-2.5-flash"
```

**Benefits**:
- ✅ No quota issues (tested and working)
- ✅ Faster response times (1-2 seconds)
- ✅ Better availability
- ✅ Same quality analysis

**Effort**: 2 minutes  
**Impact**: High

---

### 2. Add Daily Profit Target ⭐⭐⭐

**Current**: Only has MAX_DAILY_LOSS ($200)

**Add to Config Section**:
```python
MAX_DAILY_PROFIT = 100.0  # Close all positions when daily profit reaches $100
```

**Implementation in bot_loop**:
```python
def bot_loop():
    # ... existing code ...
    
    # Check daily profit target
    daily_profit = calculate_daily_profit()  # Need to implement
    if daily_profit >= MAX_DAILY_PROFIT:
        log.warning(f"Daily profit target reached: ${daily_profit:.2f}")
        close_all()
        # Pause trading for rest of day
        return
```

**Benefits**:
- Lock in daily gains
- Reduce overtrading
- Consistent profit taking
- Better risk management

**Effort**: 10 minutes  
**Impact**: High

---

### 3. Add Maximum Floating Drawdown Protection ⭐⭐⭐

**Current**: No maximum drawdown limit

**Add to Config Section**:
```python
MAX_FLOATING_DRAWDOWN = -150.0  # Close all if floating loss exceeds $150
```

**Implementation in tp_engine**:
```python
def tp_engine():
    # ... existing code ...
    
    pnl = floating_pnl()
    
    # Emergency drawdown protection
    if pnl <= MAX_FLOATING_DRAWDOWN:
        log.error(f"MAX DRAWDOWN HIT: {pnl:.2f} | Closing all positions")
        close_all()
        lot_index = 0
        return
    
    # ... rest of existing code ...
```

**Benefits**:
- Prevents catastrophic losses
- Automatic risk management
- Peace of mind
- Account protection

**Effort**: 5 minutes  
**Impact**: Critical

---

## 📈 Medium Priority Recommendations

### 4. Add Trading Time Restrictions ⭐⭐

**Purpose**: Avoid low liquidity and high-risk periods

**Add to Config Section**:
```python
# Trading hours (IST timezone)
TRADING_START_HOUR = 6   # 6:00 AM IST
TRADING_END_HOUR = 22    # 10:00 PM IST
AVOID_NEWS_WINDOW = 30   # Minutes before/after major news

# Major news times (GMT) - adjust for IST
HIGH_IMPACT_NEWS_TIMES = [
    "13:30",  # US Session open, major data releases
    "18:00",  # FOMC minutes
    "19:00",  # Fed speeches
]
```

**Implementation**:
```python
def is_trading_allowed():
    """Check if current time is within trading hours"""
    now = datetime.now()
    current_hour = now.hour
    
    # Check trading hours
    if current_hour < TRADING_START_HOUR or current_hour >= TRADING_END_HOUR:
        return False, "Outside trading hours"
    
    # Check if near major news (optional - requires news calendar API)
    # if is_near_major_news():
    #     return False, "Near major news event"
    
    return True, "OK"

# Use in grid_engine before opening positions:
allowed, reason = is_trading_allowed()
if not allowed:
    log.info(f"Trading paused: {reason}")
    return
```

**Benefits**:
- Avoid low liquidity periods
- Skip high-spread times
- Reduce news-driven volatility
- Better entry quality

**Effort**: 15 minutes  
**Impact**: Medium

---

### 5. Improve Take Profit Logic with Volatility ⭐⭐

**Current**: Fixed formula

**Enhanced Version**:
```python
def dynamic_tp_target(total_lot, position_count, atr=None):
    """Calculate dynamic take profit target based on grid depth and volatility"""
    if position_count == 0:
        return 1.0
    
    # Quick exit for single 0.01 lot position
    if position_count == 1 and total_lot <= 0.01:
        return 1.0
    
    base_target = 1.0
    position_multiplier = math.pow(position_count, 1.5)
    lot_component = total_lot * 1.3
    
    base_tp = base_target + position_multiplier + lot_component
    
    # Adjust for volatility if ATR available
    if atr:
        if atr > 3.0:  # High volatility - take profit faster
            return base_tp * 1.2
        elif atr < 1.5:  # Low volatility - can wait for more
            return base_tp * 0.8
    
    return base_tp
```

**Update tp_engine call**:
```python
# In tp_engine function:
atr_current = df['atr'].iloc[-1] if df is not None else None
target = dynamic_tp_target(total_lot, position_count, atr_current)
```

**Benefits**:
- Adapts to market conditions
- Faster exits in volatile markets
- Better profit optimization
- Reduced risk in choppy markets

**Effort**: 10 minutes  
**Impact**: Medium

---

### 6. Add Position Averaging Limit ⭐⭐

**Purpose**: Prevent rapid position accumulation

**Add to Config Section**:
```python
MAX_POSITIONS_PER_HOUR = 3  # Don't open more than 3 positions in 1 hour
```

**Implementation**:
```python
# Add to global variables
position_open_times = []

def can_open_position():
    """Check if we can open a new position based on time limits"""
    global position_open_times
    
    now = time.time()
    one_hour_ago = now - 3600
    
    # Remove entries older than 1 hour
    position_open_times = [t for t in position_open_times if t > one_hour_ago]
    
    if len(position_open_times) >= MAX_POSITIONS_PER_HOUR:
        return False, f"Max {MAX_POSITIONS_PER_HOUR} positions per hour reached"
    
    return True, "OK"

# Use in grid_engine before opening positions:
can_open, reason = can_open_position()
if not can_open:
    log.warning(f"Position opening blocked: {reason}")
    return

# After successful position open:
position_open_times.append(time.time())
```

**Benefits**:
- Prevents panic trading
- Gives time for price stabilization
- Reduces emotional decisions
- Better position quality

**Effort**: 15 minutes  
**Impact**: Medium

---

## 🎯 Low Priority Recommendations (Nice to Have)

### 7. Add Telegram Notifications ⭐

**Purpose**: Real-time alerts on mobile

**Setup**:
```python
import requests

TELEGRAM_BOT_TOKEN = "your_bot_token"
TELEGRAM_CHAT_ID = "your_chat_id"

def send_telegram(message):
    """Send message to Telegram"""
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        data = {"chat_id": TELEGRAM_CHAT_ID, "text": message}
        requests.post(url, data=data, timeout=5)
    except Exception as e:
        log.error(f"Telegram send failed: {e}")

# Use for important events:
send_telegram(f"🟢 BUY Position Opened | Price: {price} | Lot: {lot}")
send_telegram(f"💰 Daily Profit: ${daily_profit:.2f}")
send_telegram(f"⚠️ Max Positions Reached: {len(positions)}")
send_telegram(f"🔴 Drawdown Warning: ${pnl:.2f}")
```

**Benefits**:
- Real-time monitoring
- Quick response to issues
- Daily summaries
- Peace of mind

**Effort**: 30 minutes (including Telegram bot setup)  
**Impact**: Low (convenience)

---

### 8. Enhanced Logging to CSV ⭐

**Purpose**: Better trade analysis and optimization

**Implementation**:
```python
import csv
from datetime import datetime

def log_trade_to_csv(trade_data):
    """Log trade details to CSV for analysis"""
    filename = f"trades_{datetime.now().strftime('%Y%m')}.csv"
    
    with open(filename, 'a', newline='') as f:
        writer = csv.writer(f)
        
        # Write header if file is new
        if f.tell() == 0:
            writer.writerow([
                'timestamp', 'type', 'symbol', 'lot', 'entry_price', 
                'exit_price', 'profit', 'duration', 'position_count',
                'rsi', 'macd', 'atr', 'ai_signal', 'ai_confidence'
            ])
        
        writer.writerow([
            datetime.now().isoformat(),
            trade_data['type'],
            trade_data['symbol'],
            trade_data['lot'],
            trade_data['entry_price'],
            trade_data['exit_price'],
            trade_data['profit'],
            trade_data['duration'],
            trade_data['position_count'],
            trade_data.get('rsi', ''),
            trade_data.get('macd', ''),
            trade_data.get('atr', ''),
            trade_data.get('ai_signal', ''),
            trade_data.get('ai_confidence', '')
        ])

# Call when closing positions:
log_trade_to_csv({
    'type': 'BUY',
    'symbol': SYMBOL,
    'lot': position.volume,
    'entry_price': position.price_open,
    'exit_price': tick.bid,
    'profit': position.profit,
    'duration': time.time() - position.time,
    'position_count': len(positions),
    'rsi': df['rsi'].iloc[-1],
    'macd': df['macd'].iloc[-1],
    'atr': df['atr'].iloc[-1],
    'ai_signal': gemini_ai_cache.get('signal'),
    'ai_confidence': gemini_ai_cache.get('confidence')
})
```

**Benefits**:
- Detailed trade history
- Performance analysis
- Strategy optimization
- Identify patterns

**Effort**: 20 minutes  
**Impact**: Low (analysis tool)

---

### 9. Add Trailing Stop Loss ⭐

**Purpose**: Protect profits while letting winners run

**Add to Config Section**:
```python
TRAILING_STOP = {
    'enabled': True,
    'activation_profit': 5.0,   # Start trailing after $5 profit
    'trail_distance': 3.0,       # Trail 3 points behind
    'update_interval': 60        # Update every 60 seconds
}
```

**Implementation**:
```python
trailing_stop_levels = {}  # {position_ticket: stop_level}

def update_trailing_stops():
    """Update trailing stop losses for profitable positions"""
    if not TRAILING_STOP['enabled']:
        return
    
    positions = get_positions(force=True)
    tick = safe_tick()
    
    for position in positions:
        if position.profit >= TRAILING_STOP['activation_profit']:
            # Calculate new stop level
            if position.type == mt5.POSITION_TYPE_BUY:
                new_stop = tick.bid - TRAILING_STOP['trail_distance']
            else:  # SELL
                new_stop = tick.ask + TRAILING_STOP['trail_distance']
            
            # Update if better than current stop
            current_stop = trailing_stop_levels.get(position.ticket, position.sl)
            
            if position.type == mt5.POSITION_TYPE_BUY:
                if new_stop > current_stop:
                    modify_position_sl(position.ticket, new_stop)
                    trailing_stop_levels[position.ticket] = new_stop
            else:  # SELL
                if new_stop < current_stop or current_stop == 0:
                    modify_position_sl(position.ticket, new_stop)
                    trailing_stop_levels[position.ticket] = new_stop

# Call in bot_loop every minute:
if int(time.time()) % TRAILING_STOP['update_interval'] == 0:
    update_trailing_stops()
```

**Benefits**:
- Protect profits automatically
- Let winners run
- Reduce emotional decisions
- Better risk/reward

**Effort**: 30 minutes  
**Impact**: Low (optimization)

---

### 10. Market Regime Detection ⭐

**Purpose**: Adapt strategy to market conditions

**Implementation**:
```python
def detect_market_regime(df):
    """Detect if market is trending or ranging"""
    if df is None or len(df) < 50:
        return "UNKNOWN"
    
    atr = df['atr'].iloc[-1]
    atr_mean = df['atr'].iloc[-50:].mean()
    
    # Price movement analysis
    high_50 = df['high'].iloc[-50:].max()
    low_50 = df['low'].iloc[-50:].min()
    range_50 = high_50 - low_50
    
    # Trend strength
    ema_fast = df['ema_fast'].iloc[-1]
    ema_slow = df['ema_slow'].iloc[-1]
    ema_diff = abs(ema_fast - ema_slow)
    
    # Classification
    if atr > atr_mean * 1.5 and ema_diff > 2.0:
        return "STRONG_TRENDING"
    elif atr > atr_mean * 1.2:
        return "TRENDING"
    elif atr < atr_mean * 0.7 and range_50 < 15:
        return "RANGING"
    else:
        return "NORMAL"

# Use to adjust grid gaps:
regime = detect_market_regime(df)

if regime == "STRONG_TRENDING":
    # Use wider gaps in strong trends
    base_gap = 7.0
    position_gap_exp = 1.7
elif regime == "RANGING":
    # Use tighter gaps in ranging markets
    base_gap = 4.0
    position_gap_exp = 1.3
else:
    # Normal settings
    base_gap = 5.0
    position_gap_exp = 1.5
```

**Benefits**:
- Adapts to market conditions
- Better entry timing
- Reduced risk in trends
- More opportunities in ranges

**Effort**: 25 minutes  
**Impact**: Low (optimization)

---

## 📋 Implementation Priority

### Phase 1: Critical Safety (Do This Week)
1. ✅ Update Gemini model to `gemini-3.1-flash-lite`
2. ✅ Add MAX_DAILY_PROFIT ($100)
3. ✅ Add MAX_FLOATING_DRAWDOWN (-$150)

**Total Effort**: ~20 minutes  
**Impact**: Critical for safety

---

### Phase 2: Risk Management (Do This Month)
4. Add trading time restrictions
5. Improve TP logic with volatility
6. Add position averaging limit

**Total Effort**: ~40 minutes  
**Impact**: Significant improvement

---

### Phase 3: Monitoring & Analysis (Optional)
7. Telegram notifications
8. Enhanced CSV logging
9. Trailing stop loss
10. Market regime detection

**Total Effort**: ~2 hours  
**Impact**: Nice to have features

---

## 🎯 Quick Implementation Checklist

### Immediate Actions (Today):
- [ ] Update GEMINI_MODEL in both files
- [ ] Add MAX_DAILY_PROFIT config
- [ ] Add MAX_FLOATING_DRAWDOWN config
- [ ] Implement drawdown check in tp_engine
- [ ] Test on demo account

### This Week:
- [ ] Add trading hours restriction
- [ ] Implement volatility-adjusted TP
- [ ] Add position rate limiting
- [ ] Monitor and adjust settings

### This Month:
- [ ] Set up Telegram bot (optional)
- [ ] Implement CSV logging (optional)
- [ ] Add trailing stops (optional)
- [ ] Test market regime detection (optional)

---

## 📊 Expected Results

### With Phase 1 (Critical Safety):
- ✅ Reduced quota issues (Gemini model update)
- ✅ Consistent daily profit taking
- ✅ Protection from catastrophic losses
- ✅ Better risk management

### With Phase 2 (Risk Management):
- ✅ Better entry timing
- ✅ Reduced overtrading
- ✅ Improved profit optimization
- ✅ Lower drawdowns

### With Phase 3 (Monitoring):
- ✅ Real-time alerts
- ✅ Better trade analysis
- ✅ Profit protection
- ✅ Strategy optimization

---

## 📝 Notes

- All recommendations are based on current bot analysis
- Test each change on demo account first
- Monitor performance for at least 1 week before going live
- Adjust parameters based on your risk tolerance
- Keep backups of working configurations

---

**Document Created**: June 3, 2026  
**Last Updated**: June 3, 2026  
**Status**: Ready for Review and Implementation