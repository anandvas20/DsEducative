"""
Gemini AI API routes
"""

from fastapi import APIRouter, HTTPException
from typing import Dict, Any
from pydantic import BaseModel

from ...core.gemini_service import get_gemini_service


router = APIRouter()


class MarketDataRequest(BaseModel):
    """Market data for AI analysis"""
    symbol: str
    timeframe: str
    price: float
    rsi: float
    macd: float
    macd_signal: float
    ema20: float
    ema50: float
    ema200: float
    atr: float
    support: float
    resistance: float
    volume: int
    trend: str
    mtf_trend: str
    spread: float


@router.get("/status")
async def get_gemini_status() -> Dict[str, Any]:
    """
    Get Gemini AI service status
    
    Returns cache status, rate limiting info, and availability
    """
    service = get_gemini_service()
    
    if not service:
        return {
            "enabled": False,
            "available": False,
            "message": "Gemini AI service not configured"
        }
    
    status = service.get_cache_status()
    status["available"] = service.enabled
    
    return status


@router.get("/signal/{bot_type}")
async def get_trading_signal(bot_type: str) -> Dict[str, Any]:
    """
    Get current AI trading signal from cache
    
    Args:
        bot_type: 'buy' or 'sell'
    
    Returns:
        AI analysis with entry decision, market context, timing, etc.
    """
    if bot_type not in ['buy', 'sell']:
        raise HTTPException(status_code=400, detail="bot_type must be 'buy' or 'sell'")
    
    service = get_gemini_service()
    
    if not service or not service.enabled:
        raise HTTPException(status_code=503, detail="Gemini AI service not available")
    
    # Get signal from cache (non-blocking)
    signal = service.get_trading_signal(bot_type, {})
    
    if not signal:
        raise HTTPException(status_code=404, detail="No AI signal available in cache")
    
    return signal


@router.post("/update/{bot_type}")
async def update_ai_cache(bot_type: str, market_data: MarketDataRequest) -> Dict[str, Any]:
    """
    Manually trigger AI cache update with market data
    
    Args:
        bot_type: 'buy' or 'sell'
        market_data: Current market data with indicators
    
    Returns:
        Success status
    """
    if bot_type not in ['buy', 'sell']:
        raise HTTPException(status_code=400, detail="bot_type must be 'buy' or 'sell'")
    
    service = get_gemini_service()
    
    if not service or not service.enabled:
        raise HTTPException(status_code=503, detail="Gemini AI service not available")
    
    # Convert to dict
    data = market_data.model_dump()
    
    # Update cache (this will call Gemini API)
    success = service.update_cache(bot_type, data)
    
    if not success:
        raise HTTPException(status_code=500, detail="Failed to update AI cache")
    
    return {
        "status": "success",
        "message": f"AI cache updated for {bot_type} bot",
        "bot_type": bot_type
    }


@router.post("/start-updater")
async def start_background_updater() -> Dict[str, str]:
    """Start the Gemini AI background updater thread"""
    service = get_gemini_service()
    
    if not service:
        raise HTTPException(status_code=503, detail="Gemini AI service not available")
    
    service.start_background_updater()
    
    return {
        "status": "success",
        "message": "Background updater started"
    }


@router.post("/stop-updater")
async def stop_background_updater() -> Dict[str, str]:
    """Stop the Gemini AI background updater thread"""
    service = get_gemini_service()
    
    if not service:
        raise HTTPException(status_code=503, detail="Gemini AI service not available")
    
    service.stop_background_updater()
    
    return {
        "status": "success",
        "message": "Background updater stopped"
    }


# Made with Bob