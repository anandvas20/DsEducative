#!/bin/bash

# Trading Bot Management App - Startup Script

echo "=========================================="
echo "Trading Bot Management App"
echo "=========================================="
echo ""

# Check if virtual environment exists
if [ ! -d "backend/venv" ]; then
    echo "Creating Python virtual environment..."
    cd backend
    python3 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt
    cd ..
else
    echo "✓ Virtual environment found"
fi

# Check if .env exists
if [ ! -f "backend/.env" ]; then
    echo "⚠️  Warning: .env file not found!"
    echo "Creating .env from .env.example..."
    cp backend/.env.example backend/.env
    echo "Please edit backend/.env with your MT5 credentials"
    echo ""
fi

# Start backend
echo "Starting backend server..."
cd backend
source venv/bin/activate
cd app
python main.py &
BACKEND_PID=$!
cd ../..

echo "✓ Backend started (PID: $BACKEND_PID)"
echo "  API: http://localhost:8000"
echo "  Docs: http://localhost:8000/docs"
echo ""

# Check if frontend exists
if [ -d "frontend/node_modules" ]; then
    echo "Starting frontend server..."
    cd frontend
    npm start &
    FRONTEND_PID=$!
    cd ..
    echo "✓ Frontend started (PID: $FRONTEND_PID)"
    echo "  App: http://localhost:4200"
else
    echo "⚠️  Frontend dependencies not installed. Run 'cd frontend && npm install' first"
fi

echo ""
echo "=========================================="
echo "Application is running!"
echo "=========================================="
echo ""
echo "Press Ctrl+C to stop all services"
echo ""

# Wait for Ctrl+C
trap "echo 'Stopping services...'; kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit" INT
wait

# Made with Bob
