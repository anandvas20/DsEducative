#!/bin/bash

# Angular Frontend Setup Script

echo "=========================================="
echo "Setting up Angular Frontend"
echo "=========================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm not found. Please install npm first."
    exit 1
fi

echo "✓ Node.js version: $(node --version)"
echo "✓ npm version: $(npm --version)"
echo ""

# Navigate to frontend directory
cd frontend

# Check if package.json exists
if [ ! -f "package.json" ]; then
    echo "❌ package.json not found in frontend directory"
    exit 1
fi

# Install dependencies
echo "Installing frontend dependencies..."
npm install

echo ""
echo "=========================================="
echo "✓ Frontend setup complete!"
echo "=========================================="
echo ""
echo "To start the frontend:"
echo "  cd frontend"
echo "  npm start"
echo ""
echo "Frontend will be available at: http://localhost:4200"

# Made with Bob
