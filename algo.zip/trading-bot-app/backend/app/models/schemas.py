"""
Pydantic schemas for API request/response validation
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


# ============================================================================
# Bot Configuration Schemas
# ============================================================================

class BotConfig(BaseModel):
    """Individual bot configuration"""
    symbol: str = Field(default="XAUUSD", description="Trading symbol")
    lot_size: float = Field(default=0.01, ge=0.01, description="Base lot size")
    max_positions: int = Field(default=5, ge=1, le=20, description="Maximum concurrent positions")
    
    # Ladder Configuration
    num_ladders: int = Field(default=5, ge=1, le=10, description="Number of ladder levels")
    ladder_gap_points: int = Field(default=50, ge=10, description="Gap between ladders in points")
    
    # Profit Targets
    profit_target_points: int = Field(default=100, ge=10, description="Profit target in points")
    trailing_profit_enabled: bool = Field(default=True, description="Enable trailing profit")
    trailing_profit_distance: int = Field(default=30, ge=10, description="Trailing distance in points")
    partial_profit_enabled: bool = Field(default=True, description="Enable partial profit taking")
    partial_profit_percentage: int = Field(default=50, ge=10, le=90, description="Percentage to close at profit")
    
    # Risk Management
    max_daily_loss: float = Field(default=1000, ge=100, description="Maximum daily loss in dollars")
    max_drawdown_percent: float = Field(default=10, ge=1, le=50, description="Maximum drawdown percentage")
    
    # Daily Profit Target
    daily_profit_target: Optional[float] = Field(default=None, ge=0, description="Daily profit target - close all and stop when reached")
    close_all_on_daily_target: bool = Field(default=False, description="Close all positions when daily target reached")
    stop_trading_on_daily_target: bool = Field(default=False, description="Stop bots when daily target reached")
    
    # Trading Hours
    trading_start_hour: int = Field(default=0, ge=0, le=23, description="Trading start hour (24h format)")
    trading_start_minute: int = Field(default=0, ge=0, le=59, description="Trading start minute")
    trading_end_hour: int = Field(default=23, ge=0, le=23, description="Trading end hour (24h format)")
    trading_end_minute: int = Field(default=59, ge=0, le=59, description="Trading end minute")
    trading_timezone: str = Field(default="UTC", description="Trading timezone (e.g., 'Asia/Calcutta', 'America/New_York')")
    
    # Skip Trading Days
    skip_monday: bool = Field(default=False, description="Skip trading on Monday")
    skip_tuesday: bool = Field(default=False, description="Skip trading on Tuesday")
    skip_wednesday: bool = Field(default=False, description="Skip trading on Wednesday")
    skip_thursday: bool = Field(default=False, description="Skip trading on Thursday")
    skip_friday: bool = Field(default=False, description="Skip trading on Friday")
    skip_saturday: bool = Field(default=True, description="Skip trading on Saturday")
    skip_sunday: bool = Field(default=True, description="Skip trading on Sunday")


class BotTemplate(BaseModel):
    """Configuration template"""
    id: str = Field(..., description="Unique template identifier")
    name: str = Field(..., min_length=1, max_length=100, description="Template name")
    description: str = Field(default="", max_length=500, description="Template description")
    config: BotConfig = Field(..., description="Bot configuration")
    is_default: bool = Field(default=False, description="Whether this is a default template")
    created_at: Optional[datetime] = Field(default=None, description="Creation timestamp")
    updated_at: Optional[datetime] = Field(default=None, description="Last update timestamp")


class BotAssignment(BaseModel):
    """Bot-to-template assignments"""
    buy_bot_template: str = Field(default="default", description="Template ID for BUY bot")
    sell_bot_template: str = Field(default="default", description="Template ID for SELL bot")


class ConfigurationData(BaseModel):
    """Complete configuration data"""
    templates: List[BotTemplate] = Field(default_factory=list, description="List of configuration templates")
    assignments: BotAssignment = Field(default_factory=BotAssignment, description="Bot assignments")
    
    # MT5 Connection (global settings)
    mt5_login: str = Field(default="", description="MT5 account login")
    mt5_password: str = Field(default="", description="MT5 account password")
    mt5_server: str = Field(default="", description="MT5 server name")
    
    # Gemini AI (global settings)
    gemini_api_key: str = Field(default="", description="Gemini API key")
    gemini_enabled: bool = Field(default=True, description="Enable Gemini AI")


# ============================================================================
# Bot Control Schemas
# ============================================================================

class BotStatus(BaseModel):
    """Bot status information"""
    bot_id: str = Field(..., description="Bot identifier (buy/sell)")
    status: str = Field(..., description="Bot status (running/stopped/error)")
    uptime: Optional[int] = Field(default=None, description="Uptime in seconds")
    last_trade: Optional[datetime] = Field(default=None, description="Last trade timestamp")
    active_positions: int = Field(default=0, description="Number of active positions")
    template_id: Optional[str] = Field(default=None, description="Assigned template ID")


class BotControlRequest(BaseModel):
    """Bot control request"""
    bot_id: str = Field(..., description="Bot identifier (buy/sell)")
    action: str = Field(..., description="Action to perform (start/stop/restart)")


class BotControlResponse(BaseModel):
    """Bot control response"""
    success: bool = Field(..., description="Whether action was successful")
    message: str = Field(..., description="Response message")
    bot_status: Optional[BotStatus] = Field(default=None, description="Updated bot status")


# ============================================================================
# Position Schemas
# ============================================================================

class Position(BaseModel):
    """Trading position"""
    ticket: int = Field(..., description="Position ticket number")
    symbol: str = Field(..., description="Trading symbol")
    type: str = Field(..., description="Position type (buy/sell)")
    volume: float = Field(..., description="Position volume")
    open_price: float = Field(..., description="Opening price")
    current_price: float = Field(..., description="Current price")
    profit: float = Field(..., description="Current profit/loss")
    open_time: datetime = Field(..., description="Opening time")
    magic: int = Field(..., description="Magic number")
    comment: str = Field(default="", description="Position comment")


class PositionSummary(BaseModel):
    """Summary of all positions"""
    total_positions: int = Field(..., description="Total number of positions")
    buy_positions: int = Field(..., description="Number of buy positions")
    sell_positions: int = Field(..., description="Number of sell positions")
    total_profit: float = Field(..., description="Total profit/loss")
    total_volume: float = Field(..., description="Total volume")
    positions: List[Position] = Field(default_factory=list, description="List of positions")


# ============================================================================
# Analytics Schemas
# ============================================================================

class TradeStatistics(BaseModel):
    """Trading statistics"""
    total_trades: int = Field(default=0, description="Total number of trades")
    winning_trades: int = Field(default=0, description="Number of winning trades")
    losing_trades: int = Field(default=0, description="Number of losing trades")
    win_rate: float = Field(default=0.0, description="Win rate percentage")
    total_profit: float = Field(default=0.0, description="Total profit")
    total_loss: float = Field(default=0.0, description="Total loss")
    net_profit: float = Field(default=0.0, description="Net profit")
    average_win: float = Field(default=0.0, description="Average winning trade")
    average_loss: float = Field(default=0.0, description="Average losing trade")
    profit_factor: float = Field(default=0.0, description="Profit factor")
    max_drawdown: float = Field(default=0.0, description="Maximum drawdown")


class DailyPerformance(BaseModel):
    """Daily performance data"""
    date: str = Field(..., description="Date in YYYY-MM-DD format")
    trades: int = Field(default=0, description="Number of trades")
    profit: float = Field(default=0.0, description="Daily profit/loss")
    win_rate: float = Field(default=0.0, description="Daily win rate")


class AnalyticsData(BaseModel):
    """Complete analytics data"""
    statistics: TradeStatistics = Field(..., description="Overall statistics")
    daily_performance: List[DailyPerformance] = Field(default_factory=list, description="Daily performance data")
    equity_curve: List[Dict[str, Any]] = Field(default_factory=list, description="Equity curve data points")


# ============================================================================
# WebSocket Event Schemas
# ============================================================================

class WebSocketEvent(BaseModel):
    """WebSocket event message"""
    event_type: str = Field(..., description="Event type")
    data: Dict[str, Any] = Field(..., description="Event data")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Event timestamp")


class TradeEvent(BaseModel):
    """Trade execution event"""
    ticket: int = Field(..., description="Trade ticket")
    symbol: str = Field(..., description="Trading symbol")
    type: str = Field(..., description="Trade type")
    volume: float = Field(..., description="Trade volume")
    price: float = Field(..., description="Execution price")
    profit: Optional[float] = Field(default=None, description="Profit (for closed trades)")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Trade timestamp")


class BotStatusEvent(BaseModel):
    """Bot status change event"""
    bot_id: str = Field(..., description="Bot identifier")
    old_status: str = Field(..., description="Previous status")
    new_status: str = Field(..., description="New status")
    reason: Optional[str] = Field(default=None, description="Reason for status change")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Event timestamp")


# ============================================================================
# Response Schemas
# ============================================================================

class SuccessResponse(BaseModel):
    """Generic success response"""
    success: bool = Field(default=True, description="Success flag")
    message: str = Field(..., description="Response message")
    data: Optional[Dict[str, Any]] = Field(default=None, description="Additional data")


class ErrorResponse(BaseModel):
    """Generic error response"""
    success: bool = Field(default=False, description="Success flag")
    error: str = Field(..., description="Error message")
    details: Optional[Dict[str, Any]] = Field(default=None, description="Error details")


# ============================================================================
# Template Management Schemas
# ============================================================================

class CreateTemplateRequest(BaseModel):
    """Request to create a new template"""
    name: str = Field(..., min_length=1, max_length=100, description="Template name")
    description: str = Field(default="", max_length=500, description="Template description")
    config: BotConfig = Field(..., description="Bot configuration")


class UpdateTemplateRequest(BaseModel):
    """Request to update an existing template"""
    name: Optional[str] = Field(default=None, min_length=1, max_length=100, description="Template name")
    description: Optional[str] = Field(default=None, max_length=500, description="Template description")
    config: Optional[BotConfig] = Field(default=None, description="Bot configuration")


class AssignTemplateRequest(BaseModel):
    """Request to assign template to bot"""
    bot_id: str = Field(..., description="Bot identifier (buy/sell)")
    template_id: str = Field(..., description="Template ID to assign")


# Made with Bob