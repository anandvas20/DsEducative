import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { WebsocketService } from './core/services/websocket.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'Trading Bot Management';
  wsConnected = false;
  sidebarOpen = true;

  constructor(private websocketService: WebsocketService) {}

  ngOnInit(): void {
    // Connect to WebSocket
    this.websocketService.connect();
    
    // Subscribe to connection status
    this.websocketService.getConnectionStatus().subscribe(
      status => {
        this.wsConnected = status;
        console.log('WebSocket connection status:', status);
      }
    );
  }

  ngOnDestroy(): void {
    this.websocketService.disconnect();
  }

  toggleSidebar(): void {
    this.sidebarOpen = !this.sidebarOpen;
  }
}

// Made with Bob
