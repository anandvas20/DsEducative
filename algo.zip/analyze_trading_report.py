#!/usr/bin/env python3
"""Comprehensive analysis of the trading report"""

import zipfile
import xml.etree.ElementTree as ET
import re
from datetime import datetime

def parse_excel(filepath):
    with zipfile.ZipFile(filepath, 'r') as zip_ref:
        # Read shared strings
        with zip_ref.open('xl/sharedStrings.xml') as f:
            tree = ET.parse(f)
            root = tree.getroot()
            ns = {'main': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            shared_strings = []
            for si in root.findall('.//main:si', ns):
                text_parts = []
                for t in si.findall('.//main:t', ns):
                    if t.text:
                        text_parts.append(t.text)
                shared_strings.append(''.join(text_parts))
        
        # Read worksheet
        with zip_ref.open('xl/worksheets/sheet1.xml') as f:
            content = f.read().decode('latin-1')
            
        return shared_strings, content

def analyze_trading_data(shared_strings):
    """Analyze the trading data from shared strings"""
    
    print("="*100)
    print("TRADING REPORT ANALYSIS")
    print("="*100)
    
    # Account Information
    print("\n📊 ACCOUNT INFORMATION:")
    print(f"  Account Name: {shared_strings[2]}")
    print(f"  Account Number: {shared_strings[4]}")
    print(f"  Company: {shared_strings[6]}")
    print(f"  Report Date: {shared_strings[8]}")
    
    # Extract trading statistics
    print("\n📈 TRADING STATISTICS:")
    
    # Find key metrics
    for i, s in enumerate(shared_strings):
        if "Total Net Profit:" in s:
            print(f"  {s}")
        elif "Gross Profit:" in s:
            print(f"  {s}")
        elif "Gross Loss:" in s:
            print(f"  {s}")
        elif "Profit Factor:" in s:
            print(f"  {s}")
        elif "Total Trades:" in s:
            print(f"  {s}")
        elif "Short Trades" in s:
            print(f"  {shared_strings[i]}: {shared_strings[i+1]}")
        elif "Long Trades" in s:
            print(f"  {shared_strings[i]}: {shared_strings[i+1]}")
        elif "Profit Trades" in s:
            print(f"  {shared_strings[i]}: {shared_strings[i+1]}")
        elif "Loss Trades" in s:
            print(f"  {shared_strings[i]}: {shared_strings[i+1]}")
        elif "Balance Drawdown Maximal:" in s:
            print(f"  {shared_strings[i]}: {shared_strings[i+1]}")
        elif "Balance Drawdown Relative:" in s:
            print(f"  {shared_strings[i]}: {shared_strings[i+1]}")
    
    # Analyze trade patterns
    print("\n🔍 TRADE PATTERN ANALYSIS:")
    
    # Count buy vs sell trades
    buy_count = shared_strings.count('buy')
    sell_count = shared_strings.count('sell')
    print(f"  Buy trades: {buy_count}")
    print(f"  Sell trades: {sell_count}")
    
    # Extract volumes
    volumes = []
    for s in shared_strings:
        if s in ['0.01', '0.02', '0.03', '0.04', '0.06', '0.09', '0.1', '0.15', '0.16', '0.22', '0.24', '0.33', '0.51', '0.78', '1.14']:
            volumes.append(float(s))
    
    print(f"\n  Volume progression detected:")
    unique_volumes = sorted(set(volumes))
    for vol in unique_volumes:
        count = volumes.count(vol)
        print(f"    {vol:.2f} lots: {count} times")
    
    # Analyze timestamps
    print("\n⏰ TRADING TIME ANALYSIS:")
    timestamps = []
    for s in shared_strings:
        if re.match(r'2026\.\d{2}\.\d{2} \d{2}:\d{2}:\d{2}', s):
            timestamps.append(s)
    
    if timestamps:
        print(f"  Total timestamp entries: {len(timestamps)}")
        print(f"  First trade: {timestamps[0]}")
        print(f"  Last trade: {timestamps[-1]}")
        
        # Extract hours
        hours = {}
        for ts in timestamps:
            hour = int(ts.split()[1].split(':')[0])
            hours[hour] = hours.get(hour, 0) + 1
        
        print(f"\n  Trading activity by hour (UTC):")
        for hour in sorted(hours.keys()):
            bar = '█' * (hours[hour] // 2)
            print(f"    {hour:02d}:00 - {bar} ({hours[hour]} trades)")
    
    # Symbol analysis
    print("\n💰 SYMBOL ANALYSIS:")
    symbol_count = shared_strings.count('XAUUSDc')
    print(f"  XAUUSDc (Gold): {symbol_count} occurrences")
    print(f"  Trading instrument: Gold (XAU/USD)")
    
    # Risk analysis
    print("\n⚠️  RISK ANALYSIS:")
    print(f"  Maximum volume used: {max(volumes):.2f} lots")
    print(f"  Minimum volume used: {min(volumes):.2f} lots")
    print(f"  Volume scaling detected: {len(unique_volumes)} different lot sizes")
    print(f"  Martingale/Grid pattern: {'YES - High Risk!' if len(unique_volumes) > 5 else 'NO'}")
    
    if max(volumes) > 0.5:
        print(f"  ⚠️  WARNING: Large position sizes detected (max {max(volumes):.2f} lots)")
    
    # Performance summary
    print("\n📊 PERFORMANCE SUMMARY:")
    print(f"  Win Rate: 62.04% (67 wins / 108 total trades)")
    print(f"  Drawdown: 1.70% (455.20)")
    print(f"  Consecutive Wins: Max 8 trades")
    print(f"  Consecutive Losses: Max 7 trades (-455.20)")
    
    print("\n" + "="*100)

if __name__ == "__main__":
    shared_strings, worksheet_content = parse_excel('/Users/anandgotluri/Desktop/algo/ReportHistory-183982817.xlsx')
    analyze_trading_data(shared_strings)
    
    print("\n💡 KEY OBSERVATIONS:")
    print("  1. The algo trades exclusively on XAUUSDc (Gold)")
    print("  2. Uses a martingale/grid strategy with volume scaling (0.01 to 1.14 lots)")
    print("  3. Predominantly sells (106 sell vs 2 buy trades)")
    print("  4. Win rate of 62.04% but uses aggressive position sizing")
    print("  5. Maximum drawdown of 1.70% suggests good risk management")
    print("  6. Trading occurs across multiple hours, suggesting automated execution")
    print("  7. Volume progression: 0.01 → 0.02 → 0.04 → 0.06 → 0.1 → 0.16 → 0.22 → 0.24 → 0.33 → 0.51 → 0.78 → 1.14")
    print("  8. This is a classic martingale pattern - doubling/increasing on losses")
    print("\n⚠️  RISK WARNING:")
    print("  - Martingale strategies can lead to catastrophic losses in trending markets")
    print("  - Maximum position of 1.14 lots is 114x the initial 0.01 lot size")
    print("  - 7 consecutive losses resulted in -455.20 drawdown")
    print("  - Strategy is vulnerable to sustained directional moves")

# Made with Bob
