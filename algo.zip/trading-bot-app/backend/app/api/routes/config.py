"""
Configuration API routes with template management
"""

from fastapi import APIRouter, HTTPException
from typing import Dict, List
import json
import os
from datetime import datetime

from app.models.schemas import (
    ConfigurationData,
    BotTemplate,
    BotConfig,
    BotAssignment,
    CreateTemplateRequest,
    UpdateTemplateRequest,
    AssignTemplateRequest,
    SuccessResponse,
    ErrorResponse
)

router = APIRouter()

CONFIG_FILE = "bot_config.json"


def get_default_templates() -> List[BotTemplate]:
    """Get default configuration templates"""
    return [
        BotTemplate(
            id="default",
            name="Default",
            description="Standard balanced configuration",
            is_default=True,
            config=BotConfig(
                symbol="XAUUSD",
                lot_size=0.01,
                max_positions=5,
                num_ladders=5,
                ladder_gap_points=50,
                profit_target_points=100,
                trailing_profit_enabled=True,
                trailing_profit_distance=30,
                partial_profit_enabled=True,
                partial_profit_percentage=50,
                max_daily_loss=1000,
                max_drawdown_percent=10
            ),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        ),
        BotTemplate(
            id="conservative",
            name="Conservative",
            description="Lower risk, smaller positions",
            is_default=True,
            config=BotConfig(
                symbol="XAUUSD",
                lot_size=0.01,
                max_positions=3,
                num_ladders=3,
                ladder_gap_points=30,
                profit_target_points=80,
                trailing_profit_enabled=False,
                trailing_profit_distance=20,
                partial_profit_enabled=True,
                partial_profit_percentage=50,
                max_daily_loss=500,
                max_drawdown_percent=5
            ),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        ),
        BotTemplate(
            id="aggressive",
            name="Aggressive",
            description="Higher risk, larger positions",
            is_default=True,
            config=BotConfig(
                symbol="XAUUSD",
                lot_size=0.02,
                max_positions=8,
                num_ladders=8,
                ladder_gap_points=100,
                profit_target_points=150,
                trailing_profit_enabled=True,
                trailing_profit_distance=50,
                partial_profit_enabled=False,
                partial_profit_percentage=50,
                max_daily_loss=2000,
                max_drawdown_percent=15
            ),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
    ]


def load_config() -> ConfigurationData:
    """Load configuration from file"""
    if not os.path.exists(CONFIG_FILE):
        # Return default configuration
        return ConfigurationData(
            templates=get_default_templates(),
            assignments=BotAssignment()
        )
    
    try:
        with open(CONFIG_FILE, 'r') as f:
            data = json.load(f)
            return ConfigurationData(**data)
    except Exception as e:
        print(f"Error loading config: {e}")
        return ConfigurationData(
            templates=get_default_templates(),
            assignments=BotAssignment()
        )


def save_config(config: ConfigurationData) -> None:
    """Save configuration to file"""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config.model_dump(), f, indent=2, default=str)


@router.get("/", response_model=ConfigurationData)
async def get_config() -> ConfigurationData:
    """Get current bot configuration"""
    return load_config()


@router.put("/", response_model=SuccessResponse)
async def update_config(config: ConfigurationData) -> SuccessResponse:
    """Update bot configuration"""
    try:
        save_config(config)
        return SuccessResponse(
            success=True,
            message="Configuration updated successfully",
            data={"config": config.model_dump()}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save config: {str(e)}")


@router.get("/templates", response_model=List[BotTemplate])
async def get_templates() -> List[BotTemplate]:
    """Get all configuration templates"""
    config = load_config()
    return config.templates


@router.get("/templates/{template_id}", response_model=BotTemplate)
async def get_template(template_id: str) -> BotTemplate:
    """Get a specific template by ID"""
    config = load_config()
    template = next((t for t in config.templates if t.id == template_id), None)
    
    if not template:
        raise HTTPException(status_code=404, detail=f"Template '{template_id}' not found")
    
    return template


@router.post("/templates", response_model=BotTemplate)
async def create_template(request: CreateTemplateRequest) -> BotTemplate:
    """Create a new configuration template"""
    config = load_config()
    
    # Generate unique ID
    template_id = f"custom_{int(datetime.utcnow().timestamp() * 1000)}"
    
    # Check if name already exists
    if any(t.name == request.name for t in config.templates):
        raise HTTPException(status_code=400, detail=f"Template with name '{request.name}' already exists")
    
    # Create new template
    new_template = BotTemplate(
        id=template_id,
        name=request.name,
        description=request.description,
        config=request.config,
        is_default=False,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow()
    )
    
    config.templates.append(new_template)
    save_config(config)
    
    return new_template


@router.put("/templates/{template_id}", response_model=BotTemplate)
async def update_template(template_id: str, request: UpdateTemplateRequest) -> BotTemplate:
    """Update an existing template"""
    config = load_config()
    
    # Find template
    template = next((t for t in config.templates if t.id == template_id), None)
    if not template:
        raise HTTPException(status_code=404, detail=f"Template '{template_id}' not found")
    
    # Don't allow updating default template names
    if template.is_default and request.name and request.name != template.name:
        raise HTTPException(status_code=400, detail="Cannot rename default templates")
    
    # Update fields
    if request.name:
        template.name = request.name
    if request.description is not None:
        template.description = request.description
    if request.config:
        template.config = request.config
    
    template.updated_at = datetime.utcnow()
    
    save_config(config)
    return template


@router.delete("/templates/{template_id}", response_model=SuccessResponse)
async def delete_template(template_id: str) -> SuccessResponse:
    """Delete a custom template"""
    config = load_config()
    
    # Find template
    template = next((t for t in config.templates if t.id == template_id), None)
    if not template:
        raise HTTPException(status_code=404, detail=f"Template '{template_id}' not found")
    
    # Don't allow deleting default templates
    if template.is_default:
        raise HTTPException(status_code=400, detail="Cannot delete default templates")
    
    # Check if template is assigned to any bot
    if config.assignments.buy_bot_template == template_id:
        raise HTTPException(status_code=400, detail="Cannot delete template assigned to BUY bot")
    if config.assignments.sell_bot_template == template_id:
        raise HTTPException(status_code=400, detail="Cannot delete template assigned to SELL bot")
    
    # Remove template
    config.templates = [t for t in config.templates if t.id != template_id]
    save_config(config)
    
    return SuccessResponse(
        success=True,
        message=f"Template '{template.name}' deleted successfully"
    )


@router.post("/templates/{template_id}/copy", response_model=BotTemplate)
async def copy_template(template_id: str) -> BotTemplate:
    """Create a copy of an existing template"""
    config = load_config()
    
    # Find source template
    source_template = next((t for t in config.templates if t.id == template_id), None)
    if not source_template:
        raise HTTPException(status_code=404, detail=f"Template '{template_id}' not found")
    
    # Generate unique ID and name
    new_id = f"custom_{int(datetime.utcnow().timestamp() * 1000)}"
    new_name = f"{source_template.name} (Copy)"
    
    # Ensure unique name
    counter = 1
    while any(t.name == new_name for t in config.templates):
        new_name = f"{source_template.name} (Copy {counter})"
        counter += 1
    
    # Create copy
    new_template = BotTemplate(
        id=new_id,
        name=new_name,
        description=f"Copy of {source_template.name}",
        config=source_template.config.model_copy(deep=True),
        is_default=False,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow()
    )
    
    config.templates.append(new_template)
    save_config(config)
    
    return new_template


@router.get("/assignments", response_model=BotAssignment)
async def get_assignments() -> BotAssignment:
    """Get current bot-to-template assignments"""
    config = load_config()
    return config.assignments


@router.post("/assignments", response_model=SuccessResponse)
async def assign_template(request: AssignTemplateRequest) -> SuccessResponse:
    """Assign a template to a bot"""
    config = load_config()
    
    # Validate template exists
    template = next((t for t in config.templates if t.id == request.template_id), None)
    if not template:
        raise HTTPException(status_code=404, detail=f"Template '{request.template_id}' not found")
    
    # Validate bot_id
    if request.bot_id not in ["buy", "sell"]:
        raise HTTPException(status_code=400, detail="bot_id must be 'buy' or 'sell'")
    
    # Update assignment
    if request.bot_id == "buy":
        config.assignments.buy_bot_template = request.template_id
    else:
        config.assignments.sell_bot_template = request.template_id
    
    save_config(config)
    
    return SuccessResponse(
        success=True,
        message=f"Template '{template.name}' assigned to {request.bot_id.upper()} bot",
        data={
            "bot_id": request.bot_id,
            "template_id": request.template_id,
            "template_name": template.name
        }
    )


@router.post("/reset", response_model=SuccessResponse)
async def reset_config() -> SuccessResponse:
    """Reset configuration to defaults"""
    default_config = ConfigurationData(
        templates=get_default_templates(),
        assignments=BotAssignment()
    )
    
    try:
        save_config(default_config)
        return SuccessResponse(
            success=True,
            message="Configuration reset to defaults",
            data={"config": default_config.model_dump()}
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to reset config: {str(e)}")


# Made with Bob
