#!/usr/bin/env python3
"""Script to analyze the algo report history Excel file"""

try:
    from openpyxl import load_workbook
    
    # Load the workbook
    wb = load_workbook('/Users/anandgotluri/Desktop/algo/ReportHistory-183982817.xlsx')
    ws = wb.active
    
    print(f"Sheet name: {ws.title}")
    print(f"Dimensions: {ws.dimensions}")
    print(f"Max row: {ws.max_row}, Max column: {ws.max_column}")
    print("\n" + "="*100)
    print("EXCEL DATA ANALYSIS")
    print("="*100 + "\n")
    
    # Read all rows
    all_rows = list(ws.iter_rows(values_only=True))
    
    # Print header
    if all_rows:
        print("HEADERS:")
        print(all_rows[0])
        print("\n" + "-"*100 + "\n")
    
    # Print first 30 rows
    print("FIRST 30 ROWS OF DATA:")
    for i, row in enumerate(all_rows[:30], 1):
        print(f"Row {i}: {row}")
    
    print("\n" + "-"*100 + "\n")
    
    # Print last 10 rows
    print("LAST 10 ROWS OF DATA:")
    for i, row in enumerate(all_rows[-10:], len(all_rows)-9):
        print(f"Row {i}: {row}")
    
    print("\n" + "="*100 + "\n")
    print(f"TOTAL ROWS: {len(all_rows)}")
    
except ImportError:
    print("openpyxl not available, trying alternative method...")
    import subprocess
    import sys
    
    # Try to install pandas and openpyxl
    print("Attempting to use csv conversion...")
    result = subprocess.run(['file', '/Users/anandgotluri/Desktop/algo/ReportHistory-183982817.xlsx'], 
                          capture_output=True, text=True)
    print(f"File type: {result.stdout}")

except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()

# Made with Bob
