#!/usr/bin/env python3
"""
Check what Gemini AI knows about current XAU/USD market
"""

import sys
from datetime import datetime

try:
    from google import genai
except ImportError:
    print("❌ google-genai not installed. Run: pip install google-genai")
    sys.exit(1)

GEMINI_API_KEY = "AQ.Ab8RN6L0AQS87ZzRnJ6ZSGwt12TCSE-8b7eRYgtdJahtCOGOyg"
GEMINI_MODEL = "gemini-3.1-flash-lite"

now = datetime.now()
current_date = now.strftime("%Y-%m-%d")
current_time = now.strftime("%H:%M:%S")

print("\n" + "="*80)
print("🔍 CHECKING GEMINI'S KNOWLEDGE OF XAU/USD MARKET")
print("="*80)
print(f"📅 Date: {current_date}")
print(f"⏰ Time: {current_time} IST")
print("="*80)

prompt = f"""
Today is {current_date} and the time is {current_time} IST.

Please tell me:
1. What is the current XAU/USD (Gold) price?
2. What major economic events are happening today that affect gold?
3. What is the current market trend for gold?
4. Should I buy or sell gold right now?

Be specific with actual numbers and events if you know them.
"""

print("\n📤 Asking Gemini about current XAU/USD market...")

try:
    client = genai.Client(api_key=GEMINI_API_KEY)
    response = client.models.generate_content(
        model=GEMINI_MODEL,
        contents=prompt
    )
    
    if response and response.text:
        print("\n" + "="*80)
        print("📥 GEMINI'S RESPONSE:")
        print("="*80)
        print(response.text)
        print("="*80)
    else:
        print("❌ No response received")
        
except Exception as e:
    print(f"❌ Error: {e}")
    sys.exit(1)

# Made with Bob
