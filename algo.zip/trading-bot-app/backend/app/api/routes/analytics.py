"""
Analytics API routes
"""

from fastapi import APIRouter, HTTPException
from typing import Dict, List
from datetime import datetime, timedelta
from app.core.mt5_connector import mt5_connector

router = APIRouter()


@router.get("/account")
async def get_account_info() -> Dict:
    """Get account information"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    return mt5_connector.get_account_info()


@router.get("/symbol")
async def get_symbol_info() -> Dict:
    """Get symbol information"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    return mt5_connector.get_symbol_info()


@router.get("/performance")
async def get_performance_metrics(days: int = 7) -> Dict:
    """Get performance metrics"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    history = mt5_connector.get_history(days)
    
    if not history:
        return {
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "win_rate": 0,
            "total_profit": 0,
            "average_profit": 0,
            "average_loss": 0,
            "profit_factor": 0,
            "largest_win": 0,
            "largest_loss": 0
        }
    
    # Calculate metrics
    total_trades = len(history)
    winning_trades = [t for t in history if t["profit"] > 0]
    losing_trades = [t for t in history if t["profit"] < 0]
    
    total_profit = sum(t["profit"] for t in history)
    gross_profit = sum(t["profit"] for t in winning_trades)
    gross_loss = abs(sum(t["profit"] for t in losing_trades))
    
    win_rate = (len(winning_trades) / total_trades * 100) if total_trades > 0 else 0
    avg_profit = gross_profit / len(winning_trades) if winning_trades else 0
    avg_loss = gross_loss / len(losing_trades) if losing_trades else 0
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0
    
    largest_win = max((t["profit"] for t in winning_trades), default=0)
    largest_loss = min((t["profit"] for t in losing_trades), default=0)
    
    return {
        "total_trades": total_trades,
        "winning_trades": len(winning_trades),
        "losing_trades": len(losing_trades),
        "win_rate": round(win_rate, 2),
        "total_profit": round(total_profit, 2),
        "gross_profit": round(gross_profit, 2),
        "gross_loss": round(gross_loss, 2),
        "average_profit": round(avg_profit, 2),
        "average_loss": round(avg_loss, 2),
        "profit_factor": round(profit_factor, 2),
        "largest_win": round(largest_win, 2),
        "largest_loss": round(largest_loss, 2)
    }


@router.get("/equity-curve")
async def get_equity_curve(days: int = 7) -> List[Dict]:
    """Get equity curve data"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    history = mt5_connector.get_history(days)
    account = mt5_connector.get_account_info()
    
    if not history:
        return []
    
    # Sort by time
    history.sort(key=lambda x: x["time"])
    
    # Calculate cumulative profit
    current_balance = account.get("balance", 0)
    equity_curve = []
    cumulative_profit = 0
    
    for trade in history:
        cumulative_profit += trade["profit"]
        equity_curve.append({
            "time": trade["time"],
            "equity": round(current_balance - cumulative_profit + trade["profit"], 2),
            "profit": round(trade["profit"], 2),
            "cumulative_profit": round(cumulative_profit, 2)
        })
    
    return equity_curve


@router.get("/daily-pnl")
async def get_daily_pnl(days: int = 30) -> List[Dict]:
    """Get daily P&L breakdown"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    history = mt5_connector.get_history(days)
    
    if not history:
        return []
    
    # Group by date
    daily_pnl = {}
    for trade in history:
        date = trade["time"].split("T")[0]  # Extract date part
        if date not in daily_pnl:
            daily_pnl[date] = {
                "date": date,
                "profit": 0,
                "trades": 0,
                "winning_trades": 0,
                "losing_trades": 0
            }
        
        daily_pnl[date]["profit"] += trade["profit"]
        daily_pnl[date]["trades"] += 1
        
        if trade["profit"] > 0:
            daily_pnl[date]["winning_trades"] += 1
        elif trade["profit"] < 0:
            daily_pnl[date]["losing_trades"] += 1
    
    # Convert to list and sort
    result = list(daily_pnl.values())
    result.sort(key=lambda x: x["date"])
    
    # Round profits
    for day in result:
        day["profit"] = round(day["profit"], 2)
    
    return result


@router.get("/history")
async def get_trade_history(days: int = 30, limit: int = 100) -> Dict:
    """Get complete trade history"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    history = mt5_connector.get_history(days)
    
    if not history:
        return {
            "total": 0,
            "trades": []
        }
    
    # Sort by time (newest first)
    history.sort(key=lambda x: x["time"], reverse=True)
    
    # Apply limit
    limited_history = history[:limit] if limit > 0 else history
    
    return {
        "total": len(history),
        "showing": len(limited_history),
        "trades": limited_history
    }


@router.get("/pending-orders")
async def get_pending_orders() -> Dict:
    """Get all pending orders"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    orders = mt5_connector.get_pending_orders()
    
    return {
        "total": len(orders),
        "orders": orders
    }


@router.get("/statistics")
async def get_statistics(days: int = 30) -> Dict:
    """Get comprehensive trading statistics"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    history = mt5_connector.get_history(days)
    account = mt5_connector.get_account_info()
    
    if not history:
        return {
            "total_trades": 0,
            "winning_trades": 0,
            "losing_trades": 0,
            "win_rate": 0,
            "total_profit": 0,
            "total_loss": 0,
            "net_profit": 0,
            "average_win": 0,
            "average_loss": 0,
            "profit_factor": 0,
            "max_drawdown": 0,
            "largest_win": 0,
            "largest_loss": 0,
            "average_trade_duration": 0,
            "total_volume": 0
        }
    
    # Calculate comprehensive statistics
    total_trades = len(history)
    winning_trades = [t for t in history if t["profit"] > 0]
    losing_trades = [t for t in history if t["profit"] < 0]
    
    total_profit = sum(t["profit"] for t in winning_trades)
    total_loss = abs(sum(t["profit"] for t in losing_trades))
    net_profit = sum(t["profit"] for t in history)
    
    win_rate = (len(winning_trades) / total_trades * 100) if total_trades > 0 else 0
    avg_win = total_profit / len(winning_trades) if winning_trades else 0
    avg_loss = total_loss / len(losing_trades) if losing_trades else 0
    profit_factor = total_profit / total_loss if total_loss > 0 else 0
    
    largest_win = max((t["profit"] for t in winning_trades), default=0)
    largest_loss = min((t["profit"] for t in losing_trades), default=0)
    
    total_volume = sum(t.get("volume", 0) for t in history)
    
    return {
        "total_trades": total_trades,
        "winning_trades": len(winning_trades),
        "losing_trades": len(losing_trades),
        "win_rate": round(win_rate, 2),
        "total_profit": round(total_profit, 2),
        "total_loss": round(total_loss, 2),
        "net_profit": round(net_profit, 2),
        "average_win": round(avg_win, 2),
        "average_loss": round(avg_loss, 2),
        "profit_factor": round(profit_factor, 2),
        "max_drawdown": 0,  # TODO: Calculate actual drawdown
        "largest_win": round(largest_win, 2),
        "largest_loss": round(largest_loss, 2),
        "average_trade_duration": 0,  # TODO: Calculate duration
        "total_volume": round(total_volume, 2),
        "account_balance": account.get("balance", 0),
        "account_equity": account.get("equity", 0)
    }


# Made with Bob
