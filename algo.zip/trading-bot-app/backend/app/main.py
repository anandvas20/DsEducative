"""
Trading Bot Management API
FastAPI backend for managing XAU/USD trading bots
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import socketio
import uvicorn

from app.api.routes import bots, positions, analytics, config, gemini
from app.core.config import settings
from app.core.gemini_service import get_gemini_service

# Create FastAPI app
app = FastAPI(
    title="Trading Bot Management API",
    description="API for managing XAU/USD trading bots with real-time updates and AI-powered signals",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:4200"],  # Angular dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Socket.IO server for real-time updates
sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins=['http://localhost:4200']
)
socket_app = socketio.ASGIApp(sio, app)

# Include routers
app.include_router(bots.router, prefix="/api/bots", tags=["Bots"])
app.include_router(positions.router, prefix="/api/positions", tags=["Positions"])
app.include_router(analytics.router, prefix="/api/analytics", tags=["Analytics"])
app.include_router(config.router, prefix="/api/config", tags=["Configuration"])
app.include_router(gemini.router, prefix="/api/gemini", tags=["Gemini AI"])

@app.on_event("startup")
async def startup_event():
    """Initialize services on startup"""
    # Initialize Gemini AI service
    gemini_svc = get_gemini_service()
    if gemini_svc and gemini_svc.enabled:
        print("✓ Gemini AI service initialized")
    else:
        print("⚠ Gemini AI service not available (API key not configured)")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    # Stop Gemini background updater
    gemini_svc = get_gemini_service()
    if gemini_svc:
        gemini_svc.stop_background_updater()
        print("✓ Gemini AI background updater stopped")

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Trading Bot Management API",
        "version": "1.0.0",
        "docs": "/docs",
        "features": [
            "Real-time bot management",
            "Position tracking",
            "Analytics dashboard",
            "AI-powered trading signals (Gemini)",
            "WebSocket updates"
        ]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    gemini_svc = get_gemini_service()
    gemini_status = "enabled" if gemini_svc and gemini_svc.enabled else "disabled"
    
    return {
        "status": "healthy",
        "services": {
            "api": "running",
            "websocket": "running",
            "gemini_ai": gemini_status
        }
    }

# Socket.IO events
@sio.event
async def connect(sid, environ):
    """Handle client connection"""
    print(f"Client connected: {sid}")
    await sio.emit('connection_response', {'status': 'connected'}, room=sid)

@sio.event
async def disconnect(sid):
    """Handle client disconnection"""
    print(f"Client disconnected: {sid}")

@sio.event
async def subscribe_positions(sid, data):
    """Subscribe to position updates"""
    await sio.enter_room(sid, 'positions')
    print(f"Client {sid} subscribed to positions")

@sio.event
async def subscribe_logs(sid, data):
    """Subscribe to log updates"""
    await sio.enter_room(sid, 'logs')
    print(f"Client {sid} subscribed to logs")

@sio.event
async def subscribe_pnl(sid, data):
    """Subscribe to P&L updates"""
    await sio.enter_room(sid, 'pnl')
    print(f"Client {sid} subscribed to P&L")

if __name__ == "__main__":
    uvicorn.run(
        "app.main:socket_app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )

# Made with Bob
