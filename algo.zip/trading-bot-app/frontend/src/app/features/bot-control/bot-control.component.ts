import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService, BotStatus } from '../../core/services/api.service';

@Component({
  selector: 'app-bot-control',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './bot-control.component.html',
  styleUrls: ['./bot-control.component.scss']
})
export class BotControlComponent implements OnInit {
  botStatus: BotStatus | null = null;
  loading = false;
  message: string | null = null;
  messageType: 'success' | 'error' | null = null;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadBotStatus();
  }

  loadBotStatus(): void {
    this.loading = true;
    this.apiService.getBotStatus().subscribe({
      next: (data) => {
        this.botStatus = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error loading bot status:', err);
        this.showMessage('Failed to load bot status', 'error');
        this.loading = false;
      }
    });
  }

  startBuyBot(): void {
    this.loading = true;
    this.apiService.startBuyBot().subscribe({
      next: (response) => {
        this.showMessage(response.message, 'success');
        this.loadBotStatus();
      },
      error: (err) => {
        this.showMessage(err.error?.detail || 'Failed to start BUY bot', 'error');
        this.loading = false;
      }
    });
  }

  stopBuyBot(): void {
    this.loading = true;
    this.apiService.stopBuyBot().subscribe({
      next: (response) => {
        this.showMessage(response.message, 'success');
        this.loadBotStatus();
      },
      error: (err) => {
        this.showMessage(err.error?.detail || 'Failed to stop BUY bot', 'error');
        this.loading = false;
      }
    });
  }

  restartBuyBot(): void {
    this.loading = true;
    this.apiService.restartBuyBot().subscribe({
      next: (response) => {
        this.showMessage(response.message, 'success');
        this.loadBotStatus();
      },
      error: (err) => {
        this.showMessage(err.error?.detail || 'Failed to restart BUY bot', 'error');
        this.loading = false;
      }
    });
  }

  startSellBot(): void {
    this.loading = true;
    this.apiService.startSellBot().subscribe({
      next: (response) => {
        this.showMessage(response.message, 'success');
        this.loadBotStatus();
      },
      error: (err) => {
        this.showMessage(err.error?.detail || 'Failed to start SELL bot', 'error');
        this.loading = false;
      }
    });
  }

  stopSellBot(): void {
    this.loading = true;
    this.apiService.stopSellBot().subscribe({
      next: (response) => {
        this.showMessage(response.message, 'success');
        this.loadBotStatus();
      },
      error: (err) => {
        this.showMessage(err.error?.detail || 'Failed to stop SELL bot', 'error');
        this.loading = false;
      }
    });
  }

  restartSellBot(): void {
    this.loading = true;
    this.apiService.restartSellBot().subscribe({
      next: (response) => {
        this.showMessage(response.message, 'success');
        this.loadBotStatus();
      },
      error: (err) => {
        this.showMessage(err.error?.detail || 'Failed to restart SELL bot', 'error');
        this.loading = false;
      }
    });
  }

  stopAllBots(): void {
    if (!confirm('Are you sure you want to stop all bots?')) {
      return;
    }

    this.loading = true;
    this.apiService.stopAllBots().subscribe({
      next: (response) => {
        this.showMessage('All bots stopped successfully', 'success');
        this.loadBotStatus();
      },
      error: (err) => {
        this.showMessage('Failed to stop all bots', 'error');
        this.loading = false;
      }
    });
  }

  private showMessage(message: string, type: 'success' | 'error'): void {
    this.message = message;
    this.messageType = type;
    setTimeout(() => {
      this.message = null;
      this.messageType = null;
    }, 5000);
  }

  getBotStatusClass(running: boolean): string {
    return running ? 'running' : 'stopped';
  }

  getBotStatusText(running: boolean): string {
    return running ? 'Running' : 'Stopped';
  }
}

// Made with Bob
