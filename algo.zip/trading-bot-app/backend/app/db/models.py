"""
SQLAlchemy database models for trading bot (MySQL)
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, Text, JSON
from sqlalchemy.sql import func
from datetime import datetime

from .database import Base


class Trade(Base):
    """Trade history model"""
    __tablename__ = "trades"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    ticket = Column(Integer, unique=True, index=True, nullable=False)
    order_id = Column(Integer, index=True)
    symbol = Column(String(20), index=True, nullable=False)
    trade_type = Column(String(10), nullable=False)  # BUY or SELL
    volume = Column(Float, nullable=False)
    open_price = Column(Float, nullable=False)
    close_price = Column(Float)
    profit = Column(Float)
    swap = Column(Float, default=0.0)
    commission = Column(Float, default=0.0)
    magic_number = Column(Integer, index=True)
    comment = Column(String(255))
    open_time = Column(DateTime, nullable=False)
    close_time = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<Trade(ticket={self.ticket}, symbol={self.symbol}, type={self.trade_type}, profit={self.profit})>"


class BotConfiguration(Base):
    """Bot configuration history model"""
    __tablename__ = "bot_configurations"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    bot_id = Column(String(50), index=True, nullable=False)  # 'buy' or 'sell'
    template_id = Column(String(100), index=True)
    template_name = Column(String(100))
    config_data = Column(JSON, nullable=False)  # Store full configuration as JSON
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<BotConfiguration(bot_id={self.bot_id}, template={self.template_name}, active={self.is_active})>"


class PerformanceMetric(Base):
    """Daily performance metrics model"""
    __tablename__ = "performance_metrics"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    date = Column(DateTime, index=True, nullable=False, unique=True)
    bot_id = Column(String(50), index=True)  # 'buy', 'sell', or 'all'
    
    # Trade statistics
    total_trades = Column(Integer, default=0)
    winning_trades = Column(Integer, default=0)
    losing_trades = Column(Integer, default=0)
    win_rate = Column(Float, default=0.0)
    
    # Profit/Loss
    gross_profit = Column(Float, default=0.0)
    gross_loss = Column(Float, default=0.0)
    net_profit = Column(Float, default=0.0)
    
    # Averages
    average_win = Column(Float, default=0.0)
    average_loss = Column(Float, default=0.0)
    profit_factor = Column(Float, default=0.0)
    
    # Volume
    total_volume = Column(Float, default=0.0)
    
    # Account
    starting_balance = Column(Float)
    ending_balance = Column(Float)
    max_drawdown = Column(Float, default=0.0)
    
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<PerformanceMetric(date={self.date}, bot={self.bot_id}, net_profit={self.net_profit})>"


class BotStatus(Base):
    """Bot status log model"""
    __tablename__ = "bot_status_log"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    bot_id = Column(String(50), index=True, nullable=False)
    status = Column(String(20), nullable=False)  # running, stopped, error
    template_id = Column(String(100))
    uptime_seconds = Column(Integer)
    active_positions = Column(Integer, default=0)
    last_trade_time = Column(DateTime)
    error_message = Column(Text)
    created_at = Column(DateTime, server_default=func.now())

    def __repr__(self):
        return f"<BotStatus(bot_id={self.bot_id}, status={self.status}, time={self.created_at})>"


class SystemLog(Base):
    """System event log model"""
    __tablename__ = "system_logs"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    level = Column(String(20), index=True, nullable=False)  # INFO, WARNING, ERROR, CRITICAL
    source = Column(String(100), index=True)  # bot_manager, mt5_connector, api, etc.
    message = Column(Text, nullable=False)
    details = Column(JSON)  # Additional structured data
    created_at = Column(DateTime, server_default=func.now(), index=True)

    def __repr__(self):
        return f"<SystemLog(level={self.level}, source={self.source}, time={self.created_at})>"


# Made with Bob