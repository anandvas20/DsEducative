#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("=" * 60)
print("GOLD SMART GRID BOT - LOADING...")
print("=" * 60)

import os
import sys
import time
import json
import math
import logging
import threading
import traceback
from queue import Queue
from collections import deque
from functools import wraps
from datetime import datetime, timedelta, timezone
from concurrent.futures import ThreadPoolExecutor
from logging.handlers import RotatingFileHandler

print("[IMPORT] Standard libraries loaded successfully")

# Try importing required packages with error handling
try:
    import MetaTrader5 as mt5
    print("[IMPORT] MetaTrader5 loaded successfully")
except ImportError as e:
    print(f"\n[ERROR] Failed to import MetaTrader5: {e}")
    print("[FIX] Install with: pip install MetaTrader5")
    sys.exit(1)

try:
    import numpy as np
    print("[IMPORT] NumPy loaded successfully")
except ImportError as e:
    print(f"\n[ERROR] Failed to import numpy: {e}")
    print("[FIX] Install with: pip install numpy")
    sys.exit(1)

try:
    import pandas as pd
    print("[IMPORT] Pandas loaded successfully")
except ImportError as e:
    print(f"\n[ERROR] Failed to import pandas: {e}")
    print("[FIX] Install with: pip install pandas")
    sys.exit(1)

print("[IMPORT] All required packages loaded successfully\n")

# =========================================================
# ADVANCED LOGGING CONFIGURATION
# =========================================================

class ThrottledLogger:
    """
    Advanced logging system with throttling,
    rotation, and structured logging.
    """

    def __init__(self, name="GoldSmartGridBot"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False

        # Clear existing handlers
        self.logger.handlers.clear()

        # Throttle tracking
        self._throttle_cache = {}
        self._throttle_lock = threading.Lock()

        # Performance metrics
        self._perf_metrics = {}
        self._perf_lock = threading.Lock()

        self._setup_handlers()

    def _setup_handlers(self):
        """Optimized logging setup"""
        simple_formatter = logging.Formatter(
            '%(asctime)s | %(levelname)-8s | %(message)s',
            datefmt='%H:%M:%S'
        )

        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.WARNING)
        console_handler.setFormatter(simple_formatter)
        self.logger.addHandler(console_handler)

        # Main log file
        main_file_handler = RotatingFileHandler(
            'gold_smart_grid.log',
            maxBytes=50 * 1024 * 1024,  # 50MB
            backupCount=2,
            encoding='utf-8'
        )
        main_file_handler.setLevel(logging.INFO)
        main_file_handler.setFormatter(simple_formatter)
        self.logger.addHandler(main_file_handler)

    def throttle(self, key, interval):
        """Check if message should be throttled"""
        with self._throttle_lock:
            now = time.time()
            last_time = self._throttle_cache.get(key, 0)
            if now - last_time < interval:
                return True
            self._throttle_cache[key] = now
            return False

    def debug(self, msg, throttle_key=None, throttle_interval=0):
        if throttle_key and self.throttle(throttle_key, throttle_interval):
            return
        self.logger.debug(msg)

    def info(self, msg, throttle_key=None, throttle_interval=0):
        if throttle_key and self.throttle(throttle_key, throttle_interval):
            return
        self.logger.info(msg)

    def warning(self, msg, throttle_key=None, throttle_interval=0):
        if throttle_key and self.throttle(throttle_key, throttle_interval):
            return
        self.logger.warning(msg)

    def error(self, msg, exc_info=False, throttle_key=None, throttle_interval=0):
        if throttle_key and self.throttle(throttle_key, throttle_interval):
            return
        self.logger.error(msg, exc_info=exc_info)

    def critical(self, msg, exc_info=False):
        self.logger.critical(msg, exc_info=exc_info)

    def trade(self, action, **kwargs):
        details = " | ".join([f"{k}={v}" for k, v in kwargs.items()])
        self.logger.info(f"[TRADE] {action} | {details}")


# Initialize logger
log = ThrottledLogger()

def monitor_performance(func):
    """Decorator to monitor function performance"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            duration = time.time() - start_time
            if duration > 1.0:
                log.warning(
                    f"{func.__name__} took {duration:.2f}s",
                    throttle_key=f"perf_{func.__name__}",
                    throttle_interval=60
                )
            return result
        except Exception as e:
            log.error(
                f"{func.__name__} failed: {e}",
                exc_info=True
            )
            raise
    return wrapper

# ====================================================
# CONFIGURATION
# ====================================================

# Symbol and Magic Number
SYMBOL = "XAUUSD"
MAGIC = 777888

# Timeframes
ENTRY_TF = mt5.TIMEFRAME_M1
TREND_TF = mt5.TIMEFRAME_M15
VOL_TF = mt5.TIMEFRAME_M5
SAFETY_TF = mt5.TIMEFRAME_H1

# EMA Settings
FAST_EMA = 50
SLOW_EMA = 200

# Indicator Settings
RSI_PERIOD = 14
RSI_OVERBOUGHT = 75
ADX_PERIOD = 14
MAX_ADX = 25
ATR_PERIOD = 14
ATR_MULTIPLIER = 0.8

# Position Management
BASE_LOT = 0.01
LOT_MULTIPLIER = 1.4
MAX_POSITIONS = 5

# Risk Management
BASKET_TP_USD = 8.0
MAX_FLOATING_LOSS_USD = -120.0

# MT5 Credentials (load from environment or config)
MT5_LOGIN = None  # Set your login
MT5_PASSWORD = None  # Set your password
MT5_SERVER = None  # Set your server

# Thread safety
positions_lock = threading.Lock()
trade_lock = threading.Lock()

# Cache variables
positions_cache = None
positions_cache_time = 0

# =========================================================
# MT5 LOGIN
# =========================================================

# MT5 Credentials
MT5_PATH = r"C:\Program Files\MetaTrader 5\terminal64.exe"
MT5_LOGIN = 433567390
MT5_PASSWORD = "Trading@123"
MT5_SERVER = "Exness-MT5Trial7"


def load_mt5_credentials():
    """Load MT5 credentials from constants"""
    return MT5_LOGIN, MT5_PASSWORD, MT5_SERVER


@monitor_performance
def init_mt5():
    print(f"\n[INIT] Attempting MT5 connection...")
    print(f"[INIT] Path: {MT5_PATH}")
    print(f"[INIT] Login: {MT5_LOGIN}")
    print(f"[INIT] Server: {MT5_SERVER}")
    
    login, password, server = load_mt5_credentials()

    if not mt5.initialize(
        path=MT5_PATH,
        login=login,
        password=password,
        server=server
    ):
        code, msg = mt5.last_error()
        error_msg = f"MT5 INIT FAILED | Code: {code} | Message: {msg}"
        print(f"\n[ERROR] {error_msg}")
        log.error(error_msg)
        raise RuntimeError(error_msg)

    print(f"[SUCCESS] MT5 initialized successfully")
    log.info("MT5 initialized successfully")
    
    # Print account info
    account_info = mt5.account_info()
    if account_info:
        print(f"[INFO] Account: {account_info.login}")
        print(f"[INFO] Balance: ${account_info.balance:.2f}")
        print(f"[INFO] Equity: ${account_info.equity:.2f}")
        log.info(f"Account {account_info.login} | Balance: ${account_info.balance:.2f}")
    
    # Verify symbol exists
    print(f"\n[VERIFY] Checking symbol: {SYMBOL}")
    symbol_info = mt5.symbol_info(SYMBOL)
    if symbol_info is None:
        print(f"[ERROR] Symbol '{SYMBOL}' not found!")
        print("[INFO] Available GOLD symbols:")
        symbols = mt5.symbols_get()
        gold_symbols = [s.name for s in symbols if 'GOLD' in s.name.upper() or 'XAU' in s.name.upper()]
        for sym in gold_symbols[:10]:  # Show first 10
            print(f"  - {sym}")
        raise RuntimeError(f"Symbol '{SYMBOL}' not available on this broker")
    
    # Enable symbol for trading
    if not symbol_info.visible:
        print(f"[INFO] Enabling symbol {SYMBOL} for trading...")
        if not mt5.symbol_select(SYMBOL, True):
            print(f"[WARNING] Could not enable symbol {SYMBOL}")
    
    print(f"[SUCCESS] Symbol {SYMBOL} verified and ready")
    print(f"[INFO] Bid: {symbol_info.bid:.2f} | Ask: {symbol_info.ask:.2f}")
    print(f"[INFO] Spread: {symbol_info.spread} points\n")

# ====================================================
# POSITION MANAGEMENT
# ====================================================

def get_sell_positions():
    """Get count of SELL positions for this EA"""
    with positions_lock:
        positions = mt5.positions_get(symbol=SYMBOL)
        if positions is None:
            return 0
        
        count = 0
        for pos in positions:
            if pos.magic == MAGIC and pos.type == mt5.ORDER_TYPE_SELL:
                count += 1
        
        return count

def get_basket_profit():
    """Calculate total profit/loss for all positions"""
    with positions_lock:
        positions = mt5.positions_get(symbol=SYMBOL)
        if positions is None:
            return 0.0
        
        total_profit = 0.0
        for pos in positions:
            if pos.magic == MAGIC:
                total_profit += pos.profit
        
        return total_profit

def close_all_positions():
    """Close all positions for this EA"""
    with trade_lock:
        positions = mt5.positions_get(symbol=SYMBOL)
        if positions is None:
            return
        
        for pos in positions:
            if pos.magic == MAGIC:
                tick = mt5.symbol_info_tick(SYMBOL)
                if tick is None:
                    continue
                
                request = {
                    "action": mt5.TRADE_ACTION_DEAL,
                    "symbol": SYMBOL,
                    "volume": pos.volume,
                    "type": mt5.ORDER_TYPE_BUY if pos.type == mt5.ORDER_TYPE_SELL else mt5.ORDER_TYPE_SELL,
                    "position": pos.ticket,
                    "price": tick.ask if pos.type == mt5.ORDER_TYPE_SELL else tick.bid,
                    "magic": MAGIC,
                    "comment": "Close All",
                    "type_time": mt5.ORDER_TIME_GTC,
                    "type_filling": mt5.ORDER_FILLING_IOC,
                }
                
                result = mt5.order_send(request)
                if result.retcode != mt5.TRADE_RETCODE_DONE:
                    log.error(f"Failed to close position {pos.ticket}: {result.comment}")
                else:
                    log.info(f"Closed position {pos.ticket}")

def get_last_sell_price():
    """Get the price of the most recent SELL position"""
    with positions_lock:
        positions = mt5.positions_get(symbol=SYMBOL)
        if positions is None:
            return 0.0
        
        latest_time = 0
        latest_price = 0.0
        
        for pos in positions:
            if pos.magic == MAGIC and pos.type == mt5.ORDER_TYPE_SELL:
                if pos.time > latest_time:
                    latest_time = pos.time
                    latest_price = pos.price_open
        
        return latest_price

# ====================================================
# INDICATOR CALCULATIONS
# ====================================================

def get_ema(timeframe, period):
    """Calculate EMA for given timeframe and period"""
    rates = mt5.copy_rates_from_pos(SYMBOL, timeframe, 0, period + 10)
    if rates is None or len(rates) < period:
        return None
    
    df = pd.DataFrame(rates)
    ema = df['close'].ewm(span=period, adjust=False).mean()
    return ema.iloc[-1]

def get_rsi(timeframe, period):
    """Calculate RSI for given timeframe"""
    rates = mt5.copy_rates_from_pos(SYMBOL, timeframe, 0, period + 10)
    if rates is None or len(rates) < period:
        return None
    
    df = pd.DataFrame(rates)
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi.iloc[-1]

def get_adx(timeframe, period):
    """Calculate ADX for given timeframe"""
    rates = mt5.copy_rates_from_pos(SYMBOL, timeframe, 0, period + 20)
    if rates is None or len(rates) < period:
        return None
    
    df = pd.DataFrame(rates)
    
    # Calculate True Range
    df['h-l'] = df['high'] - df['low']
    df['h-pc'] = abs(df['high'] - df['close'].shift(1))
    df['l-pc'] = abs(df['low'] - df['close'].shift(1))
    df['tr'] = df[['h-l', 'h-pc', 'l-pc']].max(axis=1)
    
    # Calculate Directional Movement
    df['up_move'] = df['high'] - df['high'].shift(1)
    df['down_move'] = df['low'].shift(1) - df['low']
    
    df['plus_dm'] = np.where((df['up_move'] > df['down_move']) & (df['up_move'] > 0), df['up_move'], 0)
    df['minus_dm'] = np.where((df['down_move'] > df['up_move']) & (df['down_move'] > 0), df['down_move'], 0)
    
    # Smooth the values
    atr = df['tr'].rolling(window=period).mean()
    plus_di = 100 * (df['plus_dm'].rolling(window=period).mean() / atr)
    minus_di = 100 * (df['minus_dm'].rolling(window=period).mean() / atr)
    
    # Calculate ADX
    dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
    adx = dx.rolling(window=period).mean()
    
    return adx.iloc[-1]

def get_atr(timeframe, period):
    """Calculate ATR for given timeframe"""
    rates = mt5.copy_rates_from_pos(SYMBOL, timeframe, 0, period + 10)
    if rates is None or len(rates) < period:
        return None
    
    df = pd.DataFrame(rates)
    df['h-l'] = df['high'] - df['low']
    df['h-pc'] = abs(df['high'] - df['close'].shift(1))
    df['l-pc'] = abs(df['low'] - df['close'].shift(1))
    df['tr'] = df[['h-l', 'h-pc', 'l-pc']].max(axis=1)
    
    atr = df['tr'].rolling(window=period).mean()
    return atr.iloc[-1]

# ====================================================
# FILTERS
# ====================================================

def trend_filter():
    """Check if M15 trend is bearish (EMA50 < EMA200)"""
    fast = get_ema(TREND_TF, FAST_EMA)
    slow = get_ema(TREND_TF, SLOW_EMA)
    
    if fast is None or slow is None:
        return False
    
    return fast < slow

def rsi_filter():
    """Check if RSI is overbought on M1"""
    rsi = get_rsi(ENTRY_TF, RSI_PERIOD)
    
    if rsi is None:
        return False
    
    return rsi >= RSI_OVERBOUGHT

def adx_filter():
    """Check if ADX is low (low volatility) on M5"""
    adx = get_adx(VOL_TF, ADX_PERIOD)
    
    if adx is None:
        return False
    
    return adx <= MAX_ADX

def safety_filter():
    """Check if H1 trend is bearish (additional safety)"""
    fast = get_ema(SAFETY_TF, 50)
    slow = get_ema(SAFETY_TF, 200)
    
    if fast is None or slow is None:
        return False
    
    return fast < slow

def session_allowed():
    """Check if current time is in allowed trading session"""
    now = datetime.now()
    hour = now.hour
    
    # Asian + Early London (0:00 - 10:00 UTC)
    return 0 <= hour <= 10

# ====================================================
# TRADING LOGIC
# ====================================================

def calculate_next_lot(level):
    """Calculate lot size for given grid level"""
    lot = BASE_LOT
    for i in range(1, level):
        lot *= LOT_MULTIPLIER
    
    return round(lot, 2)

def get_dynamic_grid_distance():
    """Calculate dynamic grid distance based on ATR"""
    atr = get_atr(VOL_TF, ATR_PERIOD)
    
    if atr is None:
        return 0.5  # Default fallback
    
    return atr * ATR_MULTIPLIER

def open_sell(level):
    """Open a SELL position"""
    lot = calculate_next_lot(level)
    
    tick = mt5.symbol_info_tick(SYMBOL)
    if tick is None:
        log.error("Failed to get tick data")
        return False
    
    with trade_lock:
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": SYMBOL,
            "volume": lot,
            "type": mt5.ORDER_TYPE_SELL,
            "price": tick.bid,
            "magic": MAGIC,
            "comment": f"Grid Level {level}",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        result = mt5.order_send(request)
        
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            log.error(f"Failed to open SELL: {result.comment}")
            return False
        
        log.info(f"Opened SELL position: Lot={lot}, Level={level}, Price={tick.bid}")
        return True

def check_entries():
    """Check and execute entry logic"""
    if not session_allowed():
        return
    
    sells = get_sell_positions()
    
    tick = mt5.symbol_info_tick(SYMBOL)
    if tick is None:
        return
    
    # FIRST ENTRY
    if sells == 0:
        if (trend_filter() and 
            rsi_filter() and 
            adx_filter() and 
            safety_filter()):
            
            log.info("All filters passed - Opening first SELL")
            open_sell(1)
        return
    
    # GRID ENTRY
    if sells < MAX_POSITIONS:
        last_price = get_last_sell_price()
        if last_price == 0:
            return
        
        distance = get_dynamic_grid_distance()
        
        # Price moved up enough for next grid level
        if tick.ask >= last_price + distance:
            log.info(f"Grid trigger: Ask={tick.ask}, Last={last_price}, Distance={distance}")
            open_sell(sells + 1)

def manage_basket():
    """Manage basket profit/loss"""
    profit = get_basket_profit()
    
    # Take profit
    if profit >= BASKET_TP_USD:
        log.info(f"Basket TP reached: ${profit:.2f}")
        close_all_positions()
        return
    
    # Emergency stop loss
    if profit <= MAX_FLOATING_LOSS_USD:
        log.warning(f"Emergency DD Stop: ${profit:.2f}")
        close_all_positions()
        return

# ====================================================
# MAIN LOOP
# ====================================================

def bot_loop():
    """Main bot loop"""
    log.info("=" * 60)
    log.info("SMART GRID EA STARTED")
    log.info(f"Symbol: {SYMBOL}")
    log.info(f"Magic: {MAGIC}")
    log.info(f"Base Lot: {BASE_LOT}")
    log.info(f"Max Positions: {MAX_POSITIONS}")
    log.info(f"Basket TP: ${BASKET_TP_USD}")
    log.info(f"Max Loss: ${MAX_FLOATING_LOSS_USD}")
    log.info("=" * 60)
    
    loop_count = 0
    
    while True:
        try:
            loop_count += 1
            
            # Check MT5 connection
            if not mt5.terminal_info():
                log.error("MT5 connection lost, attempting reconnect...")
                if not init_mt5():
                    time_module.sleep(5)
                    continue
            
            # Manage existing positions
            manage_basket()
            
            # Check for new entries
            check_entries()
            
            # Log status every 100 loops
            if loop_count % 100 == 0:
                positions = get_sell_positions()
                profit = get_basket_profit()
                log.info(f"Status: Positions={positions}, P/L=${profit:.2f}")
            
            # Sleep to avoid excessive CPU usage
            time_module.sleep(1)
            
        except KeyboardInterrupt:
            log.info("Bot stopped by user")
            break
        except Exception as e:
            log.error(f"Error in main loop: {e}", exc_info=True)
            time_module.sleep(5)
    
    # Cleanup
    mt5.shutdown()
    log.info("Bot shutdown complete")

# ====================================================
# ENTRY POINT
# ====================================================

if __name__ == "__main__":
    if not init_mt5():
        log.error("Failed to initialize MT5")
        sys.exit(1)
    
    try:
        bot_loop()
    except Exception as e:
        log.critical(f"Fatal error: {e}", exc_info=True)
        mt5.shutdown()
        sys.exit(1)

# Made with Bob
