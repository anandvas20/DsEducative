# Gemini AI Enhancement for Entry Decisions

**Focus**: Improve how Gemini AI helps make better entry decisions

---

## 🎯 Current Problem

**What AI Currently Does**:
- Gets basic market data (price, RSI, MACD, EMAs)
- Returns simple BUY/SELL/HOLD signal
- Only blocks entry if confidence > 70% and signal is HOLD/SELL

**Why This is Limited**:
- AI doesn't know about current news/events
- Doesn't consider market session (Asian/European/US)
- Doesn't assess entry quality (good vs bad timing)
- Doesn't warn about specific risks
- Doesn't suggest optimal entry price

---

## ✅ Enhanced Entry Decision Prompt

### Replace Current Prompt With This:

```python
def update_gemini_cache_background(market_data):
    # ... existing code ...
    
    # Get current date/time for context
    from datetime import datetime
    now_dt = datetime.now()
    current_date = now_dt.strftime("%Y-%m-%d")
    current_time = now_dt.strftime("%H:%M")
    day_of_week = now_dt.strftime("%A")
    hour = now_dt.hour
    
    # Determine trading session
    if 2 <= hour < 8:
        session = "Asian (Low liquidity, range-bound)"
    elif 8 <= hour < 13:
        session = "European (Moderate liquidity, trend development)"
    elif 13 <= hour < 21:
        session = "US (High liquidity, major moves)"
    else:
        session = "After-hours (Very low liquidity, avoid)"
    
    # Enhanced prompt
    prompt = f"""
You are a professional XAU/USD (Gold) trading expert with 20 years of experience.

CURRENT CONTEXT:
- Date: {current_date} ({day_of_week})
- Time: {current_time} IST
- Session: {session}

MARKET DATA:
{json.dumps(market_data, indent=2)}

YOUR TASK: Analyze if NOW is a good time to enter a BUY position.

Consider:
1. **News & Events**: Are there major economic events today that could cause volatility?
   - US CPI, NFP, FOMC, Fed speeches, etc.
   - Geopolitical events affecting gold
   - If major news is within 2 hours, recommend WAIT

2. **Market Session**: 
   - Asian session: Usually range-bound, avoid breakout trades
   - European session: Good for trend following
   - US session: High volatility, good for breakouts
   - After-hours: Avoid due to low liquidity

3. **Technical Setup Quality**:
   - Is price at a good level (support/resistance)?
   - Are indicators aligned or conflicting?
   - Is there a clear trend or choppy market?
   - Any chart patterns forming?

4. **Risk Factors**:
   - Is spread likely to widen soon?
   - Is volatility too high/low?
   - Any stop-loss hunting zones nearby?

5. **Entry Timing**:
   - Should enter immediately?
   - Wait for pullback to better price?
   - Wait for breakout confirmation?
   - Avoid entry today?

Return ONLY this JSON (no markdown, no explanation):
{{
  "entry_decision": {{
    "signal": "BUY|WAIT|AVOID",
    "confidence": 0-100,
    "entry_quality": "EXCELLENT|GOOD|FAIR|POOR",
    "optimal_entry_price": price_level,
    "reasoning": "Detailed explanation of why BUY/WAIT/AVOID"
  }},
  "market_context": {{
    "session_assessment": "How current session affects entry",
    "news_today": "Any major news/events today",
    "volatility_level": "LOW|NORMAL|HIGH|EXTREME",
    "market_sentiment": "RISK_ON|RISK_OFF|NEUTRAL"
  }},
  "technical_assessment": {{
    "trend_quality": "STRONG|MODERATE|WEAK|CHOPPY",
    "support_resistance": "Price near support/resistance/middle",
    "indicator_alignment": "ALIGNED|MIXED|CONFLICTING",
    "pattern_detected": "Any chart pattern or NONE"
  }},
  "risk_warnings": [
    "Specific warning 1",
    "Specific warning 2"
  ],
  "entry_timing": {{
    "timing": "IMMEDIATE|WAIT_FOR_DIP|WAIT_FOR_BREAKOUT|WAIT_FOR_NEWS|AVOID_TODAY",
    "wait_for_price": price_level_if_waiting,
    "reason": "Why this timing"
  }},
  "position_sizing": {{
    "recommended_size": "FULL|HALF|QUARTER|MINIMAL",
    "reason": "Why this size"
  }}
}}

Be specific about TODAY's conditions. If you don't know about specific news, say so but make educated assessment based on typical patterns for {day_of_week}.
"""
```

---

## 🔧 Enhanced Entry Decision Logic

### Update grid_engine function to use enhanced AI response:

```python
def grid_engine(df, mtf_data=None):
    """Enhanced with better AI entry decision"""
    global lot_index
    
    # ... existing position checks ...
    
    # First entry with enhanced AI decision
    if len(buy_positions) == 0:
        # Entry cooldown check
        if entry_times:
            last_entry = entry_times[-1]
            if time.time() - last_entry < MIN_ENTRY_DELAY:
                return
        
        # ✅ ENHANCED: Get AI trading signal with full context
        if GEMINI_ENABLED:
            sr_analysis = trend_analysis['sr_analysis'] if trend_analysis else None
            market_data = prepare_market_data_for_ai(df, mtf_data, sr_analysis)
            
            if market_data:
                ai_signal = get_gemini_trading_signal()
                
                if ai_signal:
                    entry_dec = ai_signal['entry_decision']
                    market_ctx = ai_signal['market_context']
                    timing = ai_signal['entry_timing']
                    position_size = ai_signal['position_sizing']
                    
                    # Log comprehensive AI analysis
                    log.info(
                        f"AI ENTRY ANALYSIS:\n"
                        f"  Signal: {entry_dec['signal']} ({entry_dec['confidence']}%)\n"
                        f"  Quality: {entry_dec['entry_quality']}\n"
                        f"  Session: {market_ctx['session_assessment']}\n"
                        f"  News: {market_ctx['news_today']}\n"
                        f"  Timing: {timing['timing']}\n"
                        f"  Size: {position_size['recommended_size']}\n"
                        f"  Reason: {entry_dec['reasoning']}"
                    )
                    
                    # ✅ BLOCK ENTRY if AI says AVOID
                    if entry_dec['signal'] == 'AVOID':
                        log.warning(
                            f"❌ AI BLOCKS ENTRY: {entry_dec['reasoning']}",
                            throttle_key="ai_avoid",
                            throttle_interval=60
                        )
                        return
                    
                    # ✅ WAIT if AI says WAIT (unless confidence is low)
                    if entry_dec['signal'] == 'WAIT' and entry_dec['confidence'] > 60:
                        log.warning(
                            f"⏸️  AI SUGGESTS WAIT: {timing['reason']}\n"
                            f"   Wait for price: {timing['wait_for_price']}",
                            throttle_key="ai_wait",
                            throttle_interval=60
                        )
                        return
                    
                    # ✅ WARN about risks even if allowing entry
                    if ai_signal.get('risk_warnings'):
                        for warning in ai_signal['risk_warnings']:
                            log.warning(f"⚠️  AI WARNING: {warning}")
                    
                    # ✅ ADJUST LOT SIZE based on AI recommendation
                    lot_multiplier = 1.0
                    if position_size['recommended_size'] == 'HALF':
                        lot_multiplier = 0.5
                        log.info(f"AI recommends HALF position: {position_size['reason']}")
                    elif position_size['recommended_size'] == 'QUARTER':
                        lot_multiplier = 0.25
                        log.info(f"AI recommends QUARTER position: {position_size['reason']}")
                    elif position_size['recommended_size'] == 'MINIMAL':
                        lot_multiplier = 0.1
                        log.info(f"AI recommends MINIMAL position: {position_size['reason']}")
                    
                    # ✅ LOG if entry quality is poor
                    if entry_dec['entry_quality'] in ['POOR', 'FAIR']:
                        log.warning(
                            f"⚠️  Entry quality is {entry_dec['entry_quality']}: "
                            f"{entry_dec['reasoning']}"
                        )
                    
                    # ✅ CONFIRM if entry quality is excellent
                    if entry_dec['entry_quality'] == 'EXCELLENT':
                        log.info(
                            f"✅ EXCELLENT ENTRY SETUP: {entry_dec['reasoning']}"
                        )
                    
                    # Use adjusted lot size
                    adjusted_lot = LOT_LADDER[0] * lot_multiplier
                    
                    # Proceed with entry using AI-adjusted parameters
                    if buy(adjusted_lot):
                        entry_times.append(time.time())
                        log.info(f"Entry executed with AI-adjusted lot: {adjusted_lot}")
                    return
        
        # ... rest of existing entry logic if AI not available ...
```

---

## 📊 What This Enhancement Provides

### Before (Current):
```
AI: "BUY with 75% confidence"
Bot: "OK, entering with 0.01 lot"
```

### After (Enhanced):
```
AI Analysis:
  Signal: WAIT (80% confidence)
  Quality: FAIR
  Session: Asian (Low liquidity, range-bound)
  News: US CPI data at 18:30 IST today - expect high volatility
  Timing: WAIT_FOR_NEWS - Enter after CPI if bullish
  Size: QUARTER - High risk due to news
  Warnings:
    - Major news in 2 hours, spread will widen
    - Price near resistance, wait for breakout confirmation
    - Asian session typically range-bound, avoid breakout trades
  
Bot: "⏸️ AI SUGGESTS WAIT - Will monitor after CPI release"
```

---

## 🎯 Key Improvements

1. **Context Awareness**: AI knows current session, day, time
2. **News Consideration**: AI warns about major events
3. **Entry Quality**: AI rates entry setup quality
4. **Timing Guidance**: AI suggests when to enter (immediate/wait/avoid)
5. **Position Sizing**: AI recommends lot size based on risk
6. **Specific Warnings**: AI provides actionable warnings
7. **Better Reasoning**: AI explains WHY in detail

---

## 🚀 Implementation Steps

### Step 1: Update Gemini Model (2 minutes)
```python
# In both algo files, line 239/244:
GEMINI_MODEL = "gemini-3.1-flash-lite"  # Change from gemini-2.5-flash
```

### Step 2: Update Prompt (5 minutes)
- Replace prompt in `update_gemini_cache_background` function
- Add date/time context
- Add session detection

### Step 3: Update Entry Logic (10 minutes)
- Enhance `grid_engine` to use new AI response fields
- Add checks for AVOID/WAIT signals
- Implement position size adjustment
- Add warning logging

### Step 4: Test (15 minutes)
- Run on demo account
- Verify AI provides detailed analysis
- Check that entry blocking works
- Confirm position sizing adjustment works

**Total Time**: ~30 minutes

---

## 📝 Expected Results

### Better Entry Decisions:
- ✅ Avoid entries before major news
- ✅ Skip poor-quality setups
- ✅ Wait for better prices when appropriate
- ✅ Reduce position size in high-risk conditions
- ✅ Get specific warnings about current risks

### Improved Performance:
- ✅ Fewer bad entries
- ✅ Better entry timing
- ✅ Appropriate position sizing
- ✅ Reduced risk from news events
- ✅ Higher quality trades overall

---

## 💡 Quick Start

**Copy this enhanced prompt and replace the current one in your bot. That's the main change needed!**

The prompt now asks AI to consider:
- Current date/time and session
- Today's news and events  
- Entry quality and timing
- Risk warnings
- Position sizing

This makes AI much more useful for entry decisions!