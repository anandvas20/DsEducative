"""
Positions API routes
"""

from fastapi import APIRouter, HTTPException
from typing import Dict, List, Optional
from app.core.mt5_connector import mt5_connector

router = APIRouter()


@router.get("/live")
async def get_live_positions() -> List[Dict]:
    """Get all open positions"""
    if not mt5_connector.connected:
        # Try to connect
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    return mt5_connector.get_positions()


@router.get("/history")
async def get_position_history(days: int = 7) -> List[Dict]:
    """Get trade history for the last N days"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    return mt5_connector.get_history(days)


@router.post("/close/{ticket}")
async def close_position(ticket: int) -> Dict:
    """Close a specific position"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    result = mt5_connector.close_position(ticket)
    if result["status"] == "error":
        raise HTTPException(status_code=400, detail=result["message"])
    
    return result


@router.post("/close-all")
async def close_all_positions(position_type: Optional[str] = None) -> Dict:
    """Close all positions (optionally filtered by type: BUY or SELL)"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    result = mt5_connector.close_all_positions(position_type)
    return result


@router.get("/summary")
async def get_positions_summary() -> Dict:
    """Get summary of open positions"""
    if not mt5_connector.connected:
        if not mt5_connector.connect():
            raise HTTPException(status_code=503, detail="MT5 not connected")
    
    positions = mt5_connector.get_positions()
    
    buy_positions = [p for p in positions if p["type"] == "BUY"]
    sell_positions = [p for p in positions if p["type"] == "SELL"]
    
    total_profit = sum(p["profit"] for p in positions)
    buy_profit = sum(p["profit"] for p in buy_positions)
    sell_profit = sum(p["profit"] for p in sell_positions)
    
    total_volume = sum(p["volume"] for p in positions)
    buy_volume = sum(p["volume"] for p in buy_positions)
    sell_volume = sum(p["volume"] for p in sell_positions)
    
    return {
        "total_positions": len(positions),
        "buy_positions": len(buy_positions),
        "sell_positions": len(sell_positions),
        "total_profit": round(total_profit, 2),
        "buy_profit": round(buy_profit, 2),
        "sell_profit": round(sell_profit, 2),
        "total_volume": round(total_volume, 2),
        "buy_volume": round(buy_volume, 2),
        "sell_volume": round(sell_volume, 2)
    }

# Made with Bob
