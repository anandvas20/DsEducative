import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../core/services/api.service';

interface TradeHistory {
  ticket: number;
  order: number;
  time: string;
  type: string;
  volume: number;
  price: number;
  profit: number;
  swap: number;
  commission: number;
  comment: string;
  magic: number;
}

interface PendingOrder {
  ticket: number;
  time_setup: string;
  type: string;
  volume: number;
  price_open: number;
  sl: number;
  tp: number;
  price_current: number;
  symbol: string;
  comment: string;
  magic: number;
}

interface Statistics {
  total_trades: number;
  winning_trades: number;
  losing_trades: number;
  win_rate: number;
  total_profit: number;
  total_loss: number;
  net_profit: number;
  average_win: number;
  average_loss: number;
  profit_factor: number;
  max_drawdown: number;
  largest_win: number;
  largest_loss: number;
  total_volume: number;
  account_balance: number;
  account_equity: number;
}

@Component({
  selector: 'app-analytics',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})
export class AnalyticsComponent implements OnInit {
  activeTab: 'statistics' | 'history' | 'pending' = 'statistics';
  
  // Statistics
  statistics: Statistics | null = null;
  
  // Trade History
  tradeHistory: TradeHistory[] = [];
  totalTrades = 0;
  showingTrades = 0;
  historyDays = 30;
  historyLimit = 100;
  
  // Pending Orders
  pendingOrders: PendingOrder[] = [];
  totalPending = 0;
  
  // Loading states
  loadingStats = false;
  loadingHistory = false;
  loadingPending = false;
  
  // Errors
  statsError = '';
  historyError = '';
  pendingError = '';

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.loadStatistics();
    this.loadTradeHistory();
    this.loadPendingOrders();
    
    // Auto-refresh every 30 seconds
    setInterval(() => {
      if (this.activeTab === 'statistics') {
        this.loadStatistics();
      } else if (this.activeTab === 'history') {
        this.loadTradeHistory();
      } else if (this.activeTab === 'pending') {
        this.loadPendingOrders();
      }
    }, 30000);
  }

  setActiveTab(tab: 'statistics' | 'history' | 'pending') {
    this.activeTab = tab;
    
    // Load data if not already loaded
    if (tab === 'statistics' && !this.statistics) {
      this.loadStatistics();
    } else if (tab === 'history' && this.tradeHistory.length === 0) {
      this.loadTradeHistory();
    } else if (tab === 'pending' && this.pendingOrders.length === 0) {
      this.loadPendingOrders();
    }
  }

  loadStatistics() {
    this.loadingStats = true;
    this.statsError = '';
    
    this.apiService.getAnalytics().subscribe({
      next: (stats: any) => {
        this.statistics = stats;
        this.loadingStats = false;
      },
      error: (error: any) => {
        this.statsError = error.message || 'Failed to load statistics';
        this.loadingStats = false;
      }
    });
  }

  loadTradeHistory() {
    this.loadingHistory = true;
    this.historyError = '';
    
    this.apiService.getTradeHistory(this.historyDays, this.historyLimit).subscribe({
      next: (response: any) => {
        this.tradeHistory = response.trades || [];
        this.totalTrades = response.total || 0;
        this.showingTrades = response.showing || 0;
        this.loadingHistory = false;
      },
      error: (error: any) => {
        this.historyError = error.message || 'Failed to load trade history';
        this.loadingHistory = false;
      }
    });
  }

  loadPendingOrders() {
    this.loadingPending = true;
    this.pendingError = '';
    
    this.apiService.getPendingOrders().subscribe({
      next: (response: any) => {
        this.pendingOrders = response.orders || [];
        this.totalPending = response.total || 0;
        this.loadingPending = false;
      },
      error: (error: any) => {
        this.pendingError = error.message || 'Failed to load pending orders';
        this.loadingPending = false;
      }
    });
  }

  refreshData() {
    if (this.activeTab === 'statistics') {
      this.loadStatistics();
    } else if (this.activeTab === 'history') {
      this.loadTradeHistory();
    } else if (this.activeTab === 'pending') {
      this.loadPendingOrders();
    }
  }

  updateHistoryDays(days: number) {
    this.historyDays = days;
    this.loadTradeHistory();
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toLocaleString();
  }

  getTradeClass(profit: number): string {
    if (profit > 0) return 'profit-positive';
    if (profit < 0) return 'profit-negative';
    return 'profit-neutral';
  }

  exportToCSV() {
    if (this.tradeHistory.length === 0) {
      alert('No trade history to export');
      return;
    }

    const headers = ['Ticket', 'Time', 'Type', 'Volume', 'Price', 'Profit', 'Swap', 'Commission', 'Comment'];
    const rows = this.tradeHistory.map(trade => [
      trade.ticket,
      trade.time,
      trade.type,
      trade.volume,
      trade.price,
      trade.profit,
      trade.swap,
      trade.commission,
      trade.comment
    ]);

    let csv = headers.join(',') + '\n';
    rows.forEach(row => {
      csv += row.join(',') + '\n';
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `trade_history_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  }
}

// Made with Bob
