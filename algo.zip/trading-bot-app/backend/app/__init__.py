"""
Trading Bot Management Application
FastAPI backend for managing XAU/USD trading bots
"""

__version__ = "1.0.0"
__author__ = "Bob"
__description__ = "Trading Bot Management API with template-based configuration"

# Made with Bob