"""
Core modules for the trading bot application
"""

from .config import settings
from .bot_manager import bot_manager
from .mt5_connector import mt5_connector
from .gemini_service import GeminiService, get_gemini_service

__all__ = [
    "settings",
    "bot_manager",
    "mt5_connector",
    "GeminiService",
    "get_gemini_service"
]

# Made with Bob